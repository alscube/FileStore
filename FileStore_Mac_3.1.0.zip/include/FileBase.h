
// FileBase.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QObject>

#include "GlobalTypes.h"
#include "FSResultCode.h"
#include "ResultException.h"

#include "LibExport.h"

class QFile;
class RecordBase;


typedef enum FileState
{
	FileInvalid = -1
	, FileClosed
	, FileOpen
}FILE_STATE;



// TODO: Throw on an invalid header, file not open

class LIB_EXPORT FileBase : public QObject
{
	Q_OBJECT

    friend class BTreeFile;

public:
	FileBase( const QString& tableName, const QString& pathFileName );
	virtual ~FileBase( );

        // Returns the name of table
	const QString& GetTableName() const;

        // Returns just the file name
	const QString GetFileName( ) const;

        // Returns the full path and name of file
	const QString& GetPathFileName( ) const;

        // Called to create a new physical file, returns a ResultCode.
	virtual ResultValue Create( );

        // Called to create a new physical file, throws an exception
    virtual void CreateT( );

        // Called to add default entries to the File, default method does nothing, returns a ResultCode.
    virtual ResultValue CreateDefaultEntries( );

        // Called to add default entries to the File, default method does nothing, throws an exception.
    virtual void CreateDefaultEntriesT( );

        // Called to delete this file
	virtual ResultValue DeleteFile( );

        // Called to open a File, returns a ResultCode.
	virtual ResultValue Open( );

        // Called to open a File, throws an exception.
	virtual void OpenT( bool markOpen = true );

        // Called to verify if file is open.
	virtual bool IsOpen( );

        // Called to close a File, returns a ResultValue
	virtual ResultValue Close( );

        // Called to close a File, throws and exception.
	virtual void CloseT( );

        // Called to insert a record, returns a ResultValue.
	virtual ResultValue Insert( RecordBase& rec );

        // Called to insert a record, throws an exception.
	virtual void InsertT( RecordBase& rec );

        // Called to read a record, returns a ResultValue.
	virtual ResultValue Read( RecordBase& rec );

        // Called to read a record, throws an exception.
	virtual void ReadT( RecordBase& rec );

        // Reads the next record using an internal index, returns a ResultValue.
	virtual ResultValue ReadNext( RecordBase& rec );

        // Reads the next record using an internal index, throws an exception.
	virtual void ReadNextT( RecordBase& rec );

        // Resets the internal index used by ReadNext above.
    virtual void SetReadNextRecordIndex( REC_ID nextRecordIndex = NO_REC_ID);

        // Called to update a record, returns a ResultCode.
	virtual ResultValue Update( RecordBase& rec );

        // Called to update a record, throws an exception.
	virtual void UpdateT( RecordBase& rec );

        // Deletes the record at identified by the recordId, returns a ResultValue.
	virtual ResultValue Delete( int recordId );

        // Deletes the record at identified by the recordId, throws and exception.
	virtual void DeleteT( int recordId );


        // ** Abstract methods to be implemented in the derived File class **

        /*!
         * \fn FILE_ID GetFileID( ) const = 0
         *
         * Called to get the file ID of this FileStore.  Each FileStore should have
         * a unique ID.
         *
         * Implement this in the dervied class and return a unique ID.
         */
    virtual FILE_ID GetFileID( ) const = 0;

        /*!
         * \fn int GetFileType( ) const = 0
         *
         * Called to get the file type for this FileStore.  One or more FileStore files
         * may have the same type.
         *
         * Implement this in the derived class and return the file type.
         */
    virtual int GetFileType( ) const = 0;

        /*!
         * \fn int GetFieldCount( ) const = 0
         *
         * Called to get the number of fields int this FileStore's record.  Call
         * into the dervied record object to get the field count.
         *
         *      int TestFile::GetFieldCount( ) const
         *      {
         *          return TestRecord::GetFieldCount();
         *      }
         */
    virtual int GetFieldCount( ) const = 0;

        /*!
         * \fn int GetRecordSize( ) const = 0
         *
         * Called to get the total number bytes in this record.  Call
         * into the dervied record object to get the record size.
         *
         *      int TestFile::GetRecordSize( ) const
         *      {
         *          return TestRecord::GetRecordSize();
         *      }
         */
    virtual int GetRecordSize( ) const = 0;

        /*!
         * \fn RecordBase* NewRecord( REC_ID recordId = NO_REC_ID ) = 0
         *
         * Called to make a new record object for the derived Record / FileBase.
         *
         * In the derived file class create a method called NewRecord that
         * returns the record type for the derived record class.
         *
         */
    virtual RecordBase* NewRecord( REC_ID recordId = NO_REC_ID ) = 0;


        // Implemented to provide a way to create and return
        // the derived record class as a RecordBase object.
        // This method calls NewRecord above.
    virtual RecordBase* _NewRecord( REC_ID recordId = NO_REC_ID );


		// **** FILE HEADER FIELDS ****
        // Returns internal version of this FileStore
	qint32 GetHeaderFileVersion( );

        // Returns the File Type from the Header
    FILE_TYPE GetHeaderFileType( );

        // Returns the Unique File ID from the Header
	FILE_ID GetHeaderFileId( );

        // Returns the Unique File ID in string format
	QString GetHeaderFileIdAsString( );

        // Returns the number of fields in each record (not including delete fields)
	qint32 GetHeaderFileFieldCount( );

        // Returns the File Record Size from the Header
	qint32 GetHeaderFileRecordSize( );

        // Returns the number of records, including deletes, in the Table File
	qint32 GetHeaderFileTotalRecordCount( );

        // Returns the number of records, not including deletes, in the Table File
	qint32 GetHeaderFileActiveRecordCount( );

        // Returns the First Deleted record number in the table file
	qint32 GetHeaderFileFirstDeleted( );

        // Returns the Last Deleted record number in the table file
	qint32 GetHeaderFileLastDeleted( );

        // Returns the Open | Close state of the table file
    FILE_STATE GetHeaderFileOpenCloseState( );

        // Gets the header spare value at Spare Index(0-4), returned as int.
	qint32  GetHeaderSpareField( int spareIndex ) const;

        // Sets the header spare value at Spare Index(0-4).
	void SetHeaderSpareField( int spareIndex, qint32 spareValue );
		// **** FILE HEADER FIELDS ****

		// return the size of the file header
	int GetTotalHeaderSize( );

        // Called to write the header of the Table File, throws an exception
    void WriteHeaderT( );


private:
        /// Called to read a record from the File, returns a ResultValue
//	ResultValue ReadRecord( RecordBase& rec );

        /// Called to read a record from the File, throws an exception
	void ReadRecordT( RecordBase& rec );

        /// Called to write a record to the File, returns a ResultValue
//	ResultValue WriteRecord( int recordId, RecordBase& rec );

        /// Called to write a record to the File, throws an exception
    void WriteRecordT( REC_ID recordId, RecordBase& rec );

        /// Called to mark a record deleted and update the header, returns a ResultValue
//    ResultValue DeleteRecord( RecordBase& rec, REC_ID firstDeletedRecordInTable, REC_ID lastDeletedRecordInTable );

        /// Called to mark a record deleted and update the header, throws an exception
    void DeleteRecordT( RecordBase& rec, REC_ID firstDeletedRecordInFile, REC_ID lastDeletedRecordInFile );

        /// Returns a stream set to the record to read or write, returns a ResultValue
//    ResultValue SeekToRecord( REC_ID recordId );

    /// Returns a stream set to the record to read or write, throws an exception
    void SeekToRecordT( REC_ID recordId );

        /// Called to read the header of the Table File
	void ReadHeaderT( );

        // Called to reset all Header fields to -1
	void ClearFileHeaderInfo( );

        // Called to write the header of the Table File, returns a ResultValue
//    ResultValue WriteHeader( );


private:
	static int FILEBASE_VERSION;

        /// Name of the type of table, "Books", "Authors", ...
	QString m_TableName;

        /// Complete (path+name) of the table file
	QString m_PathAndFileName;

        /// random IO disk file 'handle'
	QFile* m_DiskFile;

        /// size of header in bytes
	qint32 m_TotalHeaderSize;

        /// Last record accessed
	qint32 m_LastUsedRecord;

        /// Helps determine file was correctly closed
	bool _markOpen;

        /// offsets into file header array
	enum FileHeaderOffsets
	{
		FILE_HEADER_SIZE
		, hFILE_VERSION
		, hFILE_TYPE
		, hUNIQUE_FILE_ID
		, hFIELD_COUNT
		, hRECORD_SIZE
		, hTOTAL_RECORD_COUNT
		, hACTIVE_RECORD_COUNT
		, hFIRST_DELETED
		, hLAST_DELETED
		, hOPEN_CLOSE				// track if file was properly closed
		, SPARE
		, SPARE2
		, SPARE3
		, SPARE4
		, SPARE5
		, FILE_HEADER_FIELD_COUNT	// Always last
	};

        /// Array that holds the header information (enum above)
        /// note: negative values can be in the header
    qint32 _FileHeader[FILE_HEADER_FIELD_COUNT];
};



