
// TestFile.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FSFileBase.h"
#include "TestRecord.h"

#define TEST_FILE_ID 1
#define TEST_FILE_TYPE 1


#if defined(FILESTORE_LIBRARY)
#define test
#endif

// In order to test the FSFileBase a derived 'file' class is needed,
// this is that derived class.

class TestFile : public FSFileBase
{
public:
	TestFile( const QString& pathFileName );
	~TestFile() override;


		// Returns the Table ID defined in the derived table class
	FILE_ID GetFileID( ) const override { return TEST_FILE_ID; }

		// Returns the table Type defined in the derived table class
	int GetFileType( ) const override { return TEST_FILE_TYPE; }

		// Returns the number of fields in the record from derived table class
	int GetFieldCount( ) const override { return TestRecord::GetFieldCount(); }

		// Returns the table record size defined in the derived table class
	int GetRecordSize( ) const override { return TestRecord::GetRecordSize(); }

		// Called to make a new record instance for 'this' table
	TestRecord* NewRecord( int recordId = NO_REC_ID ) override;

		// Called to create a default set of entires when file is first created
	ResultValue CreateDefaultEntries( ) override;
};


