var searchData=
[
  ['read_422',['Read',['../class_file_base.html#a49e54b8409b2be6fd84d08e31d17aa99',1,'FileBase']]],
  ['readfields_423',['ReadFields',['../class_record_base.html#a939258cffc104b005dff98ef575ea009',1,'RecordBase']]],
  ['readnext_424',['ReadNext',['../class_file_base.html#aca705af60f1789666b9779d88113e48c',1,'FileBase']]],
  ['readnextt_425',['ReadNextT',['../class_file_base.html#aa35ea326241414c61e67c34a738b6379',1,'FileBase']]],
  ['readt_426',['ReadT',['../class_file_base.html#aef55c8bf0738bd0c294d266effedd96c',1,'FileBase::ReadT()'],['../class_record_base.html#a0b84837a31e3df6305f66362b405b5dd',1,'RecordBase::ReadT()']]],
  ['recordbase_427',['RecordBase',['../class_record_base.html#a22780568997858baaaa1b3736603aa42',1,'RecordBase::RecordBase(REC_ID recordID=NO_REC_ID, FileBase *fileBase=nullptr)'],['../class_record_base.html#a4991de865a9d81e891df26c2d02aa0df',1,'RecordBase::RecordBase(REC_ID recordID, REC_ID prevRecID, REC_ID nextRecID)']]],
  ['recordbasefields_428',['RecordBaseFields',['../class_record_base_fields.html#ab66c9e16b30113fcafa04d9e5edda7f4',1,'RecordBaseFields']]],
  ['resetrecord_429',['ResetRecord',['../class_record_base.html#af60cc0126dc4f2615aa8cc087a47a3d0',1,'RecordBase']]],
  ['resultcode_430',['ResultCode',['../class_result_exception.html#a3c3fbcf8ead70218390c37479fe6856d',1,'ResultException']]],
  ['resultcodestring_431',['ResultCodeString',['../class_result_exception.html#a7b5f25a03717c7dfda12b5f5c3a85978',1,'ResultException']]],
  ['resultexception_432',['ResultException',['../class_result_exception.html#a4a1ca90ad384fc219ba716a038907e82',1,'ResultException']]],
  ['resultoffset_433',['ResultOffset',['../class_result_codes.html#ab9f600420beaef53a8b34979da8616b0',1,'ResultCodes']]]
];
