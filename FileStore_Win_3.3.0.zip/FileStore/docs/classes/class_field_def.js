var class_field_def =
[
    [ "FieldDoubleMax", "class_field_def.html#ac5c2e541ddda92bb8963aefa12064837", null ],
    [ "FieldDoubleMin", "class_field_def.html#ac9acc88c6c538cf5fc65ea2adb77e0e4", null ],
    [ "FieldFloatMax", "class_field_def.html#a98cdc12844fea5ddb537016ea4b5979c", null ],
    [ "FieldFloatMin", "class_field_def.html#afbbbd22e92917bbad42fea83d9b2e8aa", null ],
    [ "FieldMax", "class_field_def.html#a490388d93db49e00c6ff5e25f80ffbd7", null ],
    [ "FieldMin", "class_field_def.html#a891428cb32c922b97ac82fca826ee6b1", null ],
    [ "FieldName", "class_field_def.html#a8b03b6a641329785b98bcaeaac22768c", null ],
    [ "minMaxVar", "class_field_def.html#adbc41784512510b4c2bdfac1489e88cb", null ],
    [ "StorageSize", "class_field_def.html#a2be03e33b840eca522ce626fdbb6bd0e", null ]
];