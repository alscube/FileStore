
// BTreeInsertTests.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include <QTest>
#include <QDebug>

#include <QList>
#include <QStringList>
#include <QVariant>

#include "BTreeTestUtils.h"

class BTreeFileTestFile;
class BTreeFileTestRecord;


class BTreeInsertTests : public QObject
{
	Q_OBJECT

public:
	// You can remove any or all of the following functions if its body
	// is empty.

	BTreeInsertTests();
	virtual ~BTreeInsertTests();

private Q_SLOTS:
//	void initTestCase();
	void cleanupTestCase();
//	void init();

	void CreateObjectTest( );
	void CreateFileTest( );
	void DuplicatesAllowedTest( );

	void CreateRecordTest( );
	void BTreeRecordTest( );
	void BTreeTestRecordTest( );
	void CompareRecordTest( );

	void GetRecordOnLeftTest();
	void GetRecordOnRightTest();

	void InsertTopRecordTest( );
	void InsertSingleLeftRecord( );
	void InsertSingleRightRecord( );

	void single_LL_RotationInsert();
	void single_RR_RotationInsert();
	void double_LR_RotationInsert();
	void double_RL_RotationInsert();

	void InsertDuplicateRight( );
	void InsertDuplicateLeft( );
	void InsertDuplicateFromTop( );
	void InsertMixedRecords();

private:
	BTreeTestUtils _btreeTestUtils;
};

//BTreeDeleteTestsDECLARE_TEST(BTreeInsertTests)
