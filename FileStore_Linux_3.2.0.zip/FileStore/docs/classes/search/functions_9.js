var searchData=
[
  ['newrecord_0',['NewRecord',['../class_f_s_file_base.html#a505e010f1d1bbe1dfb65654d8b092b7f',1,'FSFileBase']]]
];
