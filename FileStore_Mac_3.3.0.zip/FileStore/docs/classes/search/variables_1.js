var searchData=
[
  ['delete_5ffile_5fid_514',['DELETE_FILE_ID',['../class_f_s_deleted_record.html#a8e161a5eaf31341dbcebbc6fff72df69',1,'FSDeletedRecord']]],
  ['delete_5ffile_5ftype_515',['DELETE_FILE_TYPE',['../class_f_s_deleted_record.html#ac524a0806ec64d0487bedefd58ca36db',1,'FSDeletedRecord']]]
];
