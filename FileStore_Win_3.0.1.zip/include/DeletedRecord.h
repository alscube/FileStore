
// DeletedRecord.h

// Copyright (C) 2011 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "RecordBase.h"

#include "LibExport.h"



class LIB_EXPORT DeletedRecord : public RecordBase
{
public:
	DeletedRecord( REC_ID recordId = NO_REC_ID );
    DeletedRecord( REC_ID recordId, REC_ID prevRecord, REC_ID nextRecord );
	~DeletedRecord( ) override;

    static const FILE_ID DELETE_FILE_ID  = -9999;
    static const FILE_TYPE DELETE_FILE_TYPE = -9999;

	// The RecordBase defines the record for the DeleteRecord class
    // so they are not defined here, see RecordBaseFields

protected:
    ResultValue _ReadFields( QDataStream& dataStream ) override;
    ResultValue _WriteFields( QDataStream& dataStream ) override;
};

