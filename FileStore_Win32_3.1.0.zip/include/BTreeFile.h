
// BTreeFile.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FileBase.h"
#include "BTreeRecord.h"

#include "LibExport.h"


//typedef enum matching {
//	Matched
//	, MoveLeft
//	, MoveRight
//} MATCHING;


//
//  SPARE 1 - ID of Top Most Record
//  SPARE 2 - indicates if duplicates are accepted
//  SPARE 3 - Last Duplicate IP ... THIS SHOULD BE BASED UPON THE LAST DUP OF THAT RECORD SET
//  SPARE 4 - type of index (just an enum to help identify)
//


// direction to move
typedef enum {
	AT_TOP_OF_TREE = -1,
	LEFT,
	RIGHT
} LEFT_OR_RIGHT;

#define NO_CHILD -1



class LIB_EXPORT BTreeFile : public FileBase
{
public:
       // Default constructor for this clas
    BTreeFile( const QString& tableName, const QString& pathFileName );
	~BTreeFile() override;


	// --- FileBase class overrides BEGIN ---

        // Called to create a BTreeFile.
	ResultValue Create( FILE_ID fileID, FILE_ID parentFileID, bool allowDuplicates, int sortIndex = -1 );

        // Called to open a BTreeFile.
    void OpenT( bool markOpen = true ) override;

        // Returns the File ID defined in the derived table class
    FILE_ID GetFileID( ) const override;

        // Returns the File Type for BTrees
    FILE_TYPE GetFileType( ) const override;

        // Called to make a new record instance for 'this' table
    BTreeRecord* NewRecord( int recordId = NO_REC_ID ) override;

        // Called to Insert a record in the tree, returns ResultValue.
    ResultValue Insert( BTreeRecord& rec );

        // Called to Insert a record in the tree, throws an exception.
    void InsertT( BTreeRecord& newRec );

        // Called to delete a record from the tree
    void Delete( BTreeRecord& rec );

	// --- FileBase class overrides END ---


	// --- BTreeFile Interface implementation ---

        // Called to get the top of index tree
	int GetTopRecordID( );

        // Called to get the top most record of the tree, throws an exception.
    void GetTopRecord( BTreeRecord& rec );

        // Called to get the left most record
	ResultValue GetLeftMostRecord( BTreeRecord& rec );

        // Called to get the right most record
	ResultValue GetRightMostRecord( BTreeRecord& rec );

        // Get next 'sorted' entry in the tree
	ResultValue GetNextRecord( BTreeRecord& curRec );

        // Get previous 'sorted' entry in the tree
	ResultValue GetPreviousRecord( BTreeRecord& curRec );

        // Validates the links and parents of the tree
    void ValidateTree( );

        // Indicates if duplicates were defined when file was created
	bool duplicatesAllowed( );


private:
		// Recursively finds the insertion point
	ResultValue InsertIntoTree( BTreeRecord& newRec, BTreeRecord *top, LEFT_OR_RIGHT leftOrRight, bool* rebalance );

		// inserts new node/record on left in the tree and re-balances if necessary
	ResultValue InsertLeft( BTreeRecord& newRec, BTreeRecord* top, bool* rebalance );

		// inserts new node/record on right in the tree and re-balances if necessary
	ResultValue InsertRight( BTreeRecord& newRec, BTreeRecord* top, bool* rebalance );

		// deletes a node/record from the tree
	void DeleteFromTree( BTreeRecord& rec, BTreeRecord* top, LEFT_OR_RIGHT leftOrRight, bool* rebalance ); // throws
	void DoDelete( BTreeRecord& rec, BTreeRecord& top, bool* rebalance );
	void DeleteBalance1( BTreeRecord& rec, bool* rebalance );
	void DeleteBalance2( BTreeRecord& rec, bool* rebalance );

		// Called to update the link list within the tree
	void updateKeyLinks( BTreeRecord& top, BTreeRecord& newRec, LEFT_OR_RIGHT leftOrRight ); // throws

		// Update the link list within the tree when deleting an entry
	void ResetLinksOnDelete( BTreeRecord& rec );

		// Resets record at top of tree
	void SetTopNodeRecordId( int recordId );

		// Called to fix the parent of the 'top' record
	void SetTopParent( BTreeRecord& childRec, BTreeRecord& topRec );    // throws

		// Called to fix the child - parent relationship
	void SetParent( BTreeRecord& child, int parent, int leftOrRight );  // throws

		// Called to fix the parent - child relationship
	void SetChildToParent( int child, BTreeRecord& parent, int leftOrRight, bool write = true );  // throws

		// Called to set parenting child record to parent record
	void SetChildToParent( BTreeRecord& child, BTreeRecord& parent, int leftOrRight, bool write = true );  // throws

		// Called to rest the "top's" parent-child relationship
	void SetParent( BTreeRecord& rec, LEFT_OR_RIGHT leftOrRight );  // throws

		// update and set next duplicate number
		// The last duplicate ID is stored in the Spare 3 header slot
	void SetNextDuplicateID( BTreeRecord& newRec ); // throws


        // hidden, NOT used with a BTree file
    ResultValue Create( ) override;

private:
		// Each BTree file will have a unique File ID that
		// is assigned when the file is created.
	FILE_ID _FileID;

		// Indicates if a duplicate is being inserted.
		// This is toggled true as soon as a duplicate is
		// detected.  Before a duplicate is detected all
        // compares do not include the duplicate key because
        // duplicates need to be detected.
	bool _InsertingDuplicate;
};


