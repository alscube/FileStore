var searchData=
[
  ['no_5fchild_604',['NO_CHILD',['../_b_tree_file_8h.html#a53f831f4e9e3fcb833d53dd7ae6b1ccc',1,'BTreeFile.h']]],
  ['no_5ffile_5fid_605',['NO_FILE_ID',['../_global_types_8h.html#a302e870f61469167d0391c1c2ed9fb2f',1,'GlobalTypes.h']]],
  ['no_5ffile_5ftype_606',['NO_FILE_TYPE',['../_global_types_8h.html#a26d878fff368eb1d6741aa0bce6157de',1,'GlobalTypes.h']]],
  ['no_5frec_5fid_607',['NO_REC_ID',['../_global_types_8h.html#a7778e2faa2babe0e93654cfdfdf2bd49',1,'GlobalTypes.h']]]
];
