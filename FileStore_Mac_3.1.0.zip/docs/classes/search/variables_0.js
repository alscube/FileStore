var searchData=
[
  ['delete_5ffile_5fid_484',['DELETE_FILE_ID',['../class_deleted_record.html#adf31ceb21f862918e1ffbee1b30189b3',1,'DeletedRecord']]],
  ['delete_5ffile_5ftype_485',['DELETE_FILE_TYPE',['../class_deleted_record.html#a0f2ef2616b1e2d53d2c5d98a7cdc2531',1,'DeletedRecord']]]
];
