
// FSDeletedRecord.h

// Copyright (C) 2011 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FSRecordBase.h"

#include "FSLibExport.h"



class LIB_EXPORT FSDeletedRecord : public FSRecordBase
{
public:
    FSDeletedRecord( REC_ID recordId = NO_REC_ID );
    FSDeletedRecord( REC_ID recordId, REC_ID prevRecord, REC_ID nextRecord );
    ~FSDeletedRecord( ) override;

    static const FILE_ID DELETE_FILE_ID  = -9999;
    static const FILE_TYPE DELETE_FILE_TYPE = -9999;

    // The FSRecordBase defines the record/Fields for the FSDeleteRecord class.
    // Fields and accessors are defined in FSRecordBaseFields.

protected:
    FSRecordBaseFields& GetFields( ) override { return _RecordFields; }

    ResultValue _ReadFields( QDataStream& dataStream ) override;
    ResultValue _WriteFields( QDataStream& dataStream ) override;
};

