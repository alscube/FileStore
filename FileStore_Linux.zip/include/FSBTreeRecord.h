
// FSBTreeRecord.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QObject>
#include "FSRecordBase.h"

#include "FSLibExport.h"


// default file type ID for a btree file
#define BTREE_FILE_TYPE 10


class LIB_EXPORT FSBTreeRecordFields : public FSRecordBaseFields
{
public:
    FSBTreeRecordFields();
};


typedef enum  {
	CompareEqual
	, CompareLessThan
	, CompareGreaterThan
	, UnexpectedError
} eCOMPARE_RESULT;


typedef enum Balanced
{
    lean_left = -1,
    balanced = 0,
    lean_right = 1
} BALANCED;


class FSBTreeFile;


class LIB_EXPORT FSBTreeRecord : public FSRecordBase
{
    friend class FSBTreeFile;

public:

    typedef enum btreeFields
	{
          fParent = fFirstUserField
		, fLeft
		, fRight
		, fNext
		, fPrev
		, fBalance
		, fDuplicateID
		, BTreeRecordLastField = fDuplicateID
    } BTREE_FIELDS;


    FSBTreeRecord( REC_ID recordId = NO_REC_ID, FSFileBase* FSFileBase = nullptr );

    ~FSBTreeRecord( ) override;

    // ** API BEGIN **

        // Get Parent of this node
    REC_ID GetParent( );

        // Set Parent for this node
    ResultValue SetParent( REC_ID parentID );

        // Get record ID of record on left
    REC_ID GetChildOnLeft( );

        // Set record ID of record on left
    ResultValue SetChildOnLeft( REC_ID left );

        // Get record ID of record on right
    REC_ID GetChildOnRight( );

        // Set record ID of record on right
    ResultValue SetChildOnRight( REC_ID right );

        // Get next key in the link list of keys
    REC_ID GetNext( );

        // Set next key in the link list of keys
    ResultValue SetNext( REC_ID next );

        // Get previous key in the link list of keys
    REC_ID GetPrev( );

        // Set previous key in the link list of keys
    ResultValue SetPrev( REC_ID prev );

        // Get balance state of children
    BALANCED GetBalance( );

        // Set balance state of children
    ResultValue SetBalance( BALANCED balance );

        // Get duplicate key value. If 0 this not used.
    ID GetDuplicateID( );

        // Get duplicate key value. If 0 this not used.
    ResultValue SetDuplicateID( ID duplicateID );

    // ** API END **


	// -------------------------------
	// Record Interface implementation

        // Returns the total size of a record (all fields)
    static int GetRecordSize( );

        // Returns the total number of fields in record
    static int GetFieldCount( );

        // Returns all fields associated with the record
    static const QStringList& GetFieldNameList( );

        // Returns the value of a specific field by index
    ResultValue GetFieldValue( int fieldNum, QVariant& outValue ) override;

        // Called to compare the contents of this record to another
        // This is used to sort the 'keys'
    virtual eCOMPARE_RESULT CompareRecords( FSBTreeRecord& compareToRec, bool compareDups );


protected:
    FSBTreeRecordFields& GetFields( ) override { return m_BTreeRecordFields; }

    ResultValue _ReadFields( QDataStream& dataStream ) override;
    ResultValue _WriteFields( QDataStream& dataStream ) override;


private:
    qint32 _ParentID;		// parent id record number
    qint32 _ChildOnLeft;	// left id record number
    qint32 _ChildOnRight;	// right id record number
    qint32 _SortNext;		// next key in the link list of keys
    qint32 _SortPrev;		// prev key in the link list of keys
    BALANCED _Balance;		// how this leaf is currently balanced
    qint32 _DuplicateID;    // If key is a duplicate, used as additional key
							// An incremented unique value to order the key

	// internal record fields
    static FSBTreeRecordFields m_BTreeRecordFields;
};


