var _log_message_8h =
[
    [ "LogMessage", "class_log_message.html", "class_log_message" ],
    [ "LOG_MESSAGE", "_log_message_8h.html#ab2d5ec64bcab9465d8b26138ee6ac1ba", null ]
];