﻿
// ResultException.h

// Copyright (C) 2021 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QString>
#include <QFile>
#include <QTextStream>
#include "ResultCodes.h"


#define LOG_MESSAGE( msg ) LogMessage::Instance()->log( msg )

// To be implemented ...
// #define START_LOG( ) { ResultException startLog( __FILE__, __FUNCTION__, __LINE__, SUCCESS, "Start Log" ); }



class QFile;
class QTextStream;


class LogMessage
{
public:
        // Get instance of this singleton
    static LogMessage* Instance( );

        // Set name for log file, won't log with out a name set
    void SetLogName( const QString& logPathAndName );

        // Return name of log file
    const QString& GetLogName( );

        // Call to clear out log file
    void Clear( );

        // call to add a message to the log file
    void Log( const QString& message );

private:
    LogMessage( );

    bool OpenLog( );
    void CloseLog( );

private:
    static LogMessage* _Instance;

    static QString _LogPathAndName;
    QFile   _LogFile;
    QTextStream _LogFileStream;
};

