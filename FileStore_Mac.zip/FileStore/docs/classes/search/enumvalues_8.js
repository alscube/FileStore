var searchData=
[
  ['no_5fpermissions_5ffor_5ffile_0',['NO_PERMISSIONS_FOR_FILE',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a71e45ff885895a60a9412cc7bd71bb90',1,'FSResultCodes.h']]],
  ['no_5frecords_5fin_5ffile_1',['NO_RECORDS_IN_FILE',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a066ae3bd819ba19f0039234f8a7aeea1',1,'FSResultCodes.h']]],
  ['not_5fimplemented_2',['NOT_IMPLEMENTED',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a12bcc9d9958a22b983e65f77f3faf90b',1,'FSResultCodes.h']]]
];
