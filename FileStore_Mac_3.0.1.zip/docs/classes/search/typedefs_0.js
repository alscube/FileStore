var searchData=
[
  ['_5ffield_5fdef_474',['_FIELD_DEF',['../_record_base_fields_8h.html#a8c5d3e1facca48238a70b4c0989beb03',1,'RecordBaseFields.h']]]
];
