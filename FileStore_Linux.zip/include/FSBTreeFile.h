
// FSBTreeFile.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FSFileBase.h"
#include "FSBTreeRecord.h"

#include "FSLibExport.h"


//typedef enum matching {
//	Matched
//	, MoveLeft
//	, MoveRight
//} MATCHING;


//
//  SPARE 1 - ID of Top Most Record
//  SPARE 2 - indicates if duplicates are accepted
//  SPARE 3 - Last Duplicate IP ... THIS SHOULD BE BASED UPON THE LAST DUP OF THAT RECORD SET
//  SPARE 4 - type of index (just an enum to help identify)
//


// direction to move
typedef enum {
	AT_TOP_OF_TREE = -1,
	LEFT,
	RIGHT
} LEFT_OR_RIGHT;

#define NO_CHILD -1



class LIB_EXPORT FSBTreeFile : public FSFileBase
{
public:
       // Default constructor for this clas
    FSBTreeFile( const QString& tableName, const QString& pathFileName );
    ~FSBTreeFile() override;


	// --- FSFileBase class overrides BEGIN ---

        // Called to create a FSBTreeFile.
	ResultValue Create( FILE_ID fileID, FILE_ID parentFileID, bool allowDuplicates, int sortIndex = -1 );

        // Called to open a FSBTreeFile.
    void OpenT( bool markOpen = true ) override;

        // Returns the File ID defined in the derived table class
    FILE_ID GetFileID( ) const override;

        // Returns the File Type for BTrees files
    FILE_TYPE GetFileType( ) const override;

        // Called to make a new record instance for 'this' table
    FSBTreeRecord* NewRecord( int recordId = NO_REC_ID ) override;

        // Called to Insert a record in the tree, returns ResultValue.
    ResultValue Insert( FSBTreeRecord& rec );

        // Called to Insert a record in the tree, throws an exception.
    void InsertT( FSBTreeRecord& newRec );

        // Called to delete a record from the tree
    void Delete( FSBTreeRecord& rec );

	// --- FSFileBase class overrides END ---


    // --- FSBTreeFile Interface implementation ---

        // Called to get the top of index tree
	int GetTopRecordID( );

        // Called to get the top most record of the tree, throws an exception.
    void GetTopRecord( FSBTreeRecord& rec );

        // Called to get the left most record
	ResultValue GetLeftMostRecord( FSBTreeRecord& rec );

        // Called to get the right most record
	ResultValue GetRightMostRecord( FSBTreeRecord& rec );

        // Get next 'sorted' entry in the tree
	ResultValue GetNextRecord( FSBTreeRecord& curRec );

        // Get previous 'sorted' entry in the tree
	ResultValue GetPreviousRecord( FSBTreeRecord& curRec );

        // Validates the links and parents of the tree
    void ValidateTree( );

        // Indicates if duplicates were defined when file was created
	bool duplicatesAllowed( );


private:
		// Recursively finds the insertion point
	ResultValue InsertIntoTree( FSBTreeRecord& newRec, FSBTreeRecord *top, LEFT_OR_RIGHT leftOrRight, bool* rebalance );

		// inserts new node/record on left in the tree and re-balances if necessary
	ResultValue InsertLeft( FSBTreeRecord& newRec, FSBTreeRecord* top, bool* rebalance );

		// inserts new node/record on right in the tree and re-balances if necessary
	ResultValue InsertRight( FSBTreeRecord& newRec, FSBTreeRecord* top, bool* rebalance );

		// deletes a node/record from the tree
	void DeleteFromTree( FSBTreeRecord& rec, FSBTreeRecord* top, LEFT_OR_RIGHT leftOrRight, bool* rebalance ); // throws
	void DoDelete( FSBTreeRecord& rec, FSBTreeRecord& top, bool* rebalance );
	void DeleteBalance1( FSBTreeRecord& rec, bool* rebalance );
	void DeleteBalance2( FSBTreeRecord& rec, bool* rebalance );

		// Called to update the link list within the tree
	void updateKeyLinks( FSBTreeRecord& top, FSBTreeRecord& newRec, LEFT_OR_RIGHT leftOrRight ); // throws

		// Update the link list within the tree when deleting an entry
	void ResetLinksOnDelete( FSBTreeRecord& rec );

		// Resets record at top of tree
	void SetTopNodeRecordId( int recordId );

		// Called to fix the parent of the 'top' record
	void SetTopParent( FSBTreeRecord& childRec, FSBTreeRecord& topRec );    // throws

		// Called to fix the child - parent relationship
	void SetParent( FSBTreeRecord& child, int parent, int leftOrRight );  // throws

		// Called to fix the parent - child relationship
	void SetChildToParent( int child, FSBTreeRecord& parent, int leftOrRight, bool write = true );  // throws

		// Called to set parenting child record to parent record
	void SetChildToParent( FSBTreeRecord& child, FSBTreeRecord& parent, int leftOrRight, bool write = true );  // throws

		// Called to rest the "top's" parent-child relationship
	void SetParent( FSBTreeRecord& rec, LEFT_OR_RIGHT leftOrRight );  // throws

		// update and set next duplicate number
		// The last duplicate ID is stored in the Spare 3 header slot
	void SetNextDuplicateID( FSBTreeRecord& newRec ); // throws


        // hidden, NOT used with a BTree file
    ResultValue Create( ) override;

private:
		// Each BTree file will have a unique File ID that
		// is assigned when the file is created.
	FILE_ID _FileID;

		// Indicates if a duplicate is being inserted.
		// This is toggled true as soon as a duplicate is
		// detected.  Before a duplicate is detected all
        // compares do not include the duplicate key because
        // duplicates need to be detected.
	bool _InsertingDuplicate;
};


