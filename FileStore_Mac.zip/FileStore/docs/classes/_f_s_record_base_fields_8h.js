var _f_s_record_base_fields_8h =
[
    [ "FieldDef", "class_field_def.html", "class_field_def" ],
    [ "FSRecordBaseFields", "class_f_s_record_base_fields.html", "class_f_s_record_base_fields" ],
    [ "DOUBLE_MAX", "_f_s_record_base_fields_8h.html#a4a7fa8631f9ee0ad0dbf5b680dbdb707", null ],
    [ "DOUBLE_MIN", "_f_s_record_base_fields_8h.html#a526639fcb172e9377c68fc180820269d", null ],
    [ "FLOAT_MAX", "_f_s_record_base_fields_8h.html#a2124ca619b2968b0cc8429e2a7036869", null ],
    [ "FLOAT_MIN", "_f_s_record_base_fields_8h.html#af5950268eabe03299763ca25bc35d33d", null ],
    [ "QINT32_MAX", "_f_s_record_base_fields_8h.html#a0921f531fa9180a783050dd9a2371945", null ],
    [ "QINT32_MIN", "_f_s_record_base_fields_8h.html#a871b3a7fa6deedd6146efb11b7ef9859", null ],
    [ "QINT64_MAX", "_f_s_record_base_fields_8h.html#a705d9a183528df9e2c7e654a5ad77ee2", null ],
    [ "QINT64_MIN", "_f_s_record_base_fields_8h.html#a8f99896920da7f2cffe5f26e924817da", null ],
    [ "QSTRING", "_f_s_record_base_fields_8h.html#a61a49369a2011d22974ec31dea32fd2f", null ],
    [ "QUINT32_MAX", "_f_s_record_base_fields_8h.html#a9b5b79f1c92ae5d08132a0514152560d", null ],
    [ "QUINT32_MIN", "_f_s_record_base_fields_8h.html#a1ae8b94edf7e83fd624072fa33c40d2a", null ],
    [ "QUINT64_MAX", "_f_s_record_base_fields_8h.html#ac54095682b04fbc33388d3ac48bd6710", null ],
    [ "QUINT64_MIN", "_f_s_record_base_fields_8h.html#ae0e9d8c05dec18a75e68878a2a021482", null ],
    [ "MinMaxType", "_f_s_record_base_fields_8h.html#adf8d87aa76367ac3d8b4d5c63687972f", [
      [ "eMinMaxInt", "_f_s_record_base_fields_8h.html#adf8d87aa76367ac3d8b4d5c63687972fa5760dcc98d6041f3c79ab5f0f6c0c9ac", null ],
      [ "eMinMaxFloat", "_f_s_record_base_fields_8h.html#adf8d87aa76367ac3d8b4d5c63687972fa8c1834ebf9de6cf176987198ed3b647a", null ],
      [ "eMinMaxDouble", "_f_s_record_base_fields_8h.html#adf8d87aa76367ac3d8b4d5c63687972fa822f7f42f2bb790613196072cac40356", null ]
    ] ]
];