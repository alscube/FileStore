var searchData=
[
  ['newrecord_232',['NewRecord',['../class_f_s_file_base.html#a505e010f1d1bbe1dfb65654d8b092b7f',1,'FSFileBase::NewRecord()'],['../class_f_s_b_tree_file.html#a2fbc0f809159074a5584d7cb3e62cbe6',1,'FSBTreeFile::NewRecord()']]],
  ['no_5fchild_233',['NO_CHILD',['../_f_s_b_tree_file_8h.html#a53f831f4e9e3fcb833d53dd7ae6b1ccc',1,'FSBTreeFile.h']]],
  ['no_5ffile_5fid_234',['NO_FILE_ID',['../_f_s_global_types_8h.html#a302e870f61469167d0391c1c2ed9fb2f',1,'FSGlobalTypes.h']]],
  ['no_5ffile_5ftype_235',['NO_FILE_TYPE',['../_f_s_global_types_8h.html#a26d878fff368eb1d6741aa0bce6157de',1,'FSGlobalTypes.h']]],
  ['no_5fpermissions_5ffor_5ffile_236',['NO_PERMISSIONS_FOR_FILE',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a71e45ff885895a60a9412cc7bd71bb90',1,'FSResultCodes.h']]],
  ['no_5frec_5fid_237',['NO_REC_ID',['../_f_s_global_types_8h.html#a7778e2faa2babe0e93654cfdfdf2bd49',1,'FSGlobalTypes.h']]],
  ['no_5frecords_5fin_5ffile_238',['NO_RECORDS_IN_FILE',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a066ae3bd819ba19f0039234f8a7aeea1',1,'FSResultCodes.h']]],
  ['no_5fvalue_5fset_239',['NO_VALUE_SET',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a0141a9a73fe469077b5c2b41892fccf6',1,'FSResultCodes.h']]],
  ['not_5fimplemented_240',['NOT_IMPLEMENTED',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a12bcc9d9958a22b983e65f77f3faf90b',1,'FSResultCodes.h']]]
];
