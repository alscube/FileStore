
// FSResultCodesCore.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QtGlobal>
#include <QStringList>

#include "FSLibExport.h"


#ifndef DELETE
#define DELETE( x ) \
		  delete x; \
		  x = nullptr
#endif

#define ResultValue int

#define SUCCESS 0


// SINGLETON

class LIB_EXPORT FSResultCodesCore
{
public:
		// return instance of this singleton
    static FSResultCodesCore* Instance();

		// return the offset for the next collection
	int ResultOffset( );

		// add a code string for from a collecton
	void AddCode( const QString& codeString );

		// return a string version of a code
	const QString& CodeString( int resultCode );

private:
    static FSResultCodesCore* s_Instance;

    FSResultCodesCore( );

	QStringList _ResultCodeStrings;
};
