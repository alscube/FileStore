
#include "BTreeTestUtils.h"

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include <QTest>

#include <QDir>
#include <QList>

#include "BTreeFileTestFile.h"

static FILE_ID BTREE_TEST_FILE_ID = 100;



BTreeTestUtils::BTreeTestUtils()
{
	QString sep = QDir::separator();
	m_PathToFile = QDir::homePath();
    m_PathToFile += sep+"FileStore_Test"+sep;
	m_FileName = m_PathToFile + "btreetest";

	DeleteFile( );
}


void BTreeTestUtils::DeleteFile( )
{
	QDir dir;
	if ( dir.exists( m_FileName ) )
	{
		dir.remove( m_FileName );
	}
	else
	{	// or make directory if it does not exist
		dir.mkpath( m_PathToFile );
	}
}



void BTreeTestUtils::InsertTopRecord( BTreeFileTestFile& FSBTreeFile )
{
	BTreeFileTestRecord rec;
	ResultValue result = rec.SetKey( 1000 );
	QCOMPARE( result, SUCCESS );

	result = rec.SetValue( 1000 );
	QCOMPARE( result, SUCCESS );

	result = FSBTreeFile.Insert( rec );
    QCOMPARE( result, SUCCESS );

//    if ( result != FS_CODE(FILE_NOT_OPEN) )
//        QCOMPARE( result, SUCCESS );
//    else
//        QFAIL( "FILE_NOT_OPEN" );
}


void BTreeTestUtils::resetAndInsertTopRecord( BTreeFileTestFile& FSBTreeFile )
{
	DeleteFile();

//    FSBTreeFile.SetFileName( m_FileName );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, true, 0 );
	QCOMPARE( result, SUCCESS );

	InsertTopRecord( FSBTreeFile );
}



// static
QList<int> BTreeTestUtils::leftKey = QList<int>() << 500 << 400 << 300;
QList<int> BTreeTestUtils::leftValue = QList<int>() << 3536 << 3540 << 1625;

void BTreeTestUtils::InsertLeftRecord( BTreeFileTestFile &FSBTreeFile, int index )
{
	BTreeFileTestRecord rec;
	ResultValue result = rec.SetKey( leftKey[index] );
	QCOMPARE( result, SUCCESS );

	result = rec.SetValue( leftValue[index] );
	QCOMPARE( result, SUCCESS );

	result = FSBTreeFile.Insert( rec );
	QCOMPARE( result, SUCCESS );
}


// static
QList<int> BTreeTestUtils::rightKey = QList<int>() << 1500 << 1600 << 1700;
QList<int> BTreeTestUtils::rightValue = QList<int>() << 4536 << 35 << 6538;

void BTreeTestUtils::InsertRightRecord( BTreeFileTestFile &FSBTreeFile, int index )
{
	BTreeFileTestRecord rec;
	ResultValue result = rec.SetKey( rightKey[index] );
	QCOMPARE( result, SUCCESS );

	result = rec.SetValue( rightValue[index] );
	QCOMPARE( result, SUCCESS );

	result = FSBTreeFile.Insert( rec );
	QCOMPARE( result, SUCCESS );
}


// static
//QList<int> BTreeTestUtils::leftKeyEx = QList<int>() << 505 << 1186 << 936 << 2048 << 589 << 924;
//QList<int> BTreeTestUtils::leftValueEx = QList<int>() << 1001 << 1002 << 1003 << 1004 << 1005 << 1006;

//void BTreeTestUtils::InsertLeftRecordEx( BTreeFileTestFile &FSBTreeFile, int index )
//{
////    qDebug() << leftKeyEx[index];

//    BTreeFileTestRecord rec;
//    ResultValue result = rec.SetKey( leftKeyEx[index] );
//    QCOMPARE( result, SUCCESS );

//    result = rec.SetValue( leftValueEx[index] );
//    QCOMPARE( result, SUCCESS );

//    result = FSBTreeFile.Insert( rec );
//    QCOMPARE( result, SUCCESS );
//}


// static
//QList<int> BTreeTestUtils::rightKeyEx = QList<int>() << 1500 << 1600 << 1550 << 1650 << 1575 << 1700;
//QList<int> BTreeTestUtils::rightValueEx = QList<int>() << 536 << 35 << 58 << 67 << 77 << 33;

//void BTreeTestUtils::InsertRightRecordEx( BTreeFileTestFile &FSBTreeFile, int index )
//{
//    BTreeFileTestRecord rec;
//    ResultValue result = rec.SetKey( rightKeyEx[index] );
//    QCOMPARE( result, SUCCESS );

//    result = rec.SetValue( rightValueEx[index] );
//    QCOMPARE( result, SUCCESS );

//    result = FSBTreeFile.Insert( rec );
//    QCOMPARE( result, SUCCESS );
//}


void BTreeTestUtils::DumpAllRecords( BTreeFileTestFile& FSBTreeFile, bool dumpDetails )
{
	QDebug dbg = qDebug();
	dbg << "  ";

	ResultValue result = SUCCESS;
	FSBTreeFile.SetReadNextRecordIndex( 0 );
	do {
		BTreeFileTestRecord rec;
		result = FSBTreeFile.ReadNext( rec );
		if ( result == SUCCESS )
		{
			if ( dumpDetails )
				dbg << "[" << rec.GetRecordID() << rec.GetKey() << rec.GetParent()
					<< rec.GetChildOnLeft() << rec.GetChildOnRight() << rec.GetPrev() << rec.GetNext() << "]";
			else
				dbg << rec.GetKey();
		}
	} while( result == SUCCESS );

	if ( result != FS_CODE(READ_PAST_END_OF_FILE) )
		QFAIL( "Error reading NextRecord" );
}


void BTreeTestUtils::TestTreeFromLeft( BTreeFileTestFile& FSBTreeFile, bool showKeys )
{
	int recCount = FSBTreeFile.GetHeaderFileActiveRecordCount();

	BTreeFileTestRecord rec;

	try {
		FSBTreeFile.GetTopRecord( rec );

			// get left most leaf then 'move right'
		ResultValue result = FSBTreeFile.GetLeftMostRecord( rec );
		if ( result != FS_CODE(LEFT_MOST_RECORD) )
			return;

		int count = DumpLeftToRight( FSBTreeFile, rec, showKeys );

		QCOMPARE( count, recCount );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeTestUtils::TestTreeFromRight( BTreeFileTestFile& FSBTreeFile, bool showKeys )
{
	int recCount = FSBTreeFile.GetHeaderFileActiveRecordCount();

	BTreeFileTestRecord rec;
	try {
		FSBTreeFile.GetTopRecord( rec );

			// get right most leaf then 'move left'
		ResultValue result = FSBTreeFile.GetRightMostRecord( rec );
		if ( result != FS_CODE(RIGHT_MOST_RECORD) )
			return;

		int count = DumpRightToLeft( FSBTreeFile, rec, showKeys );

		QCOMPARE( count, recCount );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeTestUtils::DumpSideOfTree( BTreeFileTestFile& FSBTreeFile, int key )
{
	BTreeFileTestRecord rec;
	try {
		FSBTreeFile.GetTopRecord( rec );

		int recKey = rec.GetKey();
		if ( key > recKey )
			DumpLeftToRight( FSBTreeFile, rec, true );
		else
			DumpRightToLeft( FSBTreeFile, rec, true );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

}


int BTreeTestUtils::DumpRightToLeft( BTreeFileTestFile& FSBTreeFile, BTreeFileTestRecord &rec, bool showKeys )
{
	// given a starting position, dump tree from right to left

	int recCount = 0;
	int prevValue = rec.GetKey();
	ResultValue result = SUCCESS;

	if ( showKeys )
	{
		QDebug dbg = qDebug();
		dbg << "  ";

		while ( result != FS_CODE(FIRST_RECORD_IN_INDEX) )
		{
			recCount++;
			dbg << "[" << rec.GetRecordID() << rec.GetKey() << rec.GetParent()
				<< rec.GetChildOnLeft() << rec.GetChildOnRight()
				<< rec.GetPrev() << rec.GetNext() << "]";
			// dbg << rec.GetKey() << rec.GetDuplicateID();
			Q_ASSERT( rec.GetKey() <= prevValue );
			prevValue = rec.GetKey();
			result = FSBTreeFile.GetPreviousRecord( rec );
		}
	}
	else
	{
		while ( result != FS_CODE(FIRST_RECORD_IN_INDEX) )
		{
			recCount++;
			Q_ASSERT( rec.GetKey() <= prevValue );
			prevValue = rec.GetKey();
			result = FSBTreeFile.GetPreviousRecord( rec );
		}
	}

	return recCount;
}


int BTreeTestUtils::DumpLeftToRight( BTreeFileTestFile& FSBTreeFile, BTreeFileTestRecord& rec, bool showKeys )
{
	// given a starting position, dump tree from left to right

	int recCount = 0;
	int prevValue = rec.GetKey();
	ResultValue result = SUCCESS;

	if ( showKeys )
	{
		QDebug dbg = qDebug();
		dbg << "\n  D K P L R B ";

		while ( result != FS_CODE(LAST_RECORD_IN_INDEX) )
		{
			recCount++;
			dbg << "[" << rec.GetRecordID() << rec.GetKey() << rec.GetParent()
				<< rec.GetChildOnLeft() << rec.GetChildOnRight() << rec.GetBalance() << "]";
			Q_ASSERT( rec.GetKey() >= prevValue );
			prevValue = rec.GetKey();
			result = FSBTreeFile.GetNextRecord( rec );
		}
	}
	else
	{
		while ( result != FS_CODE(LAST_RECORD_IN_INDEX) )
		{
			recCount++;
			Q_ASSERT( rec.GetKey() >= prevValue );
			prevValue = rec.GetKey();
			result = FSBTreeFile.GetNextRecord( rec );
		}
	}

	return recCount;
}


void BTreeTestUtils::PrintSideOfTree( BTreeFileTestFile& FSBTreeFile, int value )
{
	try {
		BTreeFileTestRecord rec;
		FSBTreeFile.GetTopRecord( rec );

		int recValue = rec.GetValue();
		int nextRecordID = ( value > recValue ) ? rec.GetChildOnRight() : rec.GetChildOnLeft();

        BTreeFileTestRecord childRec( nextRecordID );
//		rec.ResetRecord( nextRecordID );
        FSBTreeFile.ReadT( childRec );
        printTree( FSBTreeFile, childRec );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeTestUtils::printTree( BTreeFileTestFile& FSBTreeFile, BTreeFileTestRecord& rec )
{
	int recordID = -1;
	try {
		QList<int> parents;
		QList<int> *parentPtr = &parents;
		QList<int> children;
		QList<int> *childrenPtr = &children;
		QList<int> *temp;

		parents.append( rec.GetKey() );
		parents.append( rec.GetValue() );

		children.append( rec.GetKey() );
		children.append( rec.GetValue() );
		children.append( rec.GetChildOnLeft() );
		children.append( rec.GetChildOnRight() );

		while( true )
		{
			qDebug() << *parentPtr;

			bool allBlank = true;
			temp = parentPtr;
			parentPtr = childrenPtr;
			childrenPtr = temp;

			childrenPtr->clear();

			for ( int i=0; i<parentPtr->count(); i++ )
			{
				if ( i % 4 == 0 )
					i+=2;
				recordID = parentPtr->at( i );
				if ( recordID != -1 )
				{
					allBlank = false;
					BTreeFileTestRecord rec( recordID );
					FSBTreeFile.ReadT( rec );
					childrenPtr->append( rec.GetKey() );
					childrenPtr->append( rec.GetValue() );
					childrenPtr->append( rec.GetChildOnLeft() );
					childrenPtr->append( rec.GetChildOnRight() );
				}
				else
				{
					childrenPtr->append( 98 );
					childrenPtr->append( 99 );
					childrenPtr->append( -1 );
					childrenPtr->append( -1 );
				}
			}

			if ( allBlank)
				break;

		} // while
	}
	catch( FSResultException* ex )
	{
        ResultValue result = ex->ResultCode();
		delete ex;
		qDebug() << "Exception" << recordID << result;
		Q_ASSERT( result );
	}
}

