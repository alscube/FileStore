
// BTreeFileTestRecord.cpp

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license



#include "BTreeFileTestRecord.h"

#include <QVariant>
#include <QString>


#define BTREE_FILE_ID 10
#define BTREE_FILE_TYPE 10

// static
BTreeTestRecordFields BTreeFileTestRecord::m_TestFields = BTreeTestRecordFields( );


BTreeFileTestRecord::BTreeFileTestRecord( int recordId )
	: FSBTreeRecord( recordId )
	, m_Key( -1 )
	, m_Value( -1 )
{
	SetFileID( BTREE_FILE_ID );
	SetFileType( BTREE_FILE_TYPE );
}


ResultValue BTreeFileTestRecord::GetField( int fieldNum, QVariant& outValue )
{
	switch ( fieldNum )
	{
		case fKey :
			outValue = QVariant( GetKey() );
			break;
		case fValue :
			outValue = QVariant( GetValue() );
			break;
		default :
			return FSBTreeRecord::GetField( fieldNum, outValue );
	}

	return SUCCESS;
}


ResultValue BTreeFileTestRecord::SetKey( int key )
{
	ResultValue result = Validate( key, m_TestFields[fKey] );
	if ( result == SUCCESS )
	{
		m_Key = key;
		SetModified( );
	}
	return result;
}


ResultValue BTreeFileTestRecord::SetValue( int recordIndex )
{
	ResultValue result = Validate( recordIndex, m_TestFields[fValue] );
	if ( result == SUCCESS )
	{
		m_Value = recordIndex;
		SetModified( );
	}

	return result;
}


eCOMPARE_RESULT BTreeFileTestRecord::CompareRecords( FSBTreeRecord& compareToRec, bool compareDup )
{
	QVariant var;
	ResultValue result = compareToRec.GetField( fKey, var );
	if ( result != SUCCESS )
		return UnexpectedError;

	int nextKey = var.toInt();      // var.toInt( ok );  Q_ASSERT( ok );

	int key = GetKey();

	if ( key < nextKey )
		return CompareLessThan;

	if ( key > nextKey )
		return CompareGreaterThan;

	if ( compareDup )
	{
		int dupID = this->GetDuplicateID();

		result = compareToRec.GetField( fDuplicateID, var );
		if ( result != SUCCESS )
		   return UnexpectedError;

		int compDupID = var.toInt();    // var.toInt( ok );  Q_ASSERT( ok );

		if ( dupID < compDupID )
			return CompareLessThan;

		if ( dupID > compDupID )
			return CompareGreaterThan;
	}

	return CompareEqual;
}


//FSBTreeRecord* BTreeFileTestRecord::operator=( FSBTreeRecord* rec )
//{
//	BTreeFileTestRecord* source = (BTreeFileTestRecord*)rec;

//	this->SetIndexedID( source->GetIndexedID() );
//	this->SetIndexedRecordID( source->GetIndexedRecordID() );

//	return this;
//}


