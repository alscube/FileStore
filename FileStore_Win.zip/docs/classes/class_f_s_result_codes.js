var class_f_s_result_codes =
[
    [ "CodeString", "class_f_s_result_codes.html#ae627cc71916b49a9b85f8cb6c790c059", null ],
    [ "Offset", "class_f_s_result_codes.html#aa3b96e93e288689518e915863a637254", null ]
];