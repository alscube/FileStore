
// TestRecord.cpp

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


// This record is used to test the base functionality of the BaseRecord
// and not a particular record for the File Store.

#include "TestRecord.h"

#include <QVariant>


// static
TestRecordFields TestRecord::_Fields = TestRecordFields();


TestRecord::TestRecord( int recordId, FSFileBase* FSFileBase )
	: FSRecordBase( recordId, FSFileBase )
    , _Boolean( false )
    , _ZipCode( -1 )
    , _AreaCode( -1 )
    , _Income( 0.0 )
    , _OtherIncome( 0.0 )
    , _LimitDouble( 0.0 )
{
}


ResultValue TestRecord::SetName( const QString& name )
{
    return ValidateField( _Name, name, fName );
}


void TestRecord::SetBoolean( bool b )
{
    FSRecordBase::ValidateFieldT( _Boolean, b, fBoolean );
}

ResultValue TestRecord::SetAddress( const QString& address )
{
    return ValidateField( _Address, address, fAddress );
}

ResultValue TestRecord::SetZipCode( int zipCode )
{
    return ValidateField( _ZipCode, zipCode, fZipCode );
}

ResultValue TestRecord::SetAreaCode( int areaCode )
{
    return ValidateField( _AreaCode, areaCode, fAreaCode );
}

ResultValue TestRecord::SetPhoneNumber( const QString& phoneNumber )
{
    return ValidateField( _PhoneNumber, phoneNumber, fPhoneNumber );
}

ResultValue TestRecord::SetIncome( float income )
{
    return ValidateField( _Income, income, fIncome );
}

ResultValue TestRecord::SetOtherIncome( double otherIncome )
{
    return ValidateField( _OtherIncome, otherIncome, fOtherIncome );
}

ResultValue TestRecord::SetLimitDouble( double value )
{
    return ValidateField( _LimitDouble, value, fLimitDouble );
}


const FieldDef* TestRecord::GetFieldDefinition( int fieldNum )
{
	if ( fieldNum < 0 || fieldNum >= _Fields.GetFieldCount() )
		return nullptr;

	return _Fields[fieldNum];
}


ResultValue TestRecord::GetFieldValue( int fieldNum, QVariant& outValue )
{
	switch ( fieldNum )
	{
		case fName :
			outValue = QVariant( GetName() );
			break;
        case fBoolean :
            outValue = QVariant( GetBoolean() );
            break;
		case fAddress :
			outValue = QVariant( GetAddress() );
			break;
		case fZipCode :
			outValue = QVariant( GetZipCode() );
			break;
		case fAreaCode :
			outValue = QVariant( GetAreaCode() );
			break;
		case fPhoneNumber :
			outValue = QVariant( GetPhoneNumber() );
			break;
		case fIncome :
			outValue = QVariant( GetIncome() );
			break;
		case fOtherIncome :
			outValue = QVariant( GetOtherIncome() );
            break;
        case fLimitDouble :
            outValue = QVariant( GetLimitDouble() );
            break;
        default :
            return FSRecordBase::GetFieldValue( fieldNum, outValue );
	}
	return SUCCESS;
}


ResultValue TestRecord::SetFieldValue( int fieldNum, QVariant& inValue )
{
	ResultValue result = SUCCESS;

	switch( fieldNum )
	{
		case fName :
			{
			QString value = inValue.toString();
			result = SetName( value );
			}
			break;
		case fAddress :
			break;
		case fZipCode :
			break;
		case fAreaCode :
			break;
		case fPhoneNumber :
			break;
		case fIncome :
			break;
		case fOtherIncome :
			break;
        case fLimitDouble :
            break;
        default :
			result = FIELD_NOT_FOUND_IN_RECORD;
	}

	return result;
}


void TestRecord::ClearRecord( REC_ID recordID )
{
    FSRecordBase::ResetRecord( recordID );

    _Name.clear();
    _Boolean = false;
    _Address.clear();
    _ZipCode = -1;
    _AreaCode = -1;
    _PhoneNumber.clear();
    _Income = 0.0;
    _OtherIncome = 0.0;
    _LimitDouble = 0.0;
}



// PROTECTED
ResultValue TestRecord::_ReadFields( QDataStream& dataStream )
{

    dataStream >> _Name >> _Boolean >> _ZipCode >> _AreaCode >> _PhoneNumber >> _Address >> _Income >> _OtherIncome >> _LimitDouble;
	return SUCCESS;
}


// PROTECTED
ResultValue TestRecord::_WriteFields( QDataStream& dataStream )
{
    dataStream << _Name << _Boolean << _ZipCode << _AreaCode << _PhoneNumber << _Address << _Income << _OtherIncome << _LimitDouble;
	return SUCCESS;
}


// Exposed for internal testing
ResultValue TestRecord::ValidateField( QString& field, const QString& value, int fieldEnum )
{
    return FSRecordBase::ValidateField( field, value, fieldEnum );
}

ResultValue TestRecord::ValidateField( bool& field, const bool value, int fieldEnum )
{
    return FSRecordBase::ValidateField( field, value, fieldEnum );
}

ResultValue TestRecord::ValidateField( INT32& field, const INT32 value, int fieldEnum )
{
    return FSRecordBase::ValidateField( field, value, fieldEnum );
}

ResultValue TestRecord::ValidateField( float& field, const float value, int fieldEnum )
{
    return FSRecordBase::ValidateField( field, value, fieldEnum );
}

ResultValue TestRecord::ValidateField( double& field, const double value, int fieldEnum )
{
    return FSRecordBase::ValidateField( field, value, fieldEnum );
}

void TestRecord::ValidateFieldT( QString& field, const QString& value, int fieldEnum )
{
    FSRecordBase::ValidateFieldT( field, value, fieldEnum );
}

void TestRecord::ValidateFieldT( bool& field, const bool value, int fieldEnum )
{
    FSRecordBase::ValidateFieldT( field, value, fieldEnum );
}

void TestRecord::ValidateFieldT( INT32& field, const INT32 value, int fieldEnum )
{
    FSRecordBase::ValidateFieldT( field, value, fieldEnum );
}

void TestRecord::ValidateFieldT( float& field, const float value, int fieldEnum )
{
    FSRecordBase::ValidateFieldT( field, value, fieldEnum );
}

void TestRecord::ValidateFieldT( double& field, const double value, int fieldEnum )
{
    FSRecordBase::ValidateFieldT( field, value, fieldEnum );
}

