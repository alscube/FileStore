var struct_field_def =
[
    [ "FieldMax", "struct_field_def.html#a490388d93db49e00c6ff5e25f80ffbd7", null ],
    [ "FieldMin", "struct_field_def.html#a891428cb32c922b97ac82fca826ee6b1", null ],
    [ "FieldName", "struct_field_def.html#a8b03b6a641329785b98bcaeaac22768c", null ],
    [ "StorageSize", "struct_field_def.html#a2be03e33b840eca522ce626fdbb6bd0e", null ]
];