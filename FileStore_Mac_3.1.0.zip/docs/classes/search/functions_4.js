var searchData=
[
  ['delete_369',['Delete',['../class_file_base.html#a6aaff449c0528e01182052ada5f52eab',1,'FileBase::Delete()'],['../class_b_tree_file.html#ac0fde2dd4e15bf427a2a7ca4c9199f39',1,'BTreeFile::Delete()']]],
  ['deletedrecord_370',['DeletedRecord',['../class_deleted_record.html#a46759f5d68fcfdfe1875d312dbfd36e3',1,'DeletedRecord::DeletedRecord(REC_ID recordId=NO_REC_ID)'],['../class_deleted_record.html#a3195ede1e6513a34e5f93a8dd977b13c',1,'DeletedRecord::DeletedRecord(REC_ID recordId, REC_ID prevRecord, REC_ID nextRecord)']]],
  ['deletefile_371',['DeleteFile',['../class_file_base.html#ae2b239d4b8812b5442c3a73de2894acd',1,'FileBase']]],
  ['deletet_372',['DeleteT',['../class_file_base.html#a64b9589a7f5376c6507d287de0d04a59',1,'FileBase']]],
  ['duplicatesallowed_373',['duplicatesAllowed',['../class_b_tree_file.html#ab8fb60d99fe53b1a41dddcec957212e9',1,'BTreeFile']]]
];
