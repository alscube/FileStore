var searchData=
[
  ['newrecord_0',['newrecord',['../class_f_s_file_base.html#a505e010f1d1bbe1dfb65654d8b092b7f',1,'FSFileBase::NewRecord()'],['../class_f_s_b_tree_file.html#a2fbc0f809159074a5584d7cb3e62cbe6',1,'FSBTreeFile::NewRecord()']]]
];
