﻿
// ResultException.h

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QString>
#include <QFile>
#include <QDebug>
#include "ResultCodes.h"

/*! \file ResultException.cpp */

/*!
 * Creates and throws a new ResultException without a message.
 *
 * The result value passed in should be the result value plus the result offset.
 *
 * \sa ResultCodes
 */
#define THROW_RESULT(result) throw \
    (new ResultException( __FILE__, __FUNCTION__, __LINE__, result ))


/*!
 *  Creates and throws a new ResultException with a message
 *
 * The result value passed in should be the result value plus the result offset.
 *
 * \sa ResultCodes
 */
#define THROW_RESULT_MSG(result, errstr) throw \
    (new ResultException( __FILE__, __FUNCTION__, __LINE__, result, errstr ))


/*!
 * Used like an IF statement to test a result exception for a particular result value plus result offset.
 *
 *      IF_RESULT_EQUALS( ex, FS_CODE(FILESTORE_ALREADY_EXISTS) )
 *          MessageBox("there was an error");
 *
 * This macro does not delete the exception thrown.
 */
#define IF_RESULT_EQUALS(except,result) \
    ResultValue resultCode = except->ResultCode( ); \
	if ( resultCode == result )


/*!
 * Used like and IF statement to test a result exception for a particular result value plus result offset.
 *
 *      IF_RESULT_EQUALS_X( ex, FS_CODE(FILESTORE_ALREADY_EXISTS) )
 *          MessageBox("there was an error");
 *
 * This macro deletes the exception thrown.
 */
#define IF_RESULT_EQUALS_X(except,result) \
    ResultValue resultCode = except->ResultCode( ); \
	delete except; \
	if ( resultCode == result )



/*!
 * Used like a negative IF statement to test a result exception for a particular result value plus result offset.
 *
 *      IF_RESULT_NOT_EQUALS( ex, FS_CODE(FILESTORE_ALREADY_EXISTS) )
 *          MessageBox("there was an error");
 *
 * This macro does not delete the exception thrown.
 */
#define IF_RESULT_NOT_EQUALS(except,result) \
    ResultValue resultCode = except->ResultCode( ); \
    if ( resultCode != result )


/*!
 * Used like a negative IF statement to test a result exception for a particular result value plus result offset.
 *
 *      IF_RESULT_NOT_EQUALS_X( ex, FS_CODE(FILESTORE_ALREADY_EXISTS) )
 *          MessageBox("there was an error");
 *
 * This macro deletes the exception thrown.
 */
#define IF_RESULT_NOT_EQUALS_X(except,result) \
    ResultValue resultCode = except->ResultCode( ); \
	delete except; \
	if ( resultCode != result )


/*!
 * Returns the result value out of a thrown exception.
 *
 *      ResultValue result = RETURN_RESULT( exception );
 *
 * This macro does not delete the exception thrown.
 */
#define RETURN_RESULT(except) \
    ResultValue result = except->ResultCode( ); \
    return result


/*!
 * Returns the result value out of a thrown exception.
 *
 *      ResultValue result = RETURN_RESULT_X( exception );
 *
 * This macro deletes the exception thrown.
 */
#define RETURN_RESULT_X(except) \
    ResultValue result = except->ResultCode( ); \
    delete except; \
    return result

/*!
 *  Called to delete a thrown exception.
 *
 *      DELETE_EXCEPTION( exception );
 */
#define DELETE_EXCEPTION(except) delete \
    except



/*!
 * Extract result value and compare for SUCCESS.
 *
 * Used like a Q_ASSERT, throws an exception if the result is not SUCCESS.  Through QDebug it will
 * also print out the function, line, and result value.
 *
 *      TEST_RESULT( exception );
 *
 * This macro deletes the exception thrown.
 */
#define TEST_RESULT(except) ResultValue result = except->ResultCode( ); \
                                if ( result != 0 ) \
                                { \
                                    qDebug() << except->FunctionName() \
                                        << "line:" << except->FunctionLine() \
                                        << "code:" << result << ResultCodes::Instance()->CodeString(result); \
                                } \
                                delete except; \
                                QCOMPARE( result, 0 ) // SUCCESS


/*!
 * Extract result value and compare to user value.
 *
 * Used like a Q_ASSERT, throws an exception if the result does not match.  Through QDebug it will
 * also print out the function, line, and result value.
 *
 *      COMPARE_RESULT( exception, user_result_code );
 *
 * This macro deletes the exception thrown.
 */
#define COMPARE_RESULT(except, compare) ResultValue result = except->ResultCode( ); \
										if ( result != compare ) \
										{ \
                                            qDebug() << except->FileName() << ":" \
                                                     << except->FunctionName() << ":" \
                                                     << except->FunctionLine() << "-" \
													 << "(" << result << ")" \
                                                     << ResultCodes::Instance()->CodeString(result); \
										} \
										delete except; \
										QCOMPARE( result, compare )


class QFile;
class QTextStream;

class ResultException
{
public:
	ResultException( const char* fileName,
					 const char* functionName,
					 int functionLine,
					 ResultValue result,
					 const QString& msg = nullptr );

	~ResultException( );

        // Name of file that where exception happened
    QString FileName( );

        // Name of function where exception happened
    const QString& FunctionName( );

        // Code line where exception happened
    int FunctionLine( );

        // ResultCode assigned when the exception occured
    ResultValue ResultCode( );

        // String version of the ResultCode
    const QString& ResultCodeString( );


private:
    void LogError( );

private:

    QString    _fileName;       // nane of file where exception occured
	QString    _functionName;
	int        _functionLine;
	ResultValue  _resultCode;
	QString    _messageStr;
};





