var _global_types_8h =
[
    [ "DATE", "_global_types_8h.html#a30b328ca499f27b3d0f8111b495834ca", null ],
    [ "FILE_ID", "_global_types_8h.html#a39865ae8ff0dc855422390df3b2c36b7", null ],
    [ "FILE_TYPE", "_global_types_8h.html#afe9af64ddff174e1b6e96db45b8f78fb", null ],
    [ "ID", "_global_types_8h.html#a77ceac8d6af195fe72f95f6afd87c45e", null ],
    [ "NO_FILE_ID", "_global_types_8h.html#a302e870f61469167d0391c1c2ed9fb2f", null ],
    [ "NO_FILE_TYPE", "_global_types_8h.html#a26d878fff368eb1d6741aa0bce6157de", null ],
    [ "NO_REC_ID", "_global_types_8h.html#a7778e2faa2babe0e93654cfdfdf2bd49", null ],
    [ "REC_ID", "_global_types_8h.html#a856855f029c5e23bdc667098dc089978", null ]
];