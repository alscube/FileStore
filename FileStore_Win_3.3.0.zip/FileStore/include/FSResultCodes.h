
// FSResultCodes.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FSResultCodesCore.h"
#include <QStringList>
#include "FSLibExport.h"


// Keep the s_CodeStrings list in the same order as this

enum FS_RESULT_CODES
{
	  FILE_NAME_NOT_SET         // 0
	, FILE_ALREADY_EXISTS
	, FILE_IS_OPEN
	, FILE_NOT_OPEN
	, FILE_NOT_FOUND
	, UNABLE_TO_CREATE_FILE
	, UNABLE_TO_DELETE_FILE
	, UNABLE_TO_OPEN_FILE
	, INVALID_FILE_TYPE
	, INVALID_FILE_ID
	, INVALID_RECORD_SIZE       // 10
	, INVALID_FILE_SIZE
	, INVALID_HEADER_SIZE
	, INVALID_HEADER
	, INVALID_FILE_VERSION
	, NO_PERMISSIONS_FOR_FILE

	, FILE_OBJECT_NOT_SET
	, NOT_IMPLEMENTED
	, FILE_TYPE_DOES_NOT_MATCH
	, SEEK_FAILED
	, READ_PAST_END_OF_FILE     // 20
	, ERROR_READING_FILE
	, ERROR_WRITING_FILE
	, INVALID_RECORD
	, INVALID_RECORD_ID
	, INVALID_RECORD_OBJECT
	, FAILED_TO_FLUSH_DATA_BUFFER
	, FIELD_NOT_FOUND_IN_RECORD
    , UNKNOWN_FIELD
	, DATA_TO_SMALL
    , DATA_TO_LARGE             // 30
    , NO_VALUE_SET
    , UNEXPECTED_DATA_VALUE

	, RECORD_INSERTED
	, RECORD_ALREADY_INSERTED
	, RECORD_ALREADY_DELETED
	, RECORD_WAS_DELETED
	, RECORD_NOT_FOUND
	, NO_RECORDS_IN_FILE
	, RECORD_ID_ALREADY_SET

		// BTree
    , TOP_RECORD_NOT_SET        // 40
    , FIRST_RECORD_IN_INDEX		//      First record in the entire tree
    , LAST_RECORD_IN_INDEX		//      Last record in the entire tree
	, LEFT_MOST_RECORD			//      Left most for the branch
	, RIGHT_MOST_RECORD			//      Right most for the branch

	, INVALID_RECORD_LINKS
	, INVALID_PARENT_CHILD_LINK

	, DUPLIATE_KEY_DETECTED
	, DUPLICATE_ENTRIES_NOT_ALLOWED

	, FS_UNEXPECTED_FAILURE

		// File Device errors
    , FILE_DEVICE_ERROR_READING_FILE    // 50
    , FILE_DEVICE_ERROR_WRITING_FILE
    , FILE_DEVICE_UNABLE_TO_OPEN_FILE
	, FILE_DEVICE_SEEK_FAILED
	, FILE_DEVICE_NO_PERMISSIONS_FOR_FILE
	, FILE_DEVICE_UNSPECIFIED_ERROR

	, FS_RESULT_CODE_LAST	// always last
};


#define FS_CODE(code)  code+FSResultCodes::Instance()->Offset()

// Encapsulates the FileStore result codes.   Result codes can be
// returned as a ResultValue or thrown in an exception.
//
// Use FS_CODE(<code>) to get the correct code offset.
// ie:  resultValue == FS_CODE(FILE_NOT_FOUND)
//

class LIB_EXPORT FSResultCodes
{
public:
    static FSResultCodes* Instance( );

		// returns the offset to these codes
	int Offset( );

	const QString& CodeString( int fsResultValue );

private:
		// this class instance
    static FSResultCodes* s_Instance;

        // offset to these codes in the FSResultCodesCore collection
	static int s_ResultOffset;

		// list of result code strings for this result collection
	static QStringList s_CodeStrings;

    FSResultCodes( );
};

