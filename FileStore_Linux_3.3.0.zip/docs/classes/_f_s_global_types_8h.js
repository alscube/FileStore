var _f_s_global_types_8h =
[
    [ "DATE", "_f_s_global_types_8h.html#a30b328ca499f27b3d0f8111b495834ca", null ],
    [ "FILE_ID", "_f_s_global_types_8h.html#a39865ae8ff0dc855422390df3b2c36b7", null ],
    [ "FILE_TYPE", "_f_s_global_types_8h.html#afe9af64ddff174e1b6e96db45b8f78fb", null ],
    [ "ID", "_f_s_global_types_8h.html#a77ceac8d6af195fe72f95f6afd87c45e", null ],
    [ "NO_FILE_ID", "_f_s_global_types_8h.html#a302e870f61469167d0391c1c2ed9fb2f", null ],
    [ "NO_FILE_TYPE", "_f_s_global_types_8h.html#a26d878fff368eb1d6741aa0bce6157de", null ],
    [ "NO_REC_ID", "_f_s_global_types_8h.html#a7778e2faa2babe0e93654cfdfdf2bd49", null ],
    [ "REC_ID", "_f_s_global_types_8h.html#a856855f029c5e23bdc667098dc089978", null ],
    [ "INT32", "_f_s_global_types_8h.html#a2c951cf9402cd61f04b43789471dbe7c", null ],
    [ "UINT32", "_f_s_global_types_8h.html#adfe04a44baaebba6143c3a23507ff85b", null ]
];