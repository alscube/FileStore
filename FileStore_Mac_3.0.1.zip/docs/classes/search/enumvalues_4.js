var searchData=
[
  ['error_5freading_5ffile_495',['ERROR_READING_FILE',['../_f_s_result_code_8h.html#acf2521ef0043c91d771c483ff98e52d8acdaf8fff17eab5bab3a6da68435ee15d',1,'FSResultCode.h']]],
  ['error_5fwriting_5ffile_496',['ERROR_WRITING_FILE',['../_f_s_result_code_8h.html#acf2521ef0043c91d771c483ff98e52d8a00c4fa80c3bcc8c0025a110be19657d6',1,'FSResultCode.h']]]
];
