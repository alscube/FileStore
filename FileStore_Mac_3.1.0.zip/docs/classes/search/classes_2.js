var searchData=
[
  ['deletedrecord_313',['DeletedRecord',['../class_deleted_record.html',1,'']]]
];
