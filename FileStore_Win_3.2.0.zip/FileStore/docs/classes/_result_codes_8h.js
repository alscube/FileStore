var _result_codes_8h =
[
    [ "ResultCodes", "class_result_codes.html", "class_result_codes" ],
    [ "DELETE", "_result_codes_8h.html#a9f91c27f0bcb26ae76eb4d51e5a0aca5", null ],
    [ "ResultValue", "_result_codes_8h.html#ab91dd545e9c1e7784d1c74ab39a6cfeb", null ],
    [ "SUCCESS", "_result_codes_8h.html#aa90cac659d18e8ef6294c7ae337f6b58", null ]
];