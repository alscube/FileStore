var class_log_message =
[
    [ "Clear", "class_log_message.html#a1d624bd8962b3cf5095f029f925e5f32", null ],
    [ "GetLogName", "class_log_message.html#a96164338c3dc6fcff442f2f2792a285e", null ],
    [ "Log", "class_log_message.html#ac16dfe2ecbbada92f68512cbf79c8f39", null ],
    [ "SetLogName", "class_log_message.html#a35ec422f06357df2b3c92d9ee065854b", null ]
];