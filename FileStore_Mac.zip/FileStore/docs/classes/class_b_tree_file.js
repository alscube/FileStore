var class_b_tree_file =
[
    [ "BTreeFile", "class_b_tree_file.html#a7806de74aa8574072ce18975afa0be21", null ],
    [ "~BTreeFile", "class_b_tree_file.html#ac28efbe05b60379f94c8f3a371abe0d0", null ],
    [ "Create", "class_b_tree_file.html#abcc5cbf25379ed10f1192cd62bdc0ebc", null ],
    [ "Delete", "class_b_tree_file.html#a5f47b7427398bb382b35c71c6f22e148", null ],
    [ "duplicatesAllowed", "class_b_tree_file.html#ab8fb60d99fe53b1a41dddcec957212e9", null ],
    [ "GetFileID", "class_b_tree_file.html#a3ab9586b79def9390cf6ab8701df5d67", null ],
    [ "GetFileType", "class_b_tree_file.html#ac8e24b58249591d18333bfdadab66119", null ],
    [ "GetLeftMostRecord", "class_b_tree_file.html#af72caec33a75219bbf5a1c4635cec89c", null ],
    [ "GetNextRecord", "class_b_tree_file.html#a3c5d39b2952db8ed3567aedbf3ab04f1", null ],
    [ "GetPreviousRecord", "class_b_tree_file.html#af7e0ee17e804ab885d2a60d982065d7e", null ],
    [ "GetRightMostRecord", "class_b_tree_file.html#aadce12df64550ddced4834249ff42b1d", null ],
    [ "GetTopRecord", "class_b_tree_file.html#a71963ea005d58a830c398e5aff7ad148", null ],
    [ "GetTopRecordID", "class_b_tree_file.html#a62c821d4ddac7721c8a55723f0426217", null ],
    [ "Insert", "class_b_tree_file.html#af6c876e6719575ec13ef21a6dc52d0cc", null ],
    [ "InsertT", "class_b_tree_file.html#a53f2afbf65e2c72839510eaec9fca5f6", null ],
    [ "NewRecord", "class_b_tree_file.html#aab5fdb27e30a6ebe647533b307f5273d", null ],
    [ "OpenT", "class_b_tree_file.html#a1c6c2d2a1bb522d3d5d0289b53ffd64b", null ],
    [ "ValidateTree", "class_b_tree_file.html#a1c81d3c7d5d0e85d322fa636bb40a76a", null ]
];