

// BtreeFileTestFile.cpp

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include "BTreeFileTestFile.h"


BTreeFileTestFile::BTreeFileTestFile( const QString& fileName )
	: FSBTreeFile( "TEST_INDEX", fileName )
{
}

BTreeFileTestFile::~BTreeFileTestFile( )
{
}


BTreeFileTestRecord* BTreeFileTestFile::NewRecord( int recordId )
{
	return new BTreeFileTestRecord( recordId );
}

//FSRecordBase* BTreeFileTestFile::_NewRecord( int recordId )
//{
//	return new BTreeFileTestRecord( recordId );
//}


void BTreeFileTestFile::DeleteKey( int key )
{
	BTreeFileTestRecord rec;
	rec.SetKey( key );
//    rec.SetValue( 0 );
	Delete( rec );
}
