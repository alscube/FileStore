
// TestRecord.cpp

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


// This record is used to test the base functionality of the BaseRecord
// and not a particular record for the File Store.

#include "TestRecord.h"

#include <QVariant>


// static
TestRecordFields TestRecord::_Fields = TestRecordFields();


TestRecord::TestRecord( int recordId, FileBase* fileBase )
	: RecordBase( recordId, fileBase )
{
}


ResultValue TestRecord::SetName( const QString& name )
{
	ResultValue result = Validate( name, _Fields[fName] );
	if ( result == SUCCESS )
	{
        _Name = name;
		SetModified( fName );
	}
	return result;
}

ResultValue TestRecord::SetAddress( const QString& address )
{
	ResultValue result = Validate( address, _Fields[fAddress] );
	if ( result == SUCCESS )
	{
        _Address = address;
		SetModified( fAddress );
	}
	return result;
}

ResultValue TestRecord::SetZipCode( int zipCode )
{
	ResultValue result = Validate( zipCode, _Fields[fZipCode] );
	if ( result == SUCCESS )
	{
        _ZipCode = zipCode;
		if ( zipCode > 0 )
			SetModified( fZipCode );
		else
			ClearModified( fZipCode );
	}
	return result;
}

ResultValue TestRecord::SetAreaCode( int areaCode )
{
    ResultValue result = Validate( areaCode, _Fields[fAreaCode] );
    if ( result == SUCCESS )
    {
        _AreaCode = areaCode;
        SetModified( fAreaCode );
    }
    return result;
}

ResultValue TestRecord::SetPhoneNumber( const QString& phoneNumber )
{
	ResultValue result = Validate( phoneNumber, _Fields[fPhoneNumber] );
	if ( result == SUCCESS )
	{
        _PhoneNumber = phoneNumber;
		SetModified( fPhoneNumber );
	}
	return result;
}


ResultValue TestRecord::SetIncome( float income )
{
    ResultValue result = Validate( income, _Fields[fIncome] );
    if ( result == SUCCESS )
    {
        _Income = income;
        SetModified( fIncome );
    }
    return result;
}


ResultValue TestRecord::SetOtherIncome( double otherIncome )
{
    ResultValue result = Validate( otherIncome, _Fields[fOtherIncome] );
    if ( result == SUCCESS )
    {
        _OtherIncome = otherIncome;
        SetModified( fOtherIncome );
    }
    return result;
}



const FieldDef* TestRecord::GetFieldDefinition( int fieldNum )
{
	if ( fieldNum < 0 || fieldNum >= _Fields.GetFieldCount() )
		return nullptr;

	return _Fields[fieldNum];
}


ResultValue TestRecord::GetField( int fieldNum, QVariant& outValue )
{
	switch ( fieldNum )
	{
		case fName :
			outValue = QVariant( GetName() );
			break;
		case fAddress :
			outValue = QVariant( GetAddress() );
			break;
		case fZipCode :
			outValue = QVariant( GetZipCode() );
			break;
		case fAreaCode :
			outValue = QVariant( GetAreaCode() );
			break;
		case fPhoneNumber :
			outValue = QVariant( GetPhoneNumber() );
			break;
        case fIncome :
            outValue = QVariant( GetIncome() );
            break;
        case fOtherIncome :
            outValue = QVariant( GetOtherIncome() );
            break;
            default :
			return RecordBase::GetField( fieldNum, outValue );
	}
	return SUCCESS;
}


ResultValue TestRecord::SetField( int fieldNum, QVariant& inValue )
{
	ResultValue result = SUCCESS;

	switch( fieldNum )
	{
		case fName :
			{
			QString value = inValue.toString();
			result = SetName( value );
			}
			break;
		case fAddress :
			break;
		case fZipCode :
			break;
		case fAreaCode :
			break;
		case fPhoneNumber :
			break;
        case fIncome :
            break;
        case fOtherIncome :
            break;
		default :
			result = FIELD_NOT_FOUND_IN_RECORD;
	}

	return result;
}


// PROTECTED
ResultValue TestRecord::_ReadFields( QDataStream& dataStream )
{
    dataStream >> _Name >> _ZipCode >> _AreaCode >> _PhoneNumber >> _Address >> _Income >> _OtherIncome;
    return SUCCESS;
}


// PROTECTED
ResultValue TestRecord::_WriteFields( QDataStream& dataStream )
{
    dataStream << _Name << _ZipCode << _AreaCode << _PhoneNumber << _Address << _Income << _OtherIncome;
    return SUCCESS;
}


