
// ResultCodeTest.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include <QTest>
#include <QDebug>


class FSResultCodeTest : public QObject
{
	Q_OBJECT

public:
	// You can remove any or all of the following functions if its body
	// is empty.

	FSResultCodeTest();
	virtual ~FSResultCodeTest();

private Q_SLOTS:
//	void initTestCase();
//	void cleanupTestCase();
//	void init();

    void CheckGlobalResultCode( );
	void CheckResultCode( );
    void ValidateResultException( );
    void LoggingTest( );

private:
};

