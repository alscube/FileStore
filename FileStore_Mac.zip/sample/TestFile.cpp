
// FileTestFile.cpp

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include "TestFile.h"
#include "FSResultException.h"

// in order to test the FSFileBase a derived 'file' class is needed,
// this is that derived class.


TestFile::TestFile( const QString& pathFileName )
	: FSFileBase( "TESTFILE", pathFileName )
{
}


TestFile::~TestFile( )
{
}


TestRecord* TestFile::NewRecord( int recordId )
{
	return new TestRecord( recordId, this );
}


ResultValue TestFile::CreateDefaultEntries( )
{
	ResultValue result = SUCCESS;

	TestRecord rec;

	rec.SetName( "Test Record 1" );
	rec.SetAddress( "1st Street" );
	rec.SetZipCode( 54321 );
	rec.SetAreaCode( 321 );
	rec.SetPhoneNumber( "1234567" );

	InsertT( rec );

    return result;
}

