
// BTreeFileTestRecord.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FSBTreeRecord.h"


// Example of an implemented BTree Record

class BTreeTestRecordFields : public FSBTreeRecordFields
{
public:
	BTreeTestRecordFields()
	{
		InsertField( "Key", QINT32_MIN, QINT32_MAX, sizeof(int) );
		InsertField( "Value", 0, QINT32_MAX, sizeof(int) );
	}
};


class BTreeFileTestRecord : public FSBTreeRecord
{
public:
	BTreeFileTestRecord( int recordId = -1 );
    ~BTreeFileTestRecord( ) override { }

	// * fields from Test Record * (begin)

	enum fields
	{
		fKey = BTreeRecordLastField+1
		, fValue
	};

		/// ID of BTree item indexed
	int GetKey( ) { return m_Key; }
	ResultValue SetKey( int key );

		/// ID of record that is to be indexed
	int GetValue( ) { return m_Value; }
	ResultValue SetValue( int recordIndex );


	// -------------------------------
	// Record Interface implementation

		/// Returns the total size of a record (all fields)
    static int GetRecordSize( ) { return m_TestFields.GetRecordSize(); }

		/// Returns the total number of fields in record
	static int GetFieldCount( ) { return m_TestFields.GetFieldCount(); }

		/// Returns all fields associated with the record
    static const QStringList & GetFieldList( ) { return m_TestFields.GetFieldList(); }

		/// Returns the value of a specific field by index
    ResultValue GetField( int fieldNum, QVariant& outValue ) override;

		/// called to compare the contents of this record to another
    eCOMPARE_RESULT CompareRecords( FSBTreeRecord& compareToRec, bool compareDups ) override;

//		/// called to make a copy of the record
//	virtual FSRecordBase* operator=( FSRecordBase* rec );


protected:
    ResultValue _ReadFields( QDataStream& dataStream ) override
		{
			FSBTreeRecord::_ReadFields(dataStream);   // read Btree fields
			dataStream >> m_Key >> m_Value;
            return SUCCESS;
		}

    ResultValue _WriteFields( QDataStream& dataStream ) override
		{
			FSBTreeRecord::_WriteFields(dataStream);    // write Btree fields
			dataStream << m_Key << m_Value;
            return SUCCESS;
		}


private:
	int m_Key;
	int m_Value;

	// internal record fields
	static BTreeTestRecordFields m_TestFields;

};


