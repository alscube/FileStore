var _result_exception_8h =
[
    [ "ResultException", "class_result_exception.html", "class_result_exception" ],
    [ "COMPARE_RESULT", "_result_exception_8h.html#a37d4367e8c90e35aa6e86e3ab2350768", null ],
    [ "DELETE_EXCEPTION", "_result_exception_8h.html#ae720472f0e5f04f6bb1f95b159a8732e", null ],
    [ "IF_RESULT_EQUALS", "_result_exception_8h.html#a4cdd57faa3075a92053717e410e0eded", null ],
    [ "IF_RESULT_EQUALS_X", "_result_exception_8h.html#a1467c980bf04ae5012a7c40b34c124d7", null ],
    [ "IF_RESULT_NOT_EQUALS", "_result_exception_8h.html#aaf69f625667507809238e4be65e64714", null ],
    [ "IF_RESULT_NOT_EQUALS_X", "_result_exception_8h.html#acc0948ca24674820273bfbf676d9a2ba", null ],
    [ "RETURN_RESULT", "_result_exception_8h.html#a38155dde42c7eca5f059fbcb89bfd39e", null ],
    [ "RETURN_RESULT_X", "_result_exception_8h.html#adcbbf959915887a7a81fd28610324765", null ],
    [ "TEST_RESULT", "_result_exception_8h.html#a8acbca66e00938156629a5a7ae1acd91", null ],
    [ "THROW_RESULT", "_result_exception_8h.html#ae797882eec2626e204cc0017a7d90b94", null ],
    [ "THROW_RESULT_MSG", "_result_exception_8h.html#a3d2a70ee301b192d2f423b65a64cb651", null ]
];