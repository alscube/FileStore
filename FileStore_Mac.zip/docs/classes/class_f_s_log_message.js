var class_f_s_log_message =
[
    [ "Clear", "class_f_s_log_message.html#a9588a782cfa85f6732320b43c21e2f26", null ],
    [ "GetLogName", "class_f_s_log_message.html#acec03480416d8f18fc16f9a9b5196d28", null ],
    [ "Log", "class_f_s_log_message.html#ab1ded3a61c9b2158f3afc76a171bb0cb", null ],
    [ "SetLogName", "class_f_s_log_message.html#aa30ef640a1595174bb99ef3adefe30c8", null ]
];