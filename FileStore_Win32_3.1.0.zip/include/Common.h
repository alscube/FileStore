
// Common.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "GlobalTypes.h"
#include <QString>


class Common
{
public:
	static ID GetNextUniqueFileID( );

	static QString GetNextUniqueFileName( );

	static DATE CurrentDate( );

private:
	static ID m_NextUniqueID;
};
