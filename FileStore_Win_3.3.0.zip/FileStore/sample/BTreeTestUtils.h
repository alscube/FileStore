
// BTreeTestUtils.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QString>

class BTreeFileTestFile;
class BTreeFileTestRecord;


class BTreeTestUtils
{
public:
	BTreeTestUtils();

	void DeleteFile( );

	void InsertTopRecord( BTreeFileTestFile& FSBTreeFile );

	void resetAndInsertTopRecord( BTreeFileTestFile& FSBTreeFile );

	static QList<int> leftKey;
	static QList<int> leftValue;
	void InsertLeftRecord( BTreeFileTestFile &FSBTreeFile, int index );

	static QList<int> rightKey;
	static QList<int> rightValue;
	void InsertRightRecord( BTreeFileTestFile &FSBTreeFile, int index );

//    static QList<int> leftKeyEx;
//    static QList<int> leftValueEx;
//    void InsertLeftRecordEx( BTreeFileTestFile &FSBTreeFile, int index );

//    static QList<int> rightKeyEx;
//    static QList<int> rightValueEx;
//    void InsertRightRecordEx( BTreeFileTestFile &FSBTreeFile, int index );

	void DumpAllRecords( BTreeFileTestFile& FSBTreeFile, bool dumpDetails = false );

	void TestTreeFromLeft( BTreeFileTestFile& FSBTreeFile, bool showKeys = false );

	void TestTreeFromRight( BTreeFileTestFile& FSBTreeFile, bool showKeys = false );

	void DumpSideOfTree( BTreeFileTestFile& FSBTreeFile, int key );

	int  DumpRightToLeft( BTreeFileTestFile& FSBTreeFile, BTreeFileTestRecord &rec, bool showKeys = false );

	int  DumpLeftToRight( BTreeFileTestFile& FSBTreeFile, BTreeFileTestRecord& rec, bool showKeys = false );

	void PrintSideOfTree( BTreeFileTestFile& FSBTreeFile, int value );

	void printTree( BTreeFileTestFile& FSBTreeFile, BTreeFileTestRecord& rec );


	const QString& FileName( ) { return m_FileName; }

private:
	QString m_PathToFile;
	QString m_FileName;

};


