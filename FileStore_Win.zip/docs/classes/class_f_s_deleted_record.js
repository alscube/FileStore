var class_f_s_deleted_record =
[
    [ "FSDeletedRecord", "class_f_s_deleted_record.html#a5aeeaee97bd0d7c705ca79aa2870aa9a", null ],
    [ "FSDeletedRecord", "class_f_s_deleted_record.html#af9aa99f6382ed830f00f6c87725007d3", null ],
    [ "~FSDeletedRecord", "class_f_s_deleted_record.html#a5c48f92e24012885229e184b1e97bea1", null ],
    [ "_ReadFields", "class_f_s_deleted_record.html#a22dff2a39cbcf8d5ac06ef0bf7867392", null ],
    [ "_WriteFields", "class_f_s_deleted_record.html#a1b5e1ae53e45bb0e7841cef4a50a4a8e", null ],
    [ "GetFields", "class_f_s_deleted_record.html#a3ee07c3a28d82af1432874fe9433fd2b", null ]
];