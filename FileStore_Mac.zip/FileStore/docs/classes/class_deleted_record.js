var class_deleted_record =
[
    [ "DeletedRecord", "class_deleted_record.html#a46759f5d68fcfdfe1875d312dbfd36e3", null ],
    [ "DeletedRecord", "class_deleted_record.html#a3195ede1e6513a34e5f93a8dd977b13c", null ],
    [ "~DeletedRecord", "class_deleted_record.html#a8b381f7ace0fd0ee9555a7faf9c9c82a", null ],
    [ "_ReadFields", "class_deleted_record.html#aada888a2f003da7d34917fa7e9370e82", null ],
    [ "_WriteFields", "class_deleted_record.html#a8501a2c3110445227da4a38375c63ed0", null ]
];