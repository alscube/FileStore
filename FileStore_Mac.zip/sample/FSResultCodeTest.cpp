
// FSResultCodeTest.cpp

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include "FSResultCodeTest.h"

#include "FSResultCodes.h"
#include "FSResultException.h"


// test
FSResultCodeTest::FSResultCodeTest()
{
}

FSResultCodeTest::~FSResultCodeTest()
{
}


// void FSResultCodeTest::initTestCase() { }

// void FSResultCodeTest::init() { }



void FSResultCodeTest::CheckGlobalResultCode( )
{
    FSResultCodesCore* codes( FSResultCodesCore::Instance() );
//    const QStringList& codeStrings( codes->CodeStrings() );

    QString result = codes->CodeString( 0 );
    QCOMPARE( result, QString("SUCCESS") );

    result = codes->CodeString( FS_CODE(FS_RESULT_CODE_LAST) );
    QCOMPARE( result, QString("FS_RESULT_CODE_LAST") );
}



// This only tests the local "FS" codes, not the global codes.
void FSResultCodeTest::CheckResultCode( )
{
    FSResultCodesCore* codes( FSResultCodesCore::Instance() );
//    const QStringList& codeStrings( codes->CodeStrings() );

	// first
    QString result = codes->CodeString( FS_CODE(0) );
	QCOMPARE( result, QString("FILE_NAME_NOT_SET") );

	// random middle values
    result = codes->CodeString( FS_CODE(READ_PAST_END_OF_FILE) );
	QCOMPARE( result, QString("READ_PAST_END_OF_FILE") );

    result = codes->CodeString( FS_CODE(NO_RECORDS_IN_FILE) );
	QCOMPARE( result, QString("NO_RECORDS_IN_FILE") );

	// last value
//    int strCount = codeStrings.size()-2;
//	int enumCount = FS_RESULT_CODE_LAST;
//	QCOMPARE( strCount, enumCount );

    result = codes->CodeString( FS_CODE(FS_UNEXPECTED_FAILURE) );
	QCOMPARE( result, QString("FS_UNEXPECTED_FAILURE") );

    result = codes->CodeString( FS_CODE(FS_RESULT_CODE_LAST) );
	QCOMPARE( result, QString("FS_RESULT_CODE_LAST") );
}


void FSResultCodeTest::ValidateResultException( )
{
    try {
        THROW_RESULT( FS_CODE(FILE_NOT_OPEN) );
    }
    catch ( FSResultException* ex )
    {
        int functionLine( ex->FunctionLine() );
        const QString& functionName( ex->FunctionName() );
        ResultValue result( ex->ResultCode() );
        const QString& resultString( ex->ResultCodeString() );
        const QString& messageStr( ex->MessageString() );

        QCOMPARE( functionLine, 79 );
        QCOMPARE( functionName, "ValidateResultException" );
        QCOMPARE( result, FS_CODE(FILE_NOT_OPEN) );
        QCOMPARE( resultString, "FILE_NOT_OPEN" );
        QCOMPARE( messageStr, "" );
    }

    try {
        THROW_RESULT_MSG( FS_CODE(INVALID_RECORD), "Test Record Incomplete" );
    }
    catch ( FSResultException* ex )
    {
        int functionLine( ex->FunctionLine() );
        const QString& functionName( ex->FunctionName() );
        ResultValue result( ex->ResultCode() );
        const QString& resultString( ex->ResultCodeString() );
        const QString& messageStr( ex->MessageString() );

        QCOMPARE( functionLine, 97 );
        QCOMPARE( functionName, "ValidateResultException" );
        QCOMPARE( result, FS_CODE(INVALID_RECORD) );
        QCOMPARE( resultString, "INVALID_RECORD" );
        QCOMPARE( messageStr, "Test Record Incomplete" );
    }

}


void FSResultCodeTest::LoggingTest( )
{
    qDebug() << "**** Needs to be implemented ****";
}
