var index =
[
    [ "Introduction", "index.html#Introduction", null ],
    [ "Where to get started", "index.html#Starting", null ]
];