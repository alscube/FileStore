
// BTreeInsertTests.cpp

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license



#include "BTreeInsertTests.h"

#include <QtGlobal>
#include <QRandomGenerator>

#include "BTreeFileTestFile.h"

#include <QDebug>

static int TOP_REC = 0;
static int DUP_ALLOWED = 1;
//static int LAST_DUP_VALUE = 2;

static FILE_ID BTREE_TEST_FILE_ID = 100;


BTreeInsertTests::BTreeInsertTests()
{
}

BTreeInsertTests::~BTreeInsertTests()
{
}


void BTreeInsertTests::cleanupTestCase()
{
	_btreeTestUtils.DeleteFile( );
}


// ************************************************************************
void BTreeInsertTests::CreateObjectTest( )
{
	BTreeFileTestFile* testFile = new BTreeFileTestFile( _btreeTestUtils.FileName() );

	const QString& fileName = testFile->GetPathFileName( );
	QCOMPARE( fileName, _btreeTestUtils.FileName() );

		// these are not initialized yet!
	int version = testFile->GetHeaderFileVersion();
	QCOMPARE( version, -1 );

	// this will be a bit weird until the header is
	// reworked, the compare values looks like
	// 4294967295 (ie: -1)
	FILE_ID headerFileId = testFile->GetHeaderFileId();
	QCOMPARE( headerFileId, -1 );

	try {
		FILE_ID fileID = testFile->GetFileID();
		Q_UNUSED( fileID )
		QFAIL("Should not get here");
	}
	catch( FSResultException* ex )
	{
		IF_RESULT_NOT_EQUALS_X( ex, FS_CODE(INVALID_FILE_ID) )
			QFAIL("Btree file ID is invalid" );
	}

	int fileType = testFile->GetFileType();
	QCOMPARE( fileType, 10 );

	delete testFile;
}


void BTreeInsertTests::CreateFileTest( )
{
	BTreeFileTestFile testFile( _btreeTestUtils.FileName() );

	ResultValue result = testFile.Create( BTREE_TEST_FILE_ID, 0, false );
	QCOMPARE( result, SUCCESS );

	const QString& fileName = testFile.GetPathFileName( );
	QCOMPARE( fileName, _btreeTestUtils.FileName() );

	int version = testFile.GetHeaderFileVersion();
	QCOMPARE( version, 3 );

	int fileType = testFile.GetHeaderFileType();
	QCOMPARE( fileType, 10 );

	FILE_ID fileID = testFile.GetHeaderFileId();
	QCOMPARE( fileID, 100 );

	QString verStr = testFile.GetHeaderFileIdAsString( );
	QCOMPARE( verStr, QString("100") );

	int fieldCount = testFile.GetHeaderFileFieldCount( );
	QCOMPARE( fieldCount, 12 );

	int recordSize = testFile.GetHeaderFileRecordSize( );
	QCOMPARE( recordSize, 48 );

	int recordCount = testFile.GetHeaderFileTotalRecordCount( );
	QCOMPARE( recordCount, 0 );

	int activeCount = testFile.GetHeaderFileActiveRecordCount( );
	QCOMPARE( activeCount, 0 );

	int firstDeleted = testFile.GetHeaderFileFirstDeleted( );
	QCOMPARE( firstDeleted, -1 );

	int lastDeleted = testFile.GetHeaderFileLastDeleted( );
	QCOMPARE( lastDeleted, -1 );

	int openClose = testFile.GetHeaderFileOpenCloseState( );
	QCOMPARE( openClose, 1 );

	int spare2 = testFile.GetHeaderSpareField( DUP_ALLOWED );
	QCOMPARE( spare2, 0 );  // duplicates not allowed

	bool dup = testFile.duplicatesAllowed();
	QCOMPARE( dup, false );  // duplicates not allowed

	int spare1 = testFile.GetHeaderSpareField( TOP_REC );   // top most record ID
	QCOMPARE( spare1, -1 );

	int topRecordId = testFile.GetTopRecordID();
	QCOMPARE( topRecordId, -1 );

	result = testFile.Create( BTREE_TEST_FILE_ID, 0, false );
	QCOMPARE( result, FS_CODE(FILE_IS_OPEN) );
}



void BTreeInsertTests::DuplicatesAllowedTest( )
{
	try {
		_btreeTestUtils.DeleteFile( );

		BTreeFileTestFile testFile( _btreeTestUtils.FileName() );

		ResultValue result = testFile.Create( BTREE_TEST_FILE_ID, 0, true );
		QCOMPARE( result, SUCCESS );

		bool allowed = testFile.duplicatesAllowed( );
		QCOMPARE( allowed, true );

		int spare2 = testFile.GetHeaderSpareField( DUP_ALLOWED );
		QCOMPARE( spare2, 1 );

		testFile.CloseT();

		result = testFile.Open();
		QCOMPARE( result, SUCCESS );

		allowed = testFile.duplicatesAllowed( );
		QCOMPARE( allowed, true );

		spare2 = testFile.GetHeaderSpareField( DUP_ALLOWED );
		QCOMPARE( spare2, 1 );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeInsertTests::CreateRecordTest( )
{
	BTreeFileTestRecord rec;

	int recSize = rec.GetRecordSize();
	QCOMPARE( recSize, 48 );

	int fieldCount = rec.GetFieldCount();
	QCOMPARE( fieldCount, 12 );

    const QStringList fieldList = rec.GetFieldNameList();
	QCOMPARE( fieldList.size(), fieldCount );

	QCOMPARE( fieldList[0], QString("Deleted") );
	QCOMPARE( fieldList[1], QString("PrevDeleted") );
	QCOMPARE( fieldList[2], QString("NextDeleted") );

	QCOMPARE( fieldList[3], QString("ParentID") );
	QCOMPARE( fieldList[4], QString("Left") );
	QCOMPARE( fieldList[5], QString("Right") );
	QCOMPARE( fieldList[6], QString("Next") );
	QCOMPARE( fieldList[7], QString("Prev") );
	QCOMPARE( fieldList[8], QString("Balance") );
	QCOMPARE( fieldList[9], QString("DuplicateID") );

	QCOMPARE( fieldList[10], QString("Key") );
	QCOMPARE( fieldList[11], QString("Value") );

	QCOMPARE ( rec.GetChildOnLeft(), -1 );
	QCOMPARE ( rec.GetChildOnRight(), -1 );
	QCOMPARE ( rec.GetBalance(), balanced );
	QCOMPARE ( rec.GetDuplicateID(), 0 );
	QCOMPARE ( rec.GetKey(), -1 );
	QCOMPARE ( rec.GetValue(), -1 );
}


void BTreeInsertTests::BTreeRecordTest( )
{
	ResultValue result;
	BTreeFileTestRecord rec;

	result = rec.SetChildOnLeft( -1 );
	QCOMPARE( result, SUCCESS );

	result = rec.SetChildOnLeft( 10 );
	QCOMPARE( result, SUCCESS );

	result = rec.SetChildOnLeft( -2 );
	QCOMPARE( result, FS_CODE(DATA_TO_SMALL) );

	result = rec.SetChildOnLeft( QINT32_MAX+1 );  // overflows (Compiler Warning)
	QCOMPARE( result, FS_CODE(DATA_TO_SMALL) );

	int left = rec.GetChildOnLeft();
	QCOMPARE( left, 10 );

	QVariant varLeft;
    result = rec.GetFieldValue( BTreeFileTestRecord::fLeft, varLeft );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( varLeft.toInt(), 10 );


	result = rec.SetChildOnRight( -1 );
	QCOMPARE( result, SUCCESS );

	result = rec.SetChildOnRight( 10 );
	QCOMPARE( result, SUCCESS );

	result = rec.SetChildOnRight( -2 );
	QCOMPARE( result, FS_CODE(DATA_TO_SMALL) );

	result = rec.SetChildOnRight( QINT32_MAX+1 );  // overflows (compiler warning)
	QCOMPARE( result, FS_CODE(DATA_TO_SMALL) );

	int right = rec.GetChildOnLeft();
	QCOMPARE( right, 10 );

	QVariant varRight;
    result = rec.GetFieldValue( BTreeFileTestRecord::fRight, varRight );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( varRight.toInt(), 10 );
}


void BTreeInsertTests::BTreeTestRecordTest( )
{
	ResultValue result;
	BTreeFileTestRecord rec;

	result = rec.SetKey( 100 );
	QCOMPARE( result, SUCCESS );

	int idenity = rec.GetKey( );
	QCOMPARE( idenity, 100 );

	QVariant var;
    result = rec.GetFieldValue( BTreeFileTestRecord::fKey, var );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( var.toInt(), 100 );


	result = rec.SetValue( 35409 );
	QCOMPARE( result, SUCCESS );

	int recNum = rec.GetValue( );
	QCOMPARE( recNum, 35409 );

    result = rec.GetFieldValue( BTreeFileTestRecord::fValue, var );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( var.toInt(), 35409 );
}


void BTreeInsertTests::CompareRecordTest()
{
	ResultValue result;

	BTreeFileTestRecord rec;
	result = rec.SetKey( 100 );
	QCOMPARE( result, SUCCESS );

	BTreeFileTestRecord rec1;
	result = rec1.SetKey( 50 );
	QCOMPARE( result, SUCCESS );

	eCOMPARE_RESULT compResult = rec.CompareRecords( rec1, true );
	QCOMPARE( compResult, CompareGreaterThan );

	result = rec1.SetKey( 150 );
	QCOMPARE( result, SUCCESS );

	compResult = rec.CompareRecords( rec1, true );
	QCOMPARE( compResult, CompareLessThan );

	result = rec1.SetKey( 100 );
	QCOMPARE( result, SUCCESS );

	compResult = rec.CompareRecords( rec1, true );
	QCOMPARE( compResult, CompareEqual );
}


void BTreeInsertTests::GetRecordOnLeftTest()
{
	_btreeTestUtils.DeleteFile();

	ResultValue result;

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );

	BTreeFileTestRecord rec;
	result = FSBTreeFile.GetPreviousRecord( rec );
	QCOMPARE( result, FS_CODE(INVALID_RECORD_ID) );

	BTreeFileTestRecord prevRec( 1 );
//	rec.ResetRecord( 1 );
	result = FSBTreeFile.GetPreviousRecord( prevRec );
	QCOMPARE( result, FS_CODE(FIRST_RECORD_IN_INDEX) );
		// the record is not valid, testing the return code
}


void BTreeInsertTests::GetRecordOnRightTest()
{
	_btreeTestUtils.DeleteFile();

	ResultValue result;

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );

	BTreeFileTestRecord rec;
	result = FSBTreeFile.GetNextRecord( rec );
	QCOMPARE( result, FS_CODE(INVALID_RECORD_ID) );

	BTreeFileTestRecord nextRec( 1 );
//	rec.ResetRecord( 1 );
	result = FSBTreeFile.GetNextRecord( nextRec );
	QCOMPARE( result, FS_CODE(LAST_RECORD_IN_INDEX) );
		// the record is not valid, testing the return code
}


void BTreeInsertTests::InsertTopRecordTest()
{
	try {
		_btreeTestUtils.DeleteFile();

		BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
		ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
		QCOMPARE( result, SUCCESS );

		_btreeTestUtils.InsertTopRecord( FSBTreeFile );

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.ValidateTree( );
	}
	catch ( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeInsertTests::InsertSingleLeftRecord()
{
	try {
		_btreeTestUtils.DeleteFile();

		BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );

		ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, false );
		QCOMPARE( result, SUCCESS );

		result = FSBTreeFile.Open( );
		QCOMPARE( result, FS_CODE(FILE_IS_OPEN) );

		_btreeTestUtils.InsertTopRecord( FSBTreeFile );
		_btreeTestUtils.InsertLeftRecord( FSBTreeFile, 0 );

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* except )
	{
		TEST_RESULT( except );
	}
}


void BTreeInsertTests::InsertSingleRightRecord()
{
	try {
		_btreeTestUtils.DeleteFile();

		BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );

		ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, false );
		QCOMPARE( result, SUCCESS );

		result = FSBTreeFile.Open( );
		QCOMPARE( result, FS_CODE(FILE_IS_OPEN) );

		_btreeTestUtils.InsertTopRecord( FSBTreeFile );
		_btreeTestUtils.InsertRightRecord( FSBTreeFile, 0 );

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* except )
	{
		TEST_RESULT( except );
	}
}


void BTreeInsertTests::single_LL_RotationInsert()
{
	// insert entries
	//    T        L
	//   L   =>  a   T
	//  a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   a
		int keyValues[11] = { 20, 10, 5 };

		for ( int i=0; i<3; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// insert entries
	//        T           L
	//     L     R  =>  x   T
	//   x   y         a - y R
	//  a - - -

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x   y   a
		int keyValues[11] = { 30, 20, 35, 10, 25, 5  };
		for ( int i=0; i<6; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeInsertTests::single_RR_RotationInsert( )
{
	// insert entries
	//    T           R
	//      R   =>  T   a
	//     - a       -

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   R   a
		int keyValues[11] = { 20, 30, 40 };

		for ( int i=0; i<3; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	// insert entries
	//     T             R
	//   L    R  =>   T     y
	//      x   y    L x   - a
	//     - - - a

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x   y   a
		int keyValues[11] = { 20, 10, 30, 25, 35, 40  };
		for ( int i=0; i<6; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}



void BTreeInsertTests::double_LR_RotationInsert()
{
	// insert entries
	//     T       a
	//   L   =>  L   T
	//    a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   a
		int keyValues[11] = { 20, 10, 15 };

		for ( int i=0; i<3; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// insert entries
	//        T            L
	//     L     R  =>  x     T
	//   x   y         - a   y R
	//  - - a -

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x   y   a
		int keyValues[11] = { 30, 20, 35, 10, 25, 24  };
		for ( int i=0; i<6; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// insert entries
	// double LR rotation
	//        T          y
	//     L    R  =>  L   T
	//   x   y        x a - R
	//  - - - a

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x   y   a
		int keyValues[11] = { 30, 20, 35, 10, 25, 26  };
		for ( int i=0; i<6; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	// These cases cause a Single LL Rotation

	//        T          L
	//     L    R  =>  x    T
	//   x   y        a -  y R
	//  a - - -

	//        T           L
	//     L    R  =>  x    T
	//   x   y        - a  y R
	//  - a - -


}


void BTreeInsertTests::double_RL_RotationInsert()
{
	// insert entries
	//    T           a
	//      R   =>  T   R
	//     a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   R   a
		int keyValues[11] = { 20, 30, 25 };

		for ( int i=0; i<3; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	// insert entries
	//       T              x
	//     L    R     =>  T   R
	//        x   y      L a - Y
	//       a - - -

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x   y   a
		int keyValues[11] = { 30, 20, 35, 32, 36, 31  };
		for ( int i=0; i<6; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// insert entries
	//     T              x
	//   L    R     =>  T    R
	//      x   y      L    a y
	//     - a - -

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x   y   a
		int keyValues[11] = { 30, 20, 35, 32, 40, 33  };
		for ( int i=0; i<6; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
			_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		}

		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// These cases cause a Single RR rotation

	//     T              R
	//   L    R     =>  T    y
	//      x   y      L x  a -
	//     - - a -

	//     T              R
	//   L    R     =>  T    y
	//      x   y      L x  - a
	//     - - - a
}


void BTreeInsertTests::InsertDuplicateRight( )
{
	InsertTopRecordTest();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Open( );
	QCOMPARE( result, SUCCESS );

	for ( int i=1; i<10; i++ )
	{
		BTreeFileTestRecord rec;

		result = rec.SetKey( 1010 );
		QCOMPARE( result, SUCCESS );

		result = rec.SetValue( i );
		QCOMPARE( result, SUCCESS );

		result = FSBTreeFile.Insert( rec );
		QCOMPARE( result, SUCCESS );

//        DumpAllRecords( FSBTreeFile, true );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile);
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );
	}
}


void BTreeInsertTests::InsertDuplicateLeft( )
{
	InsertTopRecordTest();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Open( );
	QCOMPARE( result, SUCCESS );

	for ( int i=1; i<6; i++ )
	{
		BTreeFileTestRecord rec;

		result = rec.SetKey( 900 );
		QCOMPARE( result, SUCCESS );

		result = rec.SetValue( i );
		QCOMPARE( result, SUCCESS );

		result = FSBTreeFile.Insert( rec );
		QCOMPARE( result, SUCCESS );

//        DumpAllRecords( FSBTreeFile, true );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );
	}
}


void BTreeInsertTests::InsertDuplicateFromTop( )
{
	InsertTopRecordTest();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Open( );
	QCOMPARE( result, SUCCESS );

	for ( int i=1; i<10; i++ )
	{
		BTreeFileTestRecord rec;

		result = rec.SetKey( 1000 );
		QCOMPARE( result, SUCCESS );

		result = rec.SetValue( i );
		QCOMPARE( result, SUCCESS );

		result = FSBTreeFile.Insert( rec );
		QCOMPARE( result, SUCCESS );

//        DumpAllRecords( FSBTreeFile, true );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );
	}
}



void BTreeInsertTests::InsertMixedRecords( )
{
	InsertTopRecordTest();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Open( );
	QCOMPARE( result, SUCCESS );

	QElapsedTimer timer;
	timer.start();

	QRandomGenerator random;
	int recID = 0;
	int randValue = static_cast<int>(random.generate());

	while ( recID < 1000 )
	{
		recID++;

		BTreeFileTestRecord rec;
		result = rec.SetKey( randValue );
		QCOMPARE( result, SUCCESS );

		result = rec.SetValue( recID );
		QCOMPARE( result, SUCCESS );

		result = FSBTreeFile.Insert( rec );
		if ( result != SUCCESS )
			qDebug() << result;

		QCOMPARE( result, SUCCESS );

//       PrintSideOfTree( FSBTreeFile, randValue );
#ifdef _VALIDATE_TREE_
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );
#endif
		randValue = static_cast<int>(random.generate());
	}

	int timed = static_cast<int>(timer.elapsed());
	QTime insertTime( 0, 0 );
	insertTime = insertTime.addMSecs( timed );
	qDebug() << recID << "records inserted in" << insertTime.toString( "s.zzz" ) << "seconds (full test)";
}

// 3000 .5 (no test)
