﻿
// FSResultException.h

// Copyright (C) 2021 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QString>
#include <QFile>
#include <QTextStream>
#include "FSResultCodesCore.h"


#define LOG_MESSAGE( msg ) FSLogMessage::Instance()->log( msg )

// To be implemented ...
// #define START_LOG( ) { FSResultException startLog( __FILE__, __FUNCTION__, __LINE__, SUCCESS, "Start Log" ); }



class QFile;
class QTextStream;


class FSLogMessage
{
public:
        // Get instance of this singleton
    static FSLogMessage* Instance( );

        // Set name for log file, won't log with out a name set
    void SetLogName( const QString& logPathAndName );

        // Return name of log file
    const QString& GetLogName( );

        // Call to clear out log file
    void Clear( );

        // call to add a message to the log file
    void Log( const QString& message );

private:
    FSLogMessage( );

    bool OpenLog( );
    void CloseLog( );

private:
    static FSLogMessage* _Instance;

    static QString _LogPathAndName;
    QFile   _LogFile;
    QTextStream _LogFileStream;
};

