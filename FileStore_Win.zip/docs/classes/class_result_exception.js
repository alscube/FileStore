var class_result_exception =
[
    [ "ResultException", "class_result_exception.html#a3af23a5c0237d5d0ce1da8d5beacb37e", null ],
    [ "~ResultException", "class_result_exception.html#ad7cc2bad348dff6418f34829e0738eef", null ],
    [ "FileName", "class_result_exception.html#a3e4775660c1f32fc1119609b7573b72e", null ],
    [ "FunctionLine", "class_result_exception.html#a63d11b2b0242c0a088ba646ff47013d6", null ],
    [ "FunctionName", "class_result_exception.html#aba700d205205160fad65adbfae15d6dd", null ],
    [ "MessageString", "class_result_exception.html#a716f9b48909db5fb0a89769905225630", null ],
    [ "ResultCode", "class_result_exception.html#a3c3fbcf8ead70218390c37479fe6856d", null ],
    [ "ResultCodeString", "class_result_exception.html#a7b5f25a03717c7dfda12b5f5c3a85978", null ]
];