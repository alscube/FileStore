var searchData=
[
  ['date_567',['DATE',['../_global_types_8h.html#a30b328ca499f27b3d0f8111b495834ca',1,'GlobalTypes.h']]],
  ['delete_568',['DELETE',['../_result_codes_8h.html#a9f91c27f0bcb26ae76eb4d51e5a0aca5',1,'ResultCodes.h']]],
  ['delete_5fexception_569',['DELETE_EXCEPTION',['../_result_exception_8h.html#ae720472f0e5f04f6bb1f95b159a8732e',1,'ResultException.h']]]
];
