var searchData=
[
  ['deletedrecord_301',['DeletedRecord',['../class_deleted_record.html',1,'']]]
];
