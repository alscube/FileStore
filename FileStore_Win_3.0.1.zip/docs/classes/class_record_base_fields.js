var class_record_base_fields =
[
    [ "RecordBaseFields", "class_record_base_fields.html#ab66c9e16b30113fcafa04d9e5edda7f4", null ],
    [ "~RecordBaseFields", "class_record_base_fields.html#a29b80cb19a22a0b247d9638f5f9a5b96", null ],
    [ "GetFieldCount", "class_record_base_fields.html#a84c4dd07b476addcf35b4f10a8168855", null ],
    [ "GetFieldList", "class_record_base_fields.html#ab68e85add2f93558c6507022e4fa80b7", null ],
    [ "GetRecordSize", "class_record_base_fields.html#a08f59fd8b966681a63ea1232076c3e5b", null ],
    [ "InsertField", "class_record_base_fields.html#a9b6533d40dc9e7be36568db8d5b4378d", null ],
    [ "operator[]", "class_record_base_fields.html#a16a1fed0b928c8d41716cd8b3e3d2f87", null ]
];