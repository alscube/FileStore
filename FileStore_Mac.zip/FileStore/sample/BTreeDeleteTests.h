
// BTreeDeleteTests.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include <QTest>
#include <QDebug>

#include "BTreeTestUtils.h"

class BTreeFileTestFile;
class BTreeFileTestRecord;


class BTreeDeleteTests : public QObject
{
	Q_OBJECT

public:
	// You can remove any or all of the following functions if its body
	// is empty.

	BTreeDeleteTests();
	virtual ~BTreeDeleteTests();

private Q_SLOTS:
//	void initTestCase();
	void cleanupTestCase();
//	void init();

	void deleteTopRecord( );
	void deleteInvalidRecord( );
	void deleteLeftSideOneEntry( );
	void deleteRightSideOneEntry( );

	void deleteLeftSideTwoEntries( );
	void deleteRightSideTwoEntries( );
	void deleteTopWithTwoChildren( );
	void deleteTopWithTwoChildrenOnLeft( );

	void single_RR_RotationDelete( );
	void double_RL_RotationDelete( );
	void single_LL_RotationDelete( );
	void double_LR_RotationDelete( );

	void deleteBalancedTreeFromBook( );

private:
	BTreeTestUtils _btreeTestUtils;
};

