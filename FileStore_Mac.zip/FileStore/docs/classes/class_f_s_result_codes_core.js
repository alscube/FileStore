var class_f_s_result_codes_core =
[
    [ "AddCode", "class_f_s_result_codes_core.html#a5ca74e2d3d0cd038d7736f46db6606df", null ],
    [ "CodeString", "class_f_s_result_codes_core.html#a96aae2facd41f11a67667c9d877969f2", null ],
    [ "ResultOffset", "class_f_s_result_codes_core.html#a05f541d9f76e4ff20c02e12059b8fb18", null ]
];