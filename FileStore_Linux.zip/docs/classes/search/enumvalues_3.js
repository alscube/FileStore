var searchData=
[
  ['data_5fto_5flarge_554',['DATA_TO_LARGE',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a17efea9306d5b1e2ebef74448d43e093',1,'FSResultCodes.h']]],
  ['data_5fto_5fsmall_555',['DATA_TO_SMALL',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a49e2e3857cd95e74050c52c3d3e55fb5',1,'FSResultCodes.h']]],
  ['dupliate_5fkey_5fdetected_556',['DUPLIATE_KEY_DETECTED',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a698ca2554ce7fc87b20c90d66833b879',1,'FSResultCodes.h']]],
  ['duplicate_5fentries_5fnot_5fallowed_557',['DUPLICATE_ENTRIES_NOT_ALLOWED',['../_f_s_result_codes_8h.html#acf2521ef0043c91d771c483ff98e52d8a42d253cb386825e3593f2f946e3e86a5',1,'FSResultCodes.h']]]
];
