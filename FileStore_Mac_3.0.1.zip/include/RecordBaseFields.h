
// RecordBaseFields.h

// Copyright (C) 2010 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QtGlobal>
#include <QList>
#include <QStringList>

#include "LibExport.h"


// on a mac .... INT_MIN, INT_MAX, INT64_MIN, INT64_MAX

// signed values
// int range:		-2,147,483,648 to 2,147,483,647
// long long range:	−9,223,372,036,854,775,808 to +9,223,372,036,854,775,807

#define QINT32_MAX 2147483647
#define QINT32_MIN -2147483648

// qint64
#define QINT64_MAX Q_INT64_C(9223372036854775807)
#define QINT64_MIN Q_INT64_C(9223372036854775807)*-1

// unsigned values
// unsigned int     0 to 4,294,967,295
// unsigned long    0 to 18,446,744,073,709,551,615

#define QUINT32_MAX 4294967295u
#define QUINT32_MIN 0

#define QUINT64_MAX Q_UINT64_C(18446744073709551615)
#define QUINT64_MIN Q_UINT64_C(0)


/*!
 * This is used to define the length of a String field in the Insert call, ie:
 *
 *      InsertField( "Payee", 1, 100, QSTRING(100) );
 */
#define QSTRING(x) sizeof(QChar)*(x+2)


/*!
 * \brief Structure that holds the basic definition of fields in a record.
 */
typedef struct FieldDef
{
	QString FieldName;
	qint64 FieldMin;
	qint64 FieldMax;
	// For Strings the Min and Max are the length.
    // For Numbers the Min and Max are the actual values.
	int StorageSize;
} _FIELD_DEF;


class LIB_EXPORT RecordBaseFields
{
public:
	RecordBaseFields( );
	virtual ~RecordBaseFields( );

        // Called to insert a field into the record
    void InsertField( const QString& name, qint64 min, qint64 max, int size );

        // Total number of bytes in the record
    int GetRecordSize( ) const;

        // Total number of Fields in the record
    int GetFieldCount( ) const;

        // String list of the field names
    const QStringList & GetFieldList( );

        // Returns the Field definition at index;
    const FieldDef* operator[](int fieldIndex);


private:
    QList<FieldDef*> _Fields;
    QStringList _FieldList;
    int _RecordSize;
};


