var class_result_codes =
[
    [ "AddCode", "class_result_codes.html#aa8564776735795088cc212656064913b", null ],
    [ "CodeString", "class_result_codes.html#a25bea0a2b9d13d2ee9acf2bd459111c2", null ],
    [ "ResultOffset", "class_result_codes.html#ab9f600420beaef53a8b34979da8616b0", null ]
];