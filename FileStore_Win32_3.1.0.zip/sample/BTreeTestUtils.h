
// BTreeTestUtils.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QString>

class BTreeFileTestFile;
class BTreeFileTestRecord;


class BTreeTestUtils
{
public:
	BTreeTestUtils();

	void DeleteFile( );

	void InsertTopRecord( BTreeFileTestFile& btreeFile );

	void resetAndInsertTopRecord( BTreeFileTestFile& btreeFile );

	static QList<int> leftKey;
	static QList<int> leftValue;
	void InsertLeftRecord( BTreeFileTestFile &btreeFile, int index );

	static QList<int> rightKey;
	static QList<int> rightValue;
	void InsertRightRecord( BTreeFileTestFile &btreeFile, int index );

//    static QList<int> leftKeyEx;
//    static QList<int> leftValueEx;
//    void InsertLeftRecordEx( BTreeFileTestFile &btreeFile, int index );

//    static QList<int> rightKeyEx;
//    static QList<int> rightValueEx;
//    void InsertRightRecordEx( BTreeFileTestFile &btreeFile, int index );

	void DumpAllRecords( BTreeFileTestFile& btreeFile, bool dumpDetails = false );

	void TestTreeFromLeft( BTreeFileTestFile& btreeFile, bool showKeys = false );

	void TestTreeFromRight( BTreeFileTestFile& btreeFile, bool showKeys = false );

	void DumpSideOfTree( BTreeFileTestFile& btreeFile, int key );

	int  DumpRightToLeft( BTreeFileTestFile& btreeFile, BTreeFileTestRecord &rec, bool showKeys = false );

	int  DumpLeftToRight( BTreeFileTestFile& btreeFile, BTreeFileTestRecord& rec, bool showKeys = false );

	void PrintSideOfTree( BTreeFileTestFile& btreeFile, int value );

	void printTree( BTreeFileTestFile& btreeFile, BTreeFileTestRecord& rec );


	const QString& FileName( ) { return m_FileName; }

private:
	QString m_PathToFile;
	QString m_FileName;

};


