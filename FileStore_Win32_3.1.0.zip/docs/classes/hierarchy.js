var hierarchy =
[
    [ "Common", "class_common.html", null ],
    [ "FieldDef", "class_field_def.html", null ],
    [ "FSResultCodes", "class_f_s_result_codes.html", null ],
    [ "LogMessage", "class_log_message.html", null ],
    [ "QObject", null, [
      [ "FileBase", "class_file_base.html", [
        [ "BTreeFile", "class_b_tree_file.html", null ]
      ] ],
      [ "RecordBase", "class_record_base.html", [
        [ "BTreeRecord", "class_b_tree_record.html", null ],
        [ "DeletedRecord", "class_deleted_record.html", null ]
      ] ]
    ] ],
    [ "RecordBaseFields", "class_record_base_fields.html", [
      [ "BTreeRecordFields", "class_b_tree_record_fields.html", null ]
    ] ],
    [ "ResultCodes", "class_result_codes.html", null ],
    [ "ResultException", "class_result_exception.html", null ]
];