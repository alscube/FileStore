
// main.cpp

// Copyright (C) 2020 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license

#include <QTest>

#include "FSResultCodeTest.h"
#include "FileStoreTest.h"

#include "BTreeInsertTests.h"
#include "BTreeDeleteTests.h"


// TEST_MAIN
int main(int argc, char *argv[])
{
	qDebug() << "Run Test";

	qputenv("QT_FORCE_STDERR_LOGGING", "1");

	int status = 0;
	QTest::setMainSourcePath(__FILE__, QT_TESTCASE_BUILDDIR);

	// FileStore Tests/Examples
	{
		FSResultCodeTest rct;
		status |= QTest::qExec(&rct, argc, argv);
	}
	{
		FileStoreTest fst;
		status |= QTest::qExec(&fst, argc, argv);
	}

	// BTree Tests/Examples
	{
		BTreeInsertTests bit;
		status |= QTest::qExec(&bit, argc, argv);
	}
	{
		BTreeDeleteTests bdt;
		status |= QTest::qExec(&bdt, argc, argv);
	}

	return status;
}
