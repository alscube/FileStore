var _f_s_file_base_8h =
[
    [ "FSFileBase", "class_f_s_file_base.html", "class_f_s_file_base" ],
    [ "FILE_STATE", "_f_s_file_base_8h.html#a0458972847fa3304f537882167149173", null ],
    [ "FileState", "_f_s_file_base_8h.html#a57306ae0f9e356347388234ed69e0ce7", [
      [ "FileInvalid", "_f_s_file_base_8h.html#a57306ae0f9e356347388234ed69e0ce7a7ef3e4b2a80a3ac618c5cc3ec922ce36", null ],
      [ "FileClosed", "_f_s_file_base_8h.html#a57306ae0f9e356347388234ed69e0ce7afbff28786b43cc30f883c51f1dd8cd85", null ],
      [ "FileOpen", "_f_s_file_base_8h.html#a57306ae0f9e356347388234ed69e0ce7afb48a1adcb94b6565ceadc7d22f75235", null ]
    ] ]
];