
// FileStoreTest.h

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


// This file tests the 'Test File'


#include <QTest>
#include <QDebug>

#include <QDir>
#include <QList>
#include <QStringList>
#include <QVariant>


class TestFile;


class FileStoreTest : public QObject
{
	Q_OBJECT

public:
	// You can remove any or all of the following functions if its body
	// is empty.

	FileStoreTest();
	~FileStoreTest() override;

private Q_SLOTS:
//	void initTestCase();
	void cleanupTestCase();
//	void init();

    void TestFileStoreInternalVersions( );

	void CreateObjectTest( );
	void CreateFileTest( );

    void OpenNoNameFileTest( );
	void OpenEmptyNameFileTest( );
	void OpenMissingFileTest( );
	void OpenOpenFileTest( );
	void OpenBadHeaderSizeFileTest( );
	void OpenInvalidHeaderFileTest( );
	void OpenInvalidVersionFileTest( );
	void OpenInvalidTypeFileTest( );
    void OpenAndCloseFileTest( );

    void TestDefaultRecordInsert( );
    void TestFileStoreVersionWithOpenFile( );
    void TestFileStoreVersionWithClosedFile( );
    void TestFileStoreVersionNoFileName( );
    void TestFileStoreVersionFileNotFound( );

	void CloseNonOpenedFileTest( );
	void CloseClosedFileTest( );

	void DeleteNoNameFileTest( );
	void DeleteBadNameFileTest( );
	void DeleteLockedFileTest( );

	//	void CloseTest( );

		// Record Tests
    void NewRecordTest( );
    void RecordFieldTest( );

    void StringValidatorsTest( );
    void BoolValidatorsTest( );
    void IntValidatorsTest( );
    void UintValidatorsTest( );
    void FloatValidatorsTest( );
    void DoubleValidatorsTest( );

	void RecordModifiedFieldTest( );

	void InsertAndValidateRecord( );
	void InsertAndRead();
    void ClearRecordTest( );
	void MultipleRecordInsert();
	void MaximumFieldSize();
//	void MinimumFieldSize();
	void BadRecordRead();
	void TestFieldAccess();
	void UpdateValidRecord();
	void UpdateInvalidRecord();
	void ReadNextValidRecord();
	void ReadNextInvalidRecord();
	void InsertAndDeleteSingleRecord();

	void TestDeletedRecord();
	void DeleteFirstRecord();
	void DeleteMiddleRecordTest();
	void DeleteLastRecord();
	void DeleteFirstTwoRecords();
	void DeleteLastTwoRecords();
	void DeleteAllRecords();
	void InsertReplaceOneDeletedRecord();
	void InsertReplaceTwoDeletedRecord();

	void RecordInsert( );
	void RecordRead( );
	void RecordUpdate( );

    void ExcludeDeletedRecords( );

private:
	void DeleteFile( );
	void CreateAndOpenFile();
	void InsertRecord( int index );

	QString m_PathToFile;
	QString m_FileName;

	TestFile* m_TestFile;
};

//DECLARE_TEST(FileStoreTest)
