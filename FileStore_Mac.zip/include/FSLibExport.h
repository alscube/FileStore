
// FSLibExport.h

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <qglobal.h>

// __declspec(dllexport), is a Microsoft feature

#ifdef _MSC_BUILD
	#if defined(FILESTORE_LIBRARY)
		#define LIB_EXPORT Q_DECL_EXPORT
	#else
		#define LIB_EXPORT Q_DECL_IMPORT
	#endif
#else
	#define LIB_EXPORT
#endif
