
// BTreeFileTestFile.h

// Copyright (C) 2014 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include "BTreeFile.h"

#include "BTreeFileTestRecord.h"


// This is an example Btree File implementation.

class BTreeFileTestFile : public BTreeFile
{
public:
	BTreeFileTestFile( const QString& fileName );
	~BTreeFileTestFile( ) override;

	// === Btree File Overrides begin

		/// Returns the number of fields in the record from derived table class
	virtual int GetFieldCount( ) const override { return BTreeFileTestRecord::GetFieldCount(); }

		/// returns the table record size defined in the derived table class
    virtual int GetRecordSize( ) const override { return BTreeFileTestRecord::GetRecordSize(); }

	// === Btree File Overrides end

		/// Delete a BTree entry by its key value
	void DeleteKey( int value ); //throws

	BTreeFileTestRecord* NewRecord( int recordId = -1 ) override;

};

