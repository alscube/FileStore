
// BTreeDeleteTests.cpp

// Copyright (C) 2015 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#include "BTreeDeleteTests.h"

#include "BTreeFileTestFile.h"
#include "BTreeFileTestRecord.h"

static FILE_ID BTREE_TEST_FILE_ID = 101;


BTreeDeleteTests::BTreeDeleteTests()
{
}


BTreeDeleteTests::~BTreeDeleteTests()
{
}


void BTreeDeleteTests::cleanupTestCase()
{
	_btreeTestUtils.DeleteFile( );
}


// ************************************************************************* //
// TESTS

void BTreeDeleteTests::deleteTopRecord( )
{
	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	BTreeFileTestRecord rec;
	FSBTreeFile.GetTopRecord( rec );

	try {
		FSBTreeFile.Delete( rec );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

		// try and delete it again!
	try {
		FSBTreeFile.Delete( rec );
	}
	catch( FSResultException* ex )
	{
        ResultValue result = ex->ResultCode( );
		delete ex;
		QCOMPARE( result, FS_CODE(NO_RECORDS_IN_FILE) );
	}
}


void BTreeDeleteTests::deleteInvalidRecord( )
{
		// try and delete a record that does not exist
	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	try {

		BTreeFileTestRecord rec( 0 );
		rec.SetKey( 1001 );
		FSBTreeFile.Delete( rec );
	}
	catch( FSResultException* ex )
	{
        COMPARE_RESULT_X( ex, FS_CODE(RECORD_NOT_FOUND) );
	}
}


void BTreeDeleteTests::deleteLeftSideOneEntry( )
{
	//    T
	//  L

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	try {
		BTreeFileTestRecord rec;
		rec.SetKey( 100 );
		rec.SetValue( 101 );

		FSBTreeFile.InsertT( rec );

		FSBTreeFile.Delete( rec );

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		BTreeFileTestRecord top;
		FSBTreeFile.GetTopRecord( top );
		QCOMPARE( top.GetParent(), -1 );
		QCOMPARE( top.GetChildOnLeft(), -1 );
		QCOMPARE( top.GetChildOnRight(), -1 );
		QCOMPARE( top.GetPrev(), -1 );
		QCOMPARE( top.GetNext(), -1 );
		QCOMPARE( top.GetBalance(), balanced );

	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::deleteRightSideOneEntry( )
{
	//    T
	//      R

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	try {
		BTreeFileTestRecord rec;
		rec.SetKey( 1010 );
		rec.SetValue( 1011 );

		FSBTreeFile.InsertT( rec );

		FSBTreeFile.Delete( rec );

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		BTreeFileTestRecord top;
		FSBTreeFile.GetTopRecord( top );
		QCOMPARE( top.GetParent(), -1 );
		QCOMPARE( top.GetChildOnLeft(), -1 );
		QCOMPARE( top.GetChildOnRight(), -1 );
		QCOMPARE( top.GetPrev(), -1 );
		QCOMPARE( top.GetNext(), -1 );
		QCOMPARE( top.GetBalance(), balanced );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::deleteLeftSideTwoEntries( )
{
	//              T
	//  (delete)  L   R
	//           a

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	try {
		BTreeFileTestRecord rec;
		rec.SetKey( 900 );
		rec.SetValue( 900 );
		FSBTreeFile.InsertT( rec );

		BTreeFileTestRecord rec2;
		rec2.SetKey( 800 );
		rec2.SetValue( 800 );
		FSBTreeFile.InsertT( rec2 );

		// so in order to get a left child we need to insert one more
		BTreeFileTestRecord rec3;
		rec3.SetKey( 700 );
		rec3.SetValue( 700 );
		FSBTreeFile.InsertT( rec3 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.ValidateTree( );

		// delete one in 'middle'
		FSBTreeFile.Delete( rec2 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );

		FSBTreeFile.ValidateTree( );

		BTreeFileTestRecord top;
		FSBTreeFile.GetTopRecord( top );
		QCOMPARE( top.GetRecordID(), 1 );
		QCOMPARE( top.GetParent(), -1 );
		QCOMPARE( top.GetChildOnLeft(), 3 );
		QCOMPARE( top.GetChildOnRight(), 0 );
		QCOMPARE( top.GetPrev(), 3 );
		QCOMPARE( top.GetNext(), 0 );
		QCOMPARE( top.GetBalance(), balanced );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::deleteRightSideTwoEntries( )
{
	//      T
	//    L   R  (delete)
	//         a

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	try {
		BTreeFileTestRecord rec;
		rec.SetKey( 1050 );
		rec.SetValue( 1050 );
		FSBTreeFile.InsertT( rec );

		BTreeFileTestRecord rec2;
		rec2.SetKey( 1100 );
		rec2.SetValue( 1100 );
		FSBTreeFile.InsertT( rec2 );

		// so in order to get a right child we need to insert one more
		BTreeFileTestRecord rec3;
		rec3.SetKey( 1150 );
		rec3.SetValue( 1150 );
		FSBTreeFile.InsertT( rec3 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.ValidateTree( );

		// delete one in 'middle'
		FSBTreeFile.Delete( rec2 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );

		FSBTreeFile.ValidateTree( );

		BTreeFileTestRecord top;
		FSBTreeFile.GetTopRecord( top );
		QCOMPARE( top.GetRecordID(), 1 );
		QCOMPARE( top.GetParent(), -1 );
		QCOMPARE( top.GetChildOnLeft(), 0 );
		QCOMPARE( top.GetChildOnRight(), 3 );
		QCOMPARE( top.GetPrev(), 0 );
		QCOMPARE( top.GetNext(), 3 );
		QCOMPARE( top.GetBalance(), balanced );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::deleteTopWithTwoChildren( )
{
	//      T (delete)
	//    L   R

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	_btreeTestUtils.resetAndInsertTopRecord( FSBTreeFile );

	try {
		BTreeFileTestRecord rec;
		rec.SetKey( 1100 );
		rec.SetValue( 1100 );
		FSBTreeFile.InsertT( rec );

		BTreeFileTestRecord rec2;
		rec2.SetKey( 900 );
		rec2.SetValue( 900 );
		FSBTreeFile.InsertT( rec2 );

//        _btreeTestUtils.DumpTreeFromLeft( FSBTreeFile, true );

		BTreeFileTestRecord top;
		FSBTreeFile.GetTopRecord( top );
		FSBTreeFile.Delete( top );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		_btreeTestUtils.TestTreeFromRight( FSBTreeFile );

		FSBTreeFile.ValidateTree( );

			// read new top
		FSBTreeFile.GetTopRecord( top );
		QCOMPARE( top.GetRecordID(), 2 );
		QCOMPARE( top.GetParent(), -1 );
		QCOMPARE( top.GetChildOnLeft(), -1 );
		QCOMPARE( top.GetChildOnRight(), 1 );
		QCOMPARE( top.GetPrev(), -1 );
		QCOMPARE( top.GetNext(), 1 );
		QCOMPARE( top.GetBalance(), lean_right );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}



void BTreeDeleteTests::deleteTopWithTwoChildrenOnLeft( )
{
	//     T (delete)
	//   L   R
	//  a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		int keyValues[11] = { 50, 25, 75, 20 };

		for ( int i=0; i<4; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

	   FSBTreeFile.DeleteKey( 50 );
	   _btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
	   FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	//     T
	//   L   R
	//    a

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();

	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		int keyValues[11] = { 50, 25, 75, 30 };

		for ( int i=0; i<4; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

	   FSBTreeFile.DeleteKey( 50 );
	   _btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
	   FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::single_RR_RotationDelete( )
{
	// insert entries then delete top
	// ( balance > balanced )
	//      T        L           R
	//    L   R   =>   R   =>  L   a
	//          a        a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
//	FSBTreeFile.SetFileName( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		int keyValues[11] = { 10, 5, 20, 25 };

		for ( int i=0; i<4; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		FSBTreeFile.DeleteKey( 10 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	// insert entries then delete top
	// ( balance = balanced )
	//      T        L           R
	//    L   R   =>   R   =>  L   b
	//       a b      a b       a

	FSBTreeFile.CloseT( );
	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L  R  a   b
		int keyValues[11] = { 10, 5, 20, 15, 25 };

		for ( int i=0; i<5; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.DeleteKey( 10 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::double_RL_RotationDelete( )
{
	// insert entries then delete top
	// ( balance < balanced )
	//      T        L           a
	//    L   R   =>   R   =>  L   R
	//       a        a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
//	FSBTreeFile.SetFileName( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		int keyValues[11] = { 10, 5, 20, 15 };

		for ( int i=0; i<4; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

	   _btreeTestUtils.TestTreeFromLeft( FSBTreeFile);

	   FSBTreeFile.DeleteKey( 10 );
	   _btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
	   FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// insert entries then delete L1
	//                T                 L2
	//  (delete)  L1       R    =>   T      R
	//              a   L2   R      a x    b R
	//                 x  b

	FSBTreeFile.CloseT( );
	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L1  R  a  L2  R   x   b
		int keyValues[11] = { 10, 5, 20, 6, 15, 25, 14, 16 };

		for ( int i=0; i<8; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.DeleteKey( 5 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::single_LL_RotationDelete( )
{
	// insert entries then delete R
	// ( balance < balanced )
	//      T          T        L
	//    L   R  =>   L   =>  a   T
	//   a           a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
//	FSBTreeFile.SetFileName( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   a
		int keyValues[11] = { 20, 10, 25, 5 };

		for ( int i=0; i<4; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.DeleteKey( 25 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	// insert entries then delete R
	// ( balance = balanced )
	//      T          T        L
	//    L   R  =>   L   =>  a   T
	//   a b         a b         b

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   a  b
		int keyValues[11] = { 20, 10, 25, 5, 15 };

		for ( int i=0; i<5; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.DeleteKey( 25 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void BTreeDeleteTests::double_LR_RotationDelete( )
{
	// insert entries then delete R
	// leaning to right

	//      T          T        a
	//    L   R  =>  L    =>  L   T
	//     a          a

	_btreeTestUtils.DeleteFile();

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );
//	FSBTreeFile.SetFileName( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   a
		int keyValues[11] = { 20, 10, 30, 15 };

		for ( int i=0; i<4; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		FSBTreeFile.DeleteKey( 30 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	// insert entries then delete R
	// 'y' on right
	//            T               L2
	//        L      R    =>   L      T
	//      x   L2     y      x a    b y
	//         a  b

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x  L2  y   a   b
		int keyValues[11] = { 20, 10, 30, 5, 15, 35, 14, 16 };

		for ( int i=0; i<8; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.DeleteKey( 30 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}


	// insert entries then delete R
	// 'y' on left
	//          T               L2
	//      L       R    =>   L    T
	//    x   L2   y         x a  b y
	//       a  b

	FSBTreeFile.CloseT( );

	_btreeTestUtils.DeleteFile();
	result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	try {
		//                    T   L   R   x  L2  y   a   b
		int keyValues[11] = { 20, 10, 30, 5, 15, 25, 14, 16 };

		for ( int i=0; i<8; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.DeleteKey( 30 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

}


void BTreeDeleteTests::deleteBalancedTreeFromBook( )
{
	/*  tree from book
	 *            5
	 *      3             8
	 *    2   4        7       10
	 *  1            6       9    11
	 *
	*/

	BTreeFileTestFile FSBTreeFile( _btreeTestUtils.FileName() );

	_btreeTestUtils.DeleteFile();

//	FSBTreeFile.SetFileName( _btreeTestUtils.FileName() );
	ResultValue result = FSBTreeFile.Create( BTREE_TEST_FILE_ID, 0, true );
	QCOMPARE( result, SUCCESS );

	int keyValues[11] = { 5, 3, 8, 2, 7, 4, 10, 1, 9, 6, 11 };

	try {
		for ( int i=0; i<11; i++ )
		{
			BTreeFileTestRecord rec;
			rec.SetKey( keyValues[i] );
			rec.SetValue( keyValues[i] );
			FSBTreeFile.InsertT( rec );
		}

		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		// 4
//        qDebug() << "delete 8";
		FSBTreeFile.DeleteKey( 4 );
		FSBTreeFile.ValidateTree( );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );

		// 8
//        qDebug() << "delete 8";
		FSBTreeFile.DeleteKey( 8 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		// 6
//        qDebug() << "delete 6";
		FSBTreeFile.DeleteKey( 6 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		// 5
//        qDebug() << "delete 5";
		FSBTreeFile.DeleteKey( 5 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		// 2
//        qDebug() << "delete 2";
		FSBTreeFile.DeleteKey( 2 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		// 1
//        qDebug() << "delete 1";
		FSBTreeFile.DeleteKey( 1 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );

		// 7
//        qDebug() << "delete 7";
		FSBTreeFile.DeleteKey( 7 );
		_btreeTestUtils.TestTreeFromLeft( FSBTreeFile );
		FSBTreeFile.ValidateTree( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	try {
		// try and delete again 7
		FSBTreeFile.DeleteKey( 7 );
	}
	catch( FSResultException* ex )
	{
        COMPARE_RESULT_X( ex, FS_CODE(RECORD_NOT_FOUND) );
	}

}
