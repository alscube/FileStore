var _file_store_globals_8h =
[
    [ "CheckFileStatus", "_file_store_globals_8h.html#a19ef07fbf0c13d11f495e3a66bafa235", null ],
    [ "CheckIOStatus", "_file_store_globals_8h.html#ad73489e76120834aa3189c81dbfa1420", null ]
];