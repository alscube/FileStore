var class_b_tree_file =
[
    [ "BTreeFile", "class_b_tree_file.html#a7806de74aa8574072ce18975afa0be21", null ],
    [ "~BTreeFile", "class_b_tree_file.html#ac28efbe05b60379f94c8f3a371abe0d0", null ],
    [ "Create", "class_b_tree_file.html#abcc5cbf25379ed10f1192cd62bdc0ebc", null ],
    [ "Delete", "class_b_tree_file.html#ac0fde2dd4e15bf427a2a7ca4c9199f39", null ],
    [ "duplicatesAllowed", "class_b_tree_file.html#ab8fb60d99fe53b1a41dddcec957212e9", null ],
    [ "GetFileID", "class_b_tree_file.html#a3ab9586b79def9390cf6ab8701df5d67", null ],
    [ "GetFileType", "class_b_tree_file.html#ac8e24b58249591d18333bfdadab66119", null ],
    [ "GetLeftMostRecord", "class_b_tree_file.html#ac4fea60aa43bb7dbf4dc01920ac12fbe", null ],
    [ "GetNextRecord", "class_b_tree_file.html#aebf84b9625afd318a6047f891812cba6", null ],
    [ "GetPreviousRecord", "class_b_tree_file.html#a78cb9bd20c3e80d5917489bbac67be9f", null ],
    [ "GetRightMostRecord", "class_b_tree_file.html#ab2c1ae589d288286709217ffd84c7512", null ],
    [ "GetTopRecord", "class_b_tree_file.html#afb413fb3af9fae7d9e9dbc977f0d9d69", null ],
    [ "GetTopRecordID", "class_b_tree_file.html#a62c821d4ddac7721c8a55723f0426217", null ],
    [ "Insert", "class_b_tree_file.html#a3762a8a2f901c8bf1b5702ad42119895", null ],
    [ "InsertT", "class_b_tree_file.html#a821eb56e31c5812c7891bfd47eddedf1", null ],
    [ "NewRecord", "class_b_tree_file.html#a866169c3503cfcdd105e05fcd6e9e9eb", null ],
    [ "OpenT", "class_b_tree_file.html#a1c6c2d2a1bb522d3d5d0289b53ffd64b", null ],
    [ "ValidateTree", "class_b_tree_file.html#a1c81d3c7d5d0e85d322fa636bb40a76a", null ]
];