var searchData=
[
  ['newrecord_417',['NewRecord',['../class_file_base.html#ad3da46c6968a4384c94060c13e34af7d',1,'FileBase::NewRecord()'],['../class_b_tree_file.html#a866169c3503cfcdd105e05fcd6e9e9eb',1,'BTreeFile::NewRecord()']]]
];
