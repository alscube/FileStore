
// FSRecordBaseFields.h

// Copyright (C) 2010 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QtGlobal>
#include <QList>
#include <QStringList>

#include "FSGlobalTypes.h"
#include "FSLibExport.h"

// 32 bit integers
// int range:		-2,147,483,648 to 2,147,483,647
// unsigned int     0 to 4,294,967,295
//
// use INT32_MAX, INT32_MIN, and UINT32_MAX
#define UINT32_MIN 0

// depracated
#define QINT32_MIN -2147483648

// depracated
#define QINT32_MAX 2147483647

// depracated
#define QUINT32_MIN 0

// depracated
#define QUINT32_MAX 4294967295u


// int 64
// signed long range:	−9,223,372,036,854,775,808 to +9,223,372,036,854,775,807
// unsigned long    0 to 18,446,744,073,709,551,615
//
// use INT64_MAX, INT64_MIN, and UINT64_MAX
#define UINT64_MIN 0

// depracated
#define QINT64_MIN Q_INT64_C(9223372036854775807)*-1

// depracated
#define QINT64_MAX Q_INT64_C(9223372036854775807)

// depracated
#define QUINT64_MIN Q_UINT64_C(0)

// depracated
#define QUINT64_MAX Q_UINT64_C(18446744073709551615)


/*!
 * float minimum value
 */
#define FLOAT_MIN (float)1.175494351e-38
/*!
 * float minimum value
 */
#define FLOAT_MAX (float)3.402823466e+38

/*!
 * double minimum value
 */
#define DOUBLE_MIN 2.2250738585072014e-308

/*!
 * double minimum value
 */
#define DOUBLE_MAX 1.7976931348623158e+308


/*!
 * This is used to define the length of a String field in the Insert call, ie:
 *
 *      InsertField( "Payee", 1, 100, QSTRING(100) );
 */
#define QSTRING(x) sizeof(QChar)*(x+2)


/*!
 * enums used to identify which Min Max values are valid for field
 */
typedef enum
{
    eMinMaxInt
    , eMinMaxFloat
    , eMinMaxDouble
} MinMaxType;


/*!
 * \brief Structure that holds the basic definition of fields in a record.
 */
class FieldDef
{
public:
    QString FieldName;
    MinMaxType minMaxVar;
    INT64 FieldMin;
    INT64 FieldMax;
    float FieldFloatMin;
    float FieldFloatMax;
    double FieldDoubleMin;
    double FieldDoubleMax;
	// For Strings the Min and Max are the length.
    // For Numbers the Min and Max are the actual values.
	int StorageSize;
};


class LIB_EXPORT FSRecordBaseFields
{
public:
    FSRecordBaseFields( );
    virtual ~FSRecordBaseFields( );

        // Called to insert a field into the record
    void InsertField( const QString& name, qint64 min, qint64 max, int size );

        // Called to insert a field with float values in a record
    void InsertFloatField( const QString& name, float min, float max, int size = sizeof(float) );

        // Called to insert a field with double values in a record
    void InsertDoubleField( const QString& name, double min, double max, int size = sizeof(double) );

        // Total number of bytes in the record
    int GetRecordSize( ) const;

        // Total number of Fields in the record
    int GetFieldCount( ) const;

        // String list of the field names
    const QStringList & GetFieldNameList( );

        // Returns the Field definition at index;
    const FieldDef* operator[](int fieldIndex);


private:
    QList<FieldDef*> _Fields;
    QStringList _FieldNameList;
    int _RecordSize;
};


