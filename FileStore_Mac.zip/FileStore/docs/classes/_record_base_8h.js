var _record_base_8h =
[
    [ "RecordBase", "class_record_base.html", "class_record_base" ],
    [ "SPRecordBase", "_record_base_8h.html#a9a1599e4128b5b7fb0c653d2e71ba28d", null ]
];