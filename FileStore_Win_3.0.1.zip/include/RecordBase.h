
// RecordBase.h

// Copyright (C) 2011 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include <QDataStream>
#include <QStringList>
#include <QSharedPointer>

#include "FSResultCode.h"
#include "GlobalTypes.h"
#include "ResultException.h"
#include "RecordBaseFields.h"
#include "LibExport.h"

class FileBase;


class LIB_EXPORT RecordBase : public QObject
{
    friend class FileBase;

public:
        // called for using normal records
	RecordBase( REC_ID recordID = NO_REC_ID, FileBase* fileBase = nullptr );

        // called when deleting a record
    RecordBase( REC_ID recordID, REC_ID prevRecID, REC_ID nextRecID );

    virtual ~RecordBase( );

    enum fields
    {
        fDeleted
        , fPrevDeleted
        , fNextDeleted
        , fRecordLastField = fNextDeleted
    };

        // ** FIELDS BEGIN **

        // Members functions used by the DeleteRecord class
    virtual bool IsDeleted( );

//    virtual void SetRecordDeleted( int state );
    virtual REC_ID  GetRecordDeleted( );

    virtual void SetPrevDeletedRecord( REC_ID prev );
    virtual REC_ID  GetPrevDeletedRecord( );

    virtual void SetNextDeletedRecord( REC_ID next );
    virtual REC_ID  GetNextDeletedRecord( );

        // ** FIELDS END **


        // RecordBase Interface implementation

        // Called to insert the record into the table
    virtual void InsertT( );

        // Called to read this record from table
    virtual void ReadT( );

        // Called to update this record in the table
    virtual void UpdateT( );

        // Test to see if a field in the record is modified.
        // Bitwise indicator, where bit zero is generic for the record,
        // any other bits are record/field specific.
	bool IsModified( unsigned int bit = 1 );

        // Used to set the modified bit for the record or field.
        // Bitwise indicator, where bit zero is generic for the record,
        // any other bits are record/field specific.
	void SetModified( unsigned int bit = 1 );

        // Clears a bit indicator for a field
	void ClearModified( unsigned int bit );

        // Indicates if record is in a valid state.  Records are validated
        // during reading and writing.
	bool IsValid( );

        // Called to invalidate the record.  Once set
        // invalid the record must be re-read from the file.
	void SetInvalid( );

        // Sets a unique id for this record.  Once set it cannot change.
        // Currently not used, always -1
	virtual int GetInternalID( );

        // Get/Set Record ID
        // This is the file index of this record relative to the file store.
    virtual void SetRecordId( REC_ID newRecordID );
    virtual REC_ID GetRecordID();

        // ID of the associated file store
    virtual void SetFileID( FILE_ID fileID );
    virtual FILE_ID GetFileID( );

        // ID of the type of file store for this record
	virtual void SetFileType( FILE_TYPE fileType );
	virtual FILE_TYPE GetFileType( );


    // The following methods have to be overridden in the derived class.
    // Thesse methods return information about the defined record and
    // are unique for the defined record.

        // Returns the total size of the RecordBase record.
        // Create a local version in the derived record. base will return the delete record size.
    static int GetRecordSize( );

        // Returns the total number of fields in the RecordBase record.
        // Create a local version in the derived record.
    static int GetFieldCount( );

        // Returns all fields associated with the record.
        // Override and make sure to call the base class.
    static const QStringList& GetFieldList( );

        // Returns the field definition as defined when inserting.
        // the field.  Pass in the field enum.
        // Override and make sure to call the base class.
    static const FieldDef* GetFieldDefinition( int fieldNum );


    // These methods only need to be implmened in derived class if you
    // want to use them

        // Returns the value of a specific field by index
        // Override and make sure to call the base class.
    virtual ResultValue GetField( int fieldNum, QVariant& outValue );

        // Returns the value of a specific field by index
        // Override and make sure to call the base class.
    virtual ResultValue SetField( int fieldNum, QVariant& inValue );


protected:

    // We always want to call ReadFields/WriteFields on the RecordBase which then calls back
    // into _ReadFields/_WriteFields on the final (derived) record.  This allows the RecordBase to
    // read/write it's fields first.

        // Reads data fields from the File into 'this' record, called by the FileBase.
        // The RecordBase calls _ReadFields which you implement in your final record class
    ResultValue ReadFields( QDataStream& dataStream );

        // Writes data fields from the record into the file, , called by the FileBase.
        // The RecordBase calls _WriteFields which you implement in your final record class
    ResultValue WriteFields( QDataStream& dataStream );


        // bool's are validated as Ints

        // Validates a string field for size, returns a ResultValue.
    virtual ResultValue Validate( const QString& value, const FieldDef* fieldDef );

        // Validates a string field for size, returns throws an exception.
    virtual void ValidateT( const QString& value, const FieldDef* fieldDef );

        // Validates a signed integer or boolean, returns a ResultValue.
    virtual ResultValue Validate( const int value, const FieldDef* fieldDef );

        // Validates a signed integer or boolean, throws an exception.
    virtual void ValidateT( const int value, const FieldDef* fieldDef );

        // Validates a unsigned 32-bit integer, returns a ResultValue
    virtual ResultValue Validate( const quint32 value, const FieldDef* fieldDef );

        // Validates a unsigned 32-bit integer throws an exception.
    virtual void ValidateT( const quint32 value, const FieldDef* fieldDef );

        // Validates a 64-bit integer, returns a ResultValue.
    virtual ResultValue Validate( const qint64 value, const FieldDef* fieldDef );

        // Validates a 62-bit integer throws an exception.
    virtual void ValidateT( const qint64 value, const FieldDef* fieldDef );

        // Called to for force a record to be valid
    virtual void SetValid( );

        // Called to clear the record internals
    void ResetRecord( REC_ID recordId = NO_REC_ID );

    // Do not call these methods directly, ReadFields and WriteFields (above) calls them.
    // These should be implemented in the derived record class to stream out field data.
    /*!
     * \fn ResultValue _ReadFields( QDataStream& dataStream ) = 0
     *
     *  This method is implemented in the derived record class to read in
     *  the fields that the dervied record class defines.
     *
            ResultValue TestRecord::_ReadFields( QDataStream& dataStream )
            {
                dataStream >> m_Name >> m_ZipCode >> m_AreaCode >> m_PhoneNumber >> m_Address;
                return SUCCESS;
            }

     * This method is called from the ReadFields method in the RecordBase
     * class when a record is read in.  The ReadFields method reads in
     * the record header fields first the calls _ReadFields.
     *
     * \param dataStream Data buffer that contains the FileStore data.
     * \return SUCCESS if the fields are read in or an ResultValue.
     *
     * \sa ResultCodes
     */
    virtual ResultValue _ReadFields( QDataStream& dataStream ) = 0;

    /*!
     * \fn ResultValue _WriteFields( QDataStream& dataStream ) = 0
     *
     * This method is implmented in the dervied record class to write out
     * the fields that the dervied record class defines.
     *
            ResultValue TestRecord::_WriteFields( QDataStream& dataStream )
            {
                dataStream << m_Name << m_ZipCode << m_AreaCode << m_PhoneNumber << m_Address;
                return SUCCESS;
            }
     *
     * This method is called from the WriteFields method in the RecordBase
     * class when a record is written out.  The WriteFields method writes out
     * the record header fields first the calls _WriteFields.
     *
     * \param dataStream Data buffer that contains the FileStore data.
     * \return SUCCESS if the fields are written out or an ResultValue.
     */
    virtual ResultValue _WriteFields( QDataStream& dataStream ) = 0;


private:
        // Sets the associated FileBase for the record.
        // This is set by NewRecord or when inserting the record
        // into the file.
    void SetFileBase( FileBase* filebase );


private:
    REC_ID _RecordID;		// index id for this record in the file
    int _InternalID;		// this should be a unique id for this record (not used yet)

    FileBase* _FileBase;	// file this record is from
    FILE_ID _FileID;		// unique ID of file
    FILE_TYPE _FileType;			// type of file

        // Indicates if a field in the record is modified.
        // Bitwise indicator, where bit zero is generic for the record,
        // any other bits are field specific.
    unsigned int _Modified;

        // Indiates if the record is valid, once the record is
        // invalid it must be re-read from the FileStore
    bool _Valid;

        // These are the leading fields written out with ALL records.
        // The initial link to the prev and next are stored in the
        // File header.
    qint32 _DeletedRecordFlag;    // indicates if record is deleted
    REC_ID _PrevDeletedRecord;    // link backward
    REC_ID _NextDeletedRecord;    // link forward

        // Fields that make up this record.
    static RecordBaseFields _Fields;
};

typedef QSharedPointer<RecordBase> SPRecordBase;
