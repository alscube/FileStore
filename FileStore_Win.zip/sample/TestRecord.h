
// TestRecord.h

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


#pragma once

#include "FSRecordBase.h"

#include <QString>


class TestTable;

/*
	fields for this record

	char[20]  Name
    int       zip code
    int       Area Code
	char[7]   phone number
    char[30]  Address
    float     Income
    double    OtherIncome
*/


class TestRecordFields : public FSRecordBaseFields
{
public:
	TestRecordFields()
	{
        InsertField( "Name", 2, 20, QSTRING(20) );
        InsertField( "Zip Code", 0, 99999, sizeof(INT32) );
        InsertField( "Area Code", 100, 999, sizeof(INT32) );
		InsertField( "Phone Number", 0, 8, QSTRING(8) );
		InsertField( "Address", 0, 30, QSTRING(30) );
        InsertFloatField( "Income", 100.0, 2000.0 ); // FLOAT_MIN, FLOAT_MAX );
        InsertDoubleField( "OtherIncome", DOUBLE_MIN, DOUBLE_MAX );
    }

	virtual ~TestRecordFields() { }
};


// This record is used to test the base functionality of the BaseRecord
// and not a particular record for the File Store.

class TestRecord : public FSRecordBase
{
public:
    TestRecord( int recordId = NO_REC_ID, FSFileBase* FSFileBase = nullptr );
	~TestRecord( ) override { }

    enum testfields
	{
		  fName = fRecordLastField+1
		, fZipCode
		, fAreaCode
		, fPhoneNumber
		, fAddress
        , fIncome
        , fOtherIncome
	};

		// ** FIELDS BEGIN **
    const QString& GetName( ) { return _Name; }
	ResultValue SetName( const QString& name );

    const QString& GetAddress( ) { return _Address; }
	ResultValue SetAddress( const QString& address );

    int GetZipCode( ) { return _ZipCode; }
	ResultValue SetZipCode( int zipCode );

    int GetAreaCode( ) { return _AreaCode; }
	ResultValue SetAreaCode( int areaCode );

    const QString& GetPhoneNumber( ) { return _PhoneNumber; }
	ResultValue SetPhoneNumber( const QString& phoneNumber );

    float GetIncome( ) { return _Income; }
    ResultValue SetIncome( float income );

    double GetOtherIncome( ) { return _OtherIncome; }
    ResultValue SetOtherIncome( double otherIncome );
        // ** FIELDS END **


		// Record Interface implementation

    static int GetFieldCount( ) { return _Fields.GetFieldCount(); }
    static int GetRecordSize( ) { return _Fields.GetRecordSize(); }
    static const QStringList& GetFieldList( ) { return _Fields.GetFieldList( ); }

	static const FieldDef* GetFieldDefinition( int fieldNum );

	ResultValue GetField( int fieldNum, QVariant& outValue ) override;
	ResultValue SetField( int fieldNum, QVariant& inValue ) override;

    // exposing to public for internal testing
    ResultValue ValidateField( QString& field, const QString& value, int fieldEnum ) override;
    ResultValue ValidateField( INT32& field, const INT32 value, int fieldEnum ) override;
    ResultValue ValidateField( float& field, const float value, int fieldEnum ) override;
    ResultValue ValidateField( double& field, const double value, int fieldEnum ) override;

protected:
    TestRecordFields& GetFields( ) override { return _Fields; }

    ResultValue _ReadFields( QDataStream& dataStream ) override;
	ResultValue _WriteFields( QDataStream& dataStream ) override;


private:
		// fields of this record
    QString _Name;
    QString _Address;
    int     _ZipCode;
    int     _AreaCode;
    QString _PhoneNumber;
    float   _Income;
    double  _OtherIncome;

		// internal data
    static TestRecordFields _Fields;
};

