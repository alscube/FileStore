
// FileStoreTest.cpp

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license


// This file tests the 'Test File', ie thie TestFile-test.


#include <QDebug>

#include "FileStoreTest.h"

#include "TestFile.h"
#include "TestRecord.h"

#include "FSDeletedRecord.h"


static QStringList _Names = QStringList() << "Mr Smith" << "Max Smart" << "James Lastname";
static QStringList _Addresses = QStringList() << "15 Main St." << "Center N. Pole #66" << "16 Lunar St";
static QList<int> _ZipCodes = QList<int>() << 23456 << 98765 << 67584;
static QList<int> _AreaCodes = QList<int>() << 515 << 151 << 999;
static QStringList _PhoneNumbers = QStringList() << "321-4567" << "999-3344" << "333-9876";
static QList<float> _Income = QList<float>() << 1234.56 << 5678.90 << 1111.22;
static QList<double> _OtherIncome = QList<double>() << 1234.5601 << 5678.9001 << 1111.2201;


// test
FileStoreTest::FileStoreTest()
{
	QString sep = QDir::separator();
	m_PathToFile = QDir::homePath();
	m_PathToFile += sep+"FileStore_Test"+sep;
	m_FileName = m_PathToFile + "FileStoreTest.dat";

	m_TestFile = nullptr;

	DeleteFile( );
}

FileStoreTest::~FileStoreTest()
{
}



//void FileStoreTest::initTestCase()
//{
//}


void FileStoreTest::cleanupTestCase()
{
	DeleteFile();
}


//void FileStoreTest::init()
//{
//}



void FileStoreTest::DeleteFile( )
{
	QDir dir;
	if ( dir.exists( m_FileName ) )
	{
		if ( m_TestFile )
			m_TestFile->Close(); // ignore result

		QString xy( m_FileName );

		if ( !dir.remove(m_FileName) )
			QFAIL( "unable to remove file" );
	}
	else
	{	// or make directory if it does not exist
		dir.mkpath( m_PathToFile );
	}
}


void FileStoreTest::CreateAndOpenFile( )
{
	if ( m_TestFile )
	{
		try {
			m_TestFile->CloseT();
		}
		catch( FSResultException *ex )
		{
			COMPARE_RESULT( ex, FS_CODE(FILE_NOT_OPEN) );
		}
	}

	DeleteFile();

	m_TestFile = new TestFile( m_FileName );

	try {
		m_TestFile->CreateT( );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::InsertRecord( int index )
{
	ResultValue result;
	TestRecord testRecord;

	result = testRecord.SetName( _Names[index] );
	QCOMPARE( result, SUCCESS );

	QString x = _Addresses[index];
	result = testRecord.SetAddress( x );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetZipCode( _ZipCodes[index] );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetAreaCode( _AreaCodes[index] );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetPhoneNumber( _PhoneNumbers[index] );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetIncome( _Income[index] );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetOtherIncome( _OtherIncome[index] );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Insert( testRecord );
	QCOMPARE( result, SUCCESS );
}


// ************************************************************************* //
// TESTS


// ************************************************************************
void FileStoreTest::CreateObjectTest( )
{
	TestFile* testFile;

	// Creates object but does not create/open physical file store
	try {
		testFile = new TestFile( m_FileName );

		QCOMPARE( testFile->IsOpen(), false );

		QCOMPARE( testFile->GetTableName( ), "TESTFILE" );
		QCOMPARE( testFile->GetFileName( ), "FileStoreTest.dat" );
		QCOMPARE( testFile->GetPathFileName( ), m_FileName );

		QCOMPARE( testFile->GetTotalHeaderSize(), 0 );

		QCOMPARE( testFile->GetHeaderFileVersion( ), -1 );
		QCOMPARE( testFile->GetHeaderFileType(), -1 );
		QCOMPARE( testFile->GetHeaderFileId(), -1 );
		QCOMPARE( testFile->GetHeaderFileIdAsString( ), QString("-1") );
		QCOMPARE( testFile->GetHeaderFileFieldCount( ), -1 );
		QCOMPARE( testFile->GetHeaderFileRecordSize( ), -1 );
		QCOMPARE( testFile->GetHeaderFileTotalRecordCount( ), -1 );
		QCOMPARE( testFile->GetHeaderFileActiveRecordCount( ), -1 );
		QCOMPARE( testFile->GetHeaderFileFirstDeleted( ), -1 );
		QCOMPARE( testFile->GetHeaderFileLastDeleted( ), -1  );
		QCOMPARE( testFile->GetHeaderFileOpenCloseState( ), FileInvalid );
		QCOMPARE( testFile->GetHeaderSpareField( 0 ), -1 );
		QCOMPARE( testFile->GetHeaderSpareField( 1 ), -1 );
		QCOMPARE( testFile->GetHeaderSpareField( 2 ), -1 );
		QCOMPARE( testFile->GetHeaderSpareField( 3 ), -1 );
		QCOMPARE( testFile->GetHeaderSpareField( 4 ), -1 );

		delete testFile;
	}
	catch( FSResultException *ex )
	{
		delete testFile;
		TEST_RESULT( ex );
	}
}


// ************************************************************************
void FileStoreTest::CreateFileTest( )
{
	try {
		TestFile testFile( m_FileName );

		ResultValue result = testFile.Create();
		QCOMPARE( result, SUCCESS );

		result = testFile.Create();
		QCOMPARE( result, FS_CODE(FILE_IS_OPEN) );

		testFile.CloseT();

		result = testFile.Create();
		QCOMPARE( result, FS_CODE(FILE_ALREADY_EXISTS) );

		TestFile badFile( "x:/badfilename" );
		result = badFile.Create();
		QCOMPARE( result, FS_CODE(UNABLE_TO_CREATE_FILE) );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::TestDefaultRecordInsert( )
{
	try {
		DeleteFile( );

			// make sure default record is created
		TestFile file( m_FileName );
		file.CreateT( );
		file.CreateDefaultEntries();
		QCOMPARE( file.GetHeaderFileActiveRecordCount(), 1 );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}

	try {
		DeleteFile( );

			// make sure default record is NOT created
		TestFile file( m_FileName );
		file.CreateT( );
		QCOMPARE( file.GetHeaderFileActiveRecordCount(), 0 );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}



void FileStoreTest::OpenCloseFileTest( )
{
	try {
		DeleteFile( );

		TestFile file( m_FileName );
		ResultValue result = file.Create();
		QCOMPARE( result, SUCCESS );
		QCOMPARE( file.GetTotalHeaderSize(), 64 );
		QCOMPARE( file.GetHeaderFileVersion(), 3 );
		QCOMPARE( file.GetHeaderFileRecordSize( ), 160 );

		file.CloseT();
		QCOMPARE( file.GetTotalHeaderSize(), -1 );
		QCOMPARE( file.GetHeaderFileVersion(), -1 );
		QCOMPARE( file.GetHeaderFileRecordSize( ), -1 );

		QCOMPARE( file.Open(), SUCCESS );
		QCOMPARE( file.GetTotalHeaderSize(), 64 );
		QCOMPARE( file.GetHeaderFileVersion(), 3 );
		QCOMPARE( file.GetHeaderFileRecordSize( ), 160 );

		file.CloseT();
		QCOMPARE( file.GetTotalHeaderSize(), -1 );
		QCOMPARE( file.GetHeaderFileVersion(), -1 );
		QCOMPARE( file.GetHeaderFileRecordSize( ), -1 );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}

// ************************************************************************
void FileStoreTest::OpenNoNameFileTest( )
{
	TestFile file( "" );
	ResultValue result = file.Open();
	QCOMPARE( result, FS_CODE(FILE_NAME_NOT_SET) );
}


void FileStoreTest::OpenEmptyNameFileTest( )
{
	try {
		DeleteFile( );

		TestFile file( m_FileName );
		ResultValue result = file.Create();
		QCOMPARE( result, SUCCESS );

		file.CloseT();

			// no name
		TestFile file2( "" );
		result = file2.Open();
		QCOMPARE( result, FS_CODE(FILE_NAME_NOT_SET) );

			// set name
		TestFile file3( m_FileName );
		result = file3.Open();
		QCOMPARE( result, SUCCESS );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::OpenMissingFileTest( )
{
	TestFile missingFile( "./MissingFile" );
	ResultValue result = missingFile.Open();
	QCOMPARE( result, FS_CODE(FILE_NOT_FOUND) );
}


void FileStoreTest::OpenOpenFileTest( )
{
	DeleteFile( );

	TestFile testFile( m_FileName );
	ResultValue result = testFile.Create();
	QCOMPARE( result, SUCCESS );

	result = testFile.Open();
	QCOMPARE( result, FS_CODE(FILE_IS_OPEN) );
}


void FileStoreTest::OpenBadHeaderSizeFileTest( )
{
	try {
		DeleteFile( );

		TestFile testFile( m_FileName );
		ResultValue result = testFile.Create();
		QCOMPARE( result, SUCCESS );

		testFile.CloseT();

		// FYI
		// There seems to be a bug with Qt that
		// when you open a file more then once it
		// does not close properly.  The call
		// to CLOSE above is needed.

		QFile file( m_FileName );
		file.resize( 20 );
		file.close();

		result = testFile.Open();
		QCOMPARE( result, FS_CODE(INVALID_FILE_SIZE) );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::OpenInvalidHeaderFileTest( )
{
	try {
		DeleteFile( );

		TestFile testFile( m_FileName );
		ResultValue result = testFile.Create();
		QCOMPARE( result, SUCCESS );

		testFile.CloseT();

		QFile file( m_FileName );
		file.open( QIODevice::ReadWrite );
		QDataStream stream( &file );
		stream << 35;   // damage size of file header
		file.close();

		result = testFile.Open();
		QCOMPARE( result, FS_CODE(INVALID_HEADER) );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::OpenInvalidVersionFileTest( )
{
	try {
		DeleteFile( );

		TestFile testFile( m_FileName );

		ResultValue result = testFile.Create();
		QCOMPARE( result, SUCCESS );

		testFile.CloseT();

		QFile file( m_FileName );
		file.open( QIODevice::ReadWrite );

			// 16 number of fields in header
		QDataStream stream( &file );
		stream << 16 << 99;    // set an invalid file version

		file.close();

		result = testFile.Open();
		QCOMPARE( result, FS_CODE(INVALID_FILE_VERSION) );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::OpenInvalidTypeFileTest( )
{
	try {
		DeleteFile( );

		TestFile testFile( m_FileName );

		ResultValue result = testFile.Create();
		QCOMPARE( result, SUCCESS );

		testFile.CloseT();

		QFile file( m_FileName );
		file.open( QIODevice::ReadWrite );

			// 16 number of fields in header
			//  3 file version
		QDataStream stream( &file );
		stream << 16 << 3 << 99;   // set an invalid file type

		file.close();

		result = testFile.Open();
		QCOMPARE( result, FS_CODE(FILE_TYPE_DOES_NOT_MATCH) );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


// ************************************************************************
void FileStoreTest::CloseNonOpenedFileTest( )
{
	try {
		DeleteFile( );

		TestFile testFile( m_FileName );
		testFile.CloseT();
	}
	catch( FSResultException *ex )
	{
		COMPARE_RESULT( ex, FS_CODE(FILE_NOT_OPEN) );
	}
}


void FileStoreTest::CloseClosedFileTest( )
{
	DeleteFile( );

	TestFile testFile( m_FileName );
	ResultValue result = testFile.Create();
	QCOMPARE( result, SUCCESS );

	try {
		testFile.CloseT();
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}

	try {
		testFile.CloseT();
	}
	catch( FSResultException *ex )
	{
		COMPARE_RESULT( ex, FS_CODE(FILE_NOT_OPEN) );
	}
}


// ************************************************************************
void FileStoreTest::DeleteNoNameFileTest( )
{
	try {
		DeleteFile( );

		TestFile testFile( "" );
		ResultValue result = testFile.DeleteFile();
		QCOMPARE( result, FS_CODE(FILE_NAME_NOT_SET) );
	}
	catch( FSResultException *ex )
	{
		COMPARE_RESULT( ex, FS_CODE(FILE_NOT_OPEN) );
	}
}


void FileStoreTest::DeleteBadNameFileTest( )
{
	DeleteFile( );

	TestFile testFile( "X;/abc" );
	ResultValue result = testFile.DeleteFile();
	QCOMPARE( result, FS_CODE(FILE_NOT_FOUND) );
}


void FileStoreTest::DeleteLockedFileTest( )
{
	// For this test to be accurate we need to open with a LOCK

	DeleteFile( );

	// Create ALSO Opens the file ...
	TestFile testFile( m_FileName );
	ResultValue result = testFile.Create();
	QCOMPARE( result, SUCCESS );

	TestFile secondFile( m_FileName );
	result = secondFile.Open( );
	QCOMPARE( result, SUCCESS );

#ifdef Q_OS_LINUX
	// On Linux if you open the file twice, it is really
	// opened only once.

	result = testFile.DeleteFile( );
	QCOMPARE( result, SUCCESS );

	result = secondFile.DeleteFile( );
	QCOMPARE( result, FS_CODE(FILE_NOT_FOUND) );
#endif

#ifdef Q_OS_WIN32
	// On Windows if you open the file twice you have to close it
	// twice, so the first one will fail.

	result = testFile.DeleteFile( );
	QCOMPARE( result, FS_CODE(UNABLE_TO_DELETE_FILE) );

	result = secondFile.DeleteFile( );
	QCOMPARE( result, SUCCESS );
#endif
}


// *****************************************************


void FileStoreTest::NewRecordTest( )
{
	TestFile* tt = new TestFile( m_PathToFile );
	FSFileBase* fs = tt;


		// Even though both are created the same the
		// upcast/down cast does make a difference.
	FSRecordBase* recBase = fs->_NewRecord( );  // creates a TestRecord but returned as FSRecordBase
	TestRecord* recFinal = tt->NewRecord( );

	QCOMPARE( recFinal->IsModified(), false );
	QCOMPARE( recFinal->IsValid(), true );

	QCOMPARE( recFinal->GetRecordID(), -1 );

	QCOMPARE( recBase->GetFileID(), NO_FILE_ID );
	QCOMPARE( recFinal->GetFileID(), NO_FILE_ID );

	QCOMPARE( recBase->GetFileType(), NO_FILE_TYPE );
	QCOMPARE( recFinal->GetFileType(), NO_FILE_TYPE );

	QCOMPARE( recBase->GetRecordSize(), 12 );
	QCOMPARE( recFinal->GetRecordSize(), 160 );

	QCOMPARE( recBase->GetFieldCount(), 3 );    // Only delete records fields
	QCOMPARE( recFinal->GetFieldCount(), 10 );   // All reecord Fields

//	const QStringList& baseFields = recBase->GetFieldList( );
//	const QStringList& finalFields = recFinal->GetFieldList( );

	delete recFinal;
	delete recBase;

	DeleteFile();
}


void FileStoreTest::RecordFieldTest( )
{
	TestRecord record;
	QStringList fieldList = record.GetFieldList( );

	int fieldCount = record.fOtherIncome+1;	// the last field (zero based)
	int count = fieldList.count();
	QCOMPARE( count, fieldCount );
	QCOMPARE( count, 10 );	// base + record fields

	QCOMPARE( fieldList[FSRecordBase::fDeleted], QString("Deleted") );

	QCOMPARE( fieldList[record.fName], QString("Name") );
	QCOMPARE( fieldList[record.fAddress], QString("Address") );
	QCOMPARE( fieldList[record.fZipCode], QString("Zip Code") );
	QCOMPARE( fieldList[record.fAreaCode], QString("Area Code") );
	QCOMPARE( fieldList[record.fPhoneNumber], QString("Phone Number") );
	QCOMPARE( fieldList[record.fIncome], QString("Income") );
	QCOMPARE( fieldList[record.fOtherIncome], QString("OtherIncome") );

	QCOMPARE( record.IsModified(), false );
	QCOMPARE( record.IsValid(), true );	// not created yet

	// Record base defines the deleted fields
	const FieldDef* def = record.GetFieldDefinition( FSRecordBase::fDeleted );
	QCOMPARE( def->FieldName, "Deleted" );
	QCOMPARE( def->FieldMin, 0 );
	QCOMPARE( def->FieldMax, 1 );

	// the derived record defines the 'record' fields
	const FieldDef* nameDef( record.GetFieldDefinition( TestRecord::fName ) );
	QCOMPARE( nameDef->FieldName, "Name" );
	QCOMPARE( nameDef->FieldMin, 0 );
	QCOMPARE( nameDef->FieldMax, 20 );

	// or you can just use a pure index
	const FieldDef* addrDef( record.GetFieldDefinition( 7 ) );
	QCOMPARE( addrDef->FieldName, "Address" );
	QCOMPARE( addrDef->FieldMin, 0 );
	QCOMPARE( addrDef->FieldMax, 30 );

	const FieldDef* incomeDef( record.GetFieldDefinition( TestRecord::fIncome ) );
	QCOMPARE( incomeDef->FieldName, "Income" );
	QCOMPARE( incomeDef->minMaxVar, eMinMaxFloat );
	QCOMPARE( incomeDef->FieldFloatMin, FLOAT_MIN );
	QCOMPARE( incomeDef->FieldFloatMax, FLOAT_MAX );

	const FieldDef* otherDef( record.GetFieldDefinition( TestRecord::fOtherIncome ) );
	QCOMPARE( otherDef->FieldName, "OtherIncome" );
	QCOMPARE( otherDef->minMaxVar, eMinMaxDouble );
	QCOMPARE( otherDef->FieldDoubleMin, DOUBLE_MIN );
	QCOMPARE( otherDef->FieldDoubleMax, DOUBLE_MAX );
}


void FileStoreTest::RecordModifiedFieldTest( )
{
	TestRecord rec;

	QCOMPARE( rec.IsModified(), false );

	rec.SetAddress( "New Address" );

	QCOMPARE( rec.IsModified(), true );
	QCOMPARE( rec.IsModified(TestRecord::fAddress), true );
	QCOMPARE( rec.IsModified(TestRecord::fName), false );

	rec.ClearModified( TestRecord::fAddress );
	QCOMPARE( rec.IsModified(TestRecord::fAddress), false );
	QCOMPARE( rec.IsModified(), false );

	rec.SetName( "name" );

	QCOMPARE( rec.IsModified(),  true );
	QCOMPARE( rec.IsModified(TestRecord::fName), true );

	rec.SetZipCode( 12345 );

	QCOMPARE( rec.IsModified(),  true );
	QCOMPARE( rec.IsModified(TestRecord::fZipCode), true );
	QCOMPARE( rec.IsModified(TestRecord::fAreaCode), false );

	rec.ClearModified( TestRecord::fZipCode );
	QCOMPARE( rec.IsModified(TestRecord::fZipCode), false );
	QCOMPARE( rec.IsModified(TestRecord::fName), true );
	QCOMPARE( rec.IsModified(TestRecord::fAreaCode), false );

	QCOMPARE( rec.IsModified(), true );
}


void FileStoreTest::InsertAndValidateRecord( )
{
	CreateAndOpenFile( );

	ResultValue result;
	TestRecord testRecord;

	int index = 0;
	result = testRecord.SetName( _Names[index] );
	QCOMPARE( result, SUCCESS );

	QString addr = _Addresses[index];
	result = testRecord.SetAddress( addr );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetZipCode( _ZipCodes[index] );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetAreaCode( _AreaCodes[index] );
	QCOMPARE( result, SUCCESS );

	result = testRecord.SetPhoneNumber( _PhoneNumbers[index] );
	QCOMPARE( result, SUCCESS );

	try {
		m_TestFile->InsertT( testRecord );
		QCOMPARE( testRecord.GetRecordID(), 0 );
		QCOMPARE( testRecord.IsModified(), false );
		QCOMPARE( testRecord.IsValid(), true );
		QCOMPARE( testRecord.GetInternalID(), -1 );
		QCOMPARE( testRecord.GetFileID(), TEST_FILE_ID );
		QCOMPARE( testRecord.GetFileType(), TEST_FILE_TYPE );
		QCOMPARE( testRecord.IsDeleted(), false );
		QCOMPARE( testRecord.GetPrevDeletedRecord(), -1 );
		QCOMPARE( testRecord.GetNextDeletedRecord(), -1 );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	try {
		testRecord.SetRecordId( 99 );     // 99 is just a random id
	} catch( FSResultException* ex )
	{
		COMPARE_RESULT( ex, FS_CODE(RECORD_ID_ALREADY_SET) );
	}

//	testRecord.ResetRecord( 99 );     // 99 is just a random id

//	QCOMPARE( testRecord.GetRecordID(), 99 );
//	QCOMPARE( testRecord.IsModified(), false );
//	QCOMPARE( testRecord.IsValid(), true );
//	QCOMPARE( testRecord.GetInternalID(), -1 );
//	QCOMPARE( testRecord.GetFileID(), -1 );
//	QCOMPARE( testRecord.GetFileType(), -1 );
//	QCOMPARE( testRecord.IsDeleted(), false );
//	QCOMPARE( testRecord.GetPrevDeletedRecord(), -1 );
//	QCOMPARE( testRecord.GetNextDeletedRecord(), -1 );
}


void FileStoreTest::InsertAndRead( )
{
	try {
		CreateAndOpenFile( );

		InsertRecord( 0 );

		TestRecord readRecord( 0 );
		ResultValue result = m_TestFile->Read( readRecord );
		QCOMPARE( result, SUCCESS );

			// validate
		QCOMPARE( _Names[0], readRecord.GetName( ) );
		QCOMPARE( _Addresses[0], readRecord.GetAddress() );
		QCOMPARE( _ZipCodes[0], readRecord.GetZipCode() );
		QCOMPARE( _AreaCodes[0], readRecord.GetAreaCode() );
		QCOMPARE( _PhoneNumbers[0], readRecord.GetPhoneNumber() );

			// insert duplicate
		result = m_TestFile->Insert( readRecord );
		QCOMPARE( result, FS_CODE(RECORD_ALREADY_INSERTED) );

			// read invalid record
		TestRecord invalidRec( NO_REC_ID );
//		readRecord.ResetRecord( -1 );
		result = m_TestFile->Read( invalidRec );
		QCOMPARE( result, FS_CODE(INVALID_RECORD_ID) );

		TestRecord invalidRec2( 99 );   // just a invalid random ID
//		readRecord.ResetRecord( 99 );
		result = m_TestFile->Read( invalidRec2 );
		QCOMPARE( result, FS_CODE(INVALID_RECORD_ID) );


		m_TestFile->CloseT( );

		result = m_TestFile->Open( );
		QCOMPARE( result, SUCCESS );

		QCOMPARE( m_TestFile->GetHeaderFileTotalRecordCount(), 1 );
		QCOMPARE( m_TestFile->GetHeaderFileActiveRecordCount(), 1 );

		m_TestFile->CloseT( );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::MultipleRecordInsert( )
{
	try {
		CreateAndOpenFile( );

		InsertRecord( 0 );

		TestRecord readRecord(0);
		ResultValue result = m_TestFile->Read( readRecord );
		QCOMPARE( result, SUCCESS );

		InsertRecord( 1 );

		TestRecord readRecord1(1);
		result = m_TestFile->Read( readRecord1 );
		QCOMPARE( result, SUCCESS );

		int count = m_TestFile->GetHeaderFileTotalRecordCount();
		QCOMPARE( count, 2 );

		count = m_TestFile->GetHeaderFileActiveRecordCount();
		QCOMPARE( count, 2 );

		m_TestFile->CloseT( );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::MaximumFieldSize( )
{
	try {
		CreateAndOpenFile( );

		TestRecord rec;
		QString name("12345678901234567890");
		ResultValue result = rec.SetName( name );	// 20
		QCOMPARE( result, SUCCESS );

		QString addr( "123456789012345678901234567890" );
		result = rec.SetAddress( addr );	// 30
		QCOMPARE( result, SUCCESS );

		result = rec.SetZipCode( 12345 );	// 5
		QCOMPARE( result, SUCCESS );

		result = rec.SetAreaCode( 123 ); 	// 3
		QCOMPARE( result, SUCCESS );

		QString phone( "123-4567" );
		result = rec.SetPhoneNumber( phone ); // 8
		QCOMPARE( result, SUCCESS );

		result = m_TestFile->Insert( rec );
		QCOMPARE( result, SUCCESS );

		TestRecord rec2;
		name = "09876543210987654321";
		result = rec2.SetName( name );	// 20
		QCOMPARE( result, SUCCESS );
		addr = "098765432109876543210987654321";
		result = rec2.SetAddress( addr );	// 30
		QCOMPARE( result, SUCCESS );
		result = rec2.SetZipCode( 54321 );	// 5
		QCOMPARE( result, SUCCESS );
		result = rec2.SetAreaCode( 321 ); 	// 3
		QCOMPARE( result, SUCCESS );
		phone = "765-4321";
		result = rec2.SetPhoneNumber( phone ); // 8
		QCOMPARE( result, SUCCESS );

		QCOMPARE( rec2.IsModified(), true );

		result = m_TestFile->Insert( rec2 );
		QCOMPARE( result, SUCCESS );

		QCOMPARE( rec2.IsModified(), false );

		// see if there is an overwrite
//        result = m_TestFile->Update( rec );
//        QCOMPARE( result, SUCCESS );

			// read in record 0 and see if any of
			// the fields dead
		TestRecord rec3(0);
		result = m_TestFile->Read( rec3 );

		QCOMPARE( rec3.GetName(), rec.GetName() );
		QCOMPARE( rec3.GetAddress(), rec.GetAddress() );
		QCOMPARE( rec3.GetZipCode(), rec.GetZipCode() );
		QCOMPARE( rec3.GetAreaCode(), rec.GetAreaCode() );
		QCOMPARE( rec3.GetPhoneNumber(), rec.GetPhoneNumber() );

		int count = m_TestFile->GetHeaderFileTotalRecordCount();
		QCOMPARE( count, 2 );

		count = m_TestFile->GetHeaderFileActiveRecordCount();
		QCOMPARE( count, 2 );

		m_TestFile->CloseT();
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::BadRecordRead( )
{
	CreateAndOpenFile( );

	TestRecord testRecord( 10 );
//	testRecord.ResetRecord( 10 );

	ResultValue result = m_TestFile->Read( testRecord );
	QCOMPARE( result, FS_CODE(INVALID_RECORD_ID) );
}


void FileStoreTest::TestFieldAccess( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );

	TestRecord rec(0);
	ResultValue result = m_TestFile->Read( rec );
	QCOMPARE( result, SUCCESS );

	QVariant var;
	rec.GetField( rec.fName, var );

	QString str = var.toString( );
	QCOMPARE( str, _Names[0] );

	try {
		rec.GetField( 33, var );
	}
	catch( ResultValue result )
	{
		QCOMPARE( result, FS_CODE(FIELD_NOT_FOUND_IN_RECORD) );
	}
}


void FileStoreTest::UpdateValidRecord( )
{
	try {
		CreateAndOpenFile( );

		TestRecord testRecord;
		testRecord.SetName( _Names[0] );
		testRecord.SetAddress( _Addresses[0] );
		testRecord.SetZipCode( _ZipCodes[0] );
		testRecord.SetAreaCode( _AreaCodes[0] );
		testRecord.SetPhoneNumber( _PhoneNumbers[0] );

		ResultValue result = m_TestFile->Insert( testRecord );
		QCOMPARE( result, SUCCESS );

		QCOMPARE( testRecord.IsModified(), false );
		testRecord.SetAddress( _Addresses[1] );
		QCOMPARE( testRecord.IsModified(), true );

		result = m_TestFile->Update( testRecord );
		QCOMPARE( result, SUCCESS );

		QCOMPARE( testRecord.IsModified(), false );

		m_TestFile->CloseT( );

		result = m_TestFile->Open( );
		QCOMPARE( result, SUCCESS );

		TestRecord readRecord(0);
		result = m_TestFile->Read( readRecord );
		QCOMPARE( result, SUCCESS );

		QString address2 = readRecord.GetAddress();
		QCOMPARE( _Addresses[1], address2 );

		m_TestFile->CloseT( );
	}
	catch( FSResultException *ex )
	{
		TEST_RESULT( ex );
	}
}


void FileStoreTest::UpdateInvalidRecord( )
{
	CreateAndOpenFile( );
	InsertRecord( 0 );

	try {
		// this is a silent update,
		// the record is not modified so the record is not updated
		TestRecord umodifiedRec;

		m_TestFile->UpdateT( umodifiedRec );
	}
	catch( FSResultException* ex )
	{
		QFAIL( "should not get here" );
	}

	try {
		TestRecord testRecord;
		testRecord.SetName( _Names[0] );
		QCOMPARE( testRecord.IsModified(), true );

		m_TestFile->UpdateT( testRecord );
	}
	catch( FSResultException* ex )
	{
		COMPARE_RESULT( ex, FS_CODE(INVALID_RECORD_ID) );
	}

	try {
		TestRecord testRecord( 0 );
		testRecord.SetName( _Names[0] );
		QCOMPARE( testRecord.IsModified(), true );

		testRecord.SetInvalid();

		m_TestFile->UpdateT( testRecord );
	}
	catch( FSResultException* ex )
	{
		COMPARE_RESULT( ex, FS_CODE(INVALID_RECORD) );
	}

	try {
		TestRecord invalidRecID( 99 );
		invalidRecID.SetName( _Names[0] );
		QCOMPARE( invalidRecID.IsModified(), true );

		m_TestFile->UpdateT( invalidRecID );
	}
	catch( FSResultException* ex )
	{
		COMPARE_RESULT( ex, FS_CODE(INVALID_RECORD_ID) );
	}

}


void FileStoreTest::ReadNextValidRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );

	TestRecord readRecord(0);
	ResultValue result = m_TestFile->Read( readRecord );
	QCOMPARE( result, SUCCESS );
	// VALIDATE

	result = m_TestFile->ReadNext( readRecord );
	QCOMPARE( result, SUCCESS );
	// VALIDATE
	QString address = readRecord.GetAddress();
	QCOMPARE( address, _Addresses[1] );

	// test END of FILE
	result = m_TestFile->ReadNext( readRecord );
	QCOMPARE( result, FS_CODE(READ_PAST_END_OF_FILE) );
}


void FileStoreTest::ReadNextInvalidRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 1 );

	TestRecord readRecord(0);
	ResultValue result = m_TestFile->Read( readRecord );
	QCOMPARE( result, SUCCESS );

	// VALIDATE

	result = m_TestFile->ReadNext( readRecord );
	QCOMPARE( result, FS_CODE(READ_PAST_END_OF_FILE) );
}


void FileStoreTest::InsertAndDeleteSingleRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );

	int total = m_TestFile->GetHeaderFileTotalRecordCount( );
	int active = m_TestFile->GetHeaderFileActiveRecordCount( );
	QCOMPARE( total, active );

		// delete
	ResultValue result = m_TestFile->Delete( 0 );
	QCOMPARE( result, SUCCESS );

	QCOMPARE( m_TestFile->GetHeaderFileTotalRecordCount( ), 1 );
	QCOMPARE( m_TestFile->GetHeaderFileActiveRecordCount( ), 0 );
	QCOMPARE( m_TestFile->GetHeaderFileFirstDeleted(), 0 );

		// try and delete again
	result = m_TestFile->Delete( 0 );
	QCOMPARE( result, FS_CODE(RECORD_ALREADY_DELETED) );

		// delete invalid record id
	result = m_TestFile->Delete( 99 );
	QCOMPARE( result, FS_CODE(INVALID_RECORD_ID) );

		// try to update the deleted record
	TestRecord rec(0);
	rec.SetName( "bad name" );
	result = m_TestFile->Update( rec );
	QCOMPARE( result, FS_CODE(INVALID_RECORD) );
}


void FileStoreTest::TestDeletedRecord( )
{
	// defines the deleted records -> FSRecordBaseFields
	//

	// The DeleteRecord only exists because the FSRecordBase
	// is abstract.

	// The DeleteRecord makes it possible to create a FSRecordBase
	// and it is the FSRecordBase that provides the definition of
	// the fields of the FSDeletedRecord.  The DeleteRecord fields
	// are part of every record written out.

	// Some day in the future either the FSDeletedRecord will be
	// merged in the FSRecordBase and removed, or the knowledge that
	// the FSRecordBase has of a delete record will get moved into
	// the FSDeletedRecord.

	// Create a valid base Record to compare with the FSDeletedRecord

	FSRecordBase* baseRec( m_TestFile->_NewRecord( ) );

	QCOMPARE( baseRec->GetFieldCount(), 3 );
	QCOMPARE( baseRec->GetRecordSize(), 12 );
	QCOMPARE( baseRec->GetFileID(), NO_FILE_ID );
	QCOMPARE( baseRec->GetFileType(), NO_FILE_TYPE );

	FSDeletedRecord delRec;

	QCOMPARE( delRec.GetFieldCount(), 3 );		// uses FSRecordBase methods
	QCOMPARE( delRec.GetRecordSize(), 12 );
	QCOMPARE( delRec.GetFileID(), FSDeletedRecord::DELETE_FILE_ID );
	QCOMPARE( delRec.GetFileType(), FSDeletedRecord::DELETE_FILE_TYPE );
}


void FileStoreTest::DeleteFirstRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

	ResultValue result = m_TestFile->Delete( 0 );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( 0, m_TestFile->GetHeaderFileFirstDeleted( ) );
	QCOMPARE( 0, m_TestFile->GetHeaderFileLastDeleted( ) );

	// try and read first record
	TestRecord rec( 0 );
	result = m_TestFile->Read( rec );
	QCOMPARE( result, FS_CODE(RECORD_WAS_DELETED) );

	// make sure next is valid
	result = m_TestFile->ReadNext( rec );
	QCOMPARE( result, SUCCESS );

	const QString& name = rec.GetName();
	QCOMPARE( name, _Names[1] );

	int count = m_TestFile->GetHeaderFileTotalRecordCount();
	QCOMPARE( count, 3);

	count = m_TestFile->GetHeaderFileActiveRecordCount();
	QCOMPARE( count, 2 );
}


void FileStoreTest::DeleteMiddleRecordTest( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

	ResultValue result = m_TestFile->Delete( 1 );
	QCOMPARE( result, SUCCESS );

	QCOMPARE( 1, m_TestFile->GetHeaderFileFirstDeleted( ) );
	QCOMPARE( 1, m_TestFile->GetHeaderFileLastDeleted( ) );

	//		Validate the header information
	//		Re-read all the records to verify that the data is correct

	TestRecord rec( 0 );
	result = m_TestFile->Read( rec );
	QCOMPARE( result, SUCCESS );

	QString name = rec.GetName();
	QCOMPARE( name, _Names[0] );

	result = m_TestFile->ReadNext( rec );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( rec.IsDeleted(), true );

	result = m_TestFile->ReadNext( rec );
	QCOMPARE( result, SUCCESS );

	name = rec.GetName();
	QCOMPARE( name, _Names[2] );

	// try read deleted record
	TestRecord delRec( 1 );
//	rec.ResetRecord( 1 );
	result = m_TestFile->Read( delRec );
	QCOMPARE( result, FS_CODE(RECORD_WAS_DELETED) );

	int count = m_TestFile->GetHeaderFileTotalRecordCount();
	QCOMPARE( count, 3 );

	count = m_TestFile->GetHeaderFileActiveRecordCount();
	QCOMPARE( count, 2 );
}


void FileStoreTest::DeleteLastRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

	ResultValue result = m_TestFile->Delete( 2 );
	QCOMPARE( result, SUCCESS );

	int firstDeleted = m_TestFile->GetHeaderFileFirstDeleted( );
	QCOMPARE( firstDeleted, 2 );

	int lastDeleted = m_TestFile->GetHeaderFileLastDeleted( );
	QCOMPARE( lastDeleted, 2 );

	TestRecord rec( 0 );
	result = m_TestFile->Read( rec );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->ReadNext( rec );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->ReadNext( rec );
	QCOMPARE( result, SUCCESS );
	QCOMPARE( rec.IsDeleted(), true );

	result = m_TestFile->ReadNext( rec );
	QCOMPARE( result, FS_CODE(READ_PAST_END_OF_FILE) );

	TestRecord delRec( 2 );
//	rec.ResetRecord( 2 );
	result = m_TestFile->Read( delRec );
	QCOMPARE( delRec.IsDeleted(), true );

	int count = m_TestFile->GetHeaderFileTotalRecordCount();
	QCOMPARE( count, 3 );

	count = m_TestFile->GetHeaderFileActiveRecordCount();
	QCOMPARE( count, 2 );

//	m_TOC->CloseT( );
}


void FileStoreTest::DeleteFirstTwoRecords( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

	ResultValue result = m_TestFile->Delete( 1 );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Delete( 0 );
	QCOMPARE( result, SUCCESS );

	int firstDeleted = m_TestFile->GetHeaderFileFirstDeleted( );
	QCOMPARE( firstDeleted, 1 );

	int lastDeleted = m_TestFile->GetHeaderFileLastDeleted( );
	QCOMPARE( lastDeleted, 0 );

	int count = m_TestFile->GetHeaderFileTotalRecordCount();
	QCOMPARE( count, 3 );

	count = m_TestFile->GetHeaderFileActiveRecordCount();
	QCOMPARE( count, 1 );
}


void FileStoreTest::DeleteLastTwoRecords( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

	ResultValue result = m_TestFile->Delete( 1 );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Delete( 2 );
	QCOMPARE( result, SUCCESS );

	int firstDeleted = m_TestFile->GetHeaderFileFirstDeleted( );
	QCOMPARE( firstDeleted, 1 );

	int lastDeleted = m_TestFile->GetHeaderFileLastDeleted( );
	QCOMPARE( lastDeleted, 2 );

	int count = m_TestFile->GetHeaderFileTotalRecordCount();
	QCOMPARE( count, 3 );

	count = m_TestFile->GetHeaderFileActiveRecordCount();
	QCOMPARE( count, 1 );
}


void FileStoreTest::DeleteAllRecords( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

// Does it matter what order to delete records in

	ResultValue result = m_TestFile->Delete( 1 );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Delete( 2 );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Delete( 0 );
	QCOMPARE( result, SUCCESS );

	int firstDeleted = m_TestFile->GetHeaderFileFirstDeleted( );
	QCOMPARE( firstDeleted, 1 );

	int lastDeleted = m_TestFile->GetHeaderFileLastDeleted( );
	QCOMPARE( lastDeleted, 0 );

	int count = m_TestFile->GetHeaderFileTotalRecordCount();
	QCOMPARE( count, 3 );

	count = m_TestFile->GetHeaderFileActiveRecordCount();
	QCOMPARE( count, 0 );
}


void FileStoreTest::InsertReplaceOneDeletedRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

		// delete two
	ResultValue result = m_TestFile->Delete( 1 );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Delete( 2 );
	QCOMPARE( result, SUCCESS );

	int firstDeleted = m_TestFile->GetHeaderFileFirstDeleted( );
	QCOMPARE( firstDeleted, 1 );

	int lastDeleted = m_TestFile->GetHeaderFileLastDeleted( );
	QCOMPARE( lastDeleted, 2 );

		// insert new record
	TestRecord newRecord;
	QString name( "New Record" );
	newRecord.SetName( name );

	QString addr( "A new address" );
	newRecord.SetAddress( addr );

	QString phone( "678-3434" );
	newRecord.SetPhoneNumber( phone );

	QCOMPARE( newRecord.IsModified(), true );

	m_TestFile->Insert( newRecord );

		// Validate the result
	QCOMPARE( m_TestFile->GetHeaderFileFirstDeleted( ), 2 );
	QCOMPARE( m_TestFile->GetHeaderFileLastDeleted( ), 2 );
	QCOMPARE( m_TestFile->GetHeaderFileTotalRecordCount(), 3 );
	QCOMPARE( m_TestFile->GetHeaderFileActiveRecordCount(), 2 );

	QCOMPARE( newRecord.IsModified(), false );
}


void FileStoreTest::InsertReplaceTwoDeletedRecord( )
{
	CreateAndOpenFile( );

	InsertRecord( 0 );
	InsertRecord( 1 );
	InsertRecord( 2 );

		// delete record 1 and 2
	ResultValue result = m_TestFile->Delete( 1 );
	QCOMPARE( result, SUCCESS );

	result = m_TestFile->Delete( 2 );
	QCOMPARE( result, SUCCESS );

	QCOMPARE( m_TestFile->GetHeaderFileFirstDeleted( ), 1 );
	QCOMPARE( m_TestFile->GetHeaderFileLastDeleted( ), 2 );
	QCOMPARE( m_TestFile->GetHeaderFileTotalRecordCount(), 3 );
	QCOMPARE( m_TestFile->GetHeaderFileActiveRecordCount(), 1 );

		// insert new record
	TestRecord newRecord;
	QString name( "New Record" );
	newRecord.SetName( name );

	QString addr( "A new address" );
	newRecord.SetAddress( addr );

	QString phone( "678-3434" );
	newRecord.SetPhoneNumber( phone );

	result = m_TestFile->Insert( newRecord );
	QCOMPARE( result, SUCCESS );

	TestRecord newRecord2;
	name = "New Record 2";
	newRecord2.SetName( name );

	addr = "A new address 2";
	newRecord2.SetAddress( addr );

	phone = "222-2222";
	newRecord2.SetPhoneNumber( phone );

	result = m_TestFile->Insert( newRecord2 );
	QCOMPARE( result, SUCCESS );

	// Validate the result
	QCOMPARE( m_TestFile->GetHeaderFileTotalRecordCount(), 3 );
	QCOMPARE( m_TestFile->GetHeaderFileActiveRecordCount(), 3 );	// is this correct?
}


void FileStoreTest::RecordInsert( )
{
	try {
		CreateAndOpenFile( );

			// insert new record
		TestRecord* newRecord = m_TestFile->NewRecord();
		newRecord->SetName( QString( "New Record" ) );
		newRecord->SetAddress( QString( "A new address" ) );
		newRecord->SetPhoneNumber( QString( "678-3434" ) );
		newRecord->InsertT();
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	try {
		TestRecord rec( 0 );
		rec.SetName( QString( "New Record B" ) );
		rec.SetAddress( QString( "A new address" ) );
		rec.SetPhoneNumber( QString( "678-3434" ) );
		rec.InsertT();
	}
	catch( FSResultException *ex )
	{
		COMPARE_RESULT( ex, FS_CODE(FILE_OBJECT_NOT_SET) );
	}
}


void FileStoreTest::RecordRead( )
{
	try {
		CreateAndOpenFile( );

			// insert new record
		TestRecord* newRecord = m_TestFile->NewRecord();
		newRecord->SetName( QString( "New Record" ) );
		newRecord->SetAddress( QString( "A new address" ) );
		newRecord->SetPhoneNumber( QString( "678-3434" ) );
		newRecord->InsertT();


		TestRecord* readRec = m_TestFile->NewRecord( 0 );
		readRec->ReadT();

		QCOMPARE( readRec->GetName(), newRecord->GetName() );
		QCOMPARE( readRec->GetAddress(), newRecord->GetAddress() );
		QCOMPARE( readRec->GetPhoneNumber(), newRecord->GetPhoneNumber() );


		TestRecord readRec2( 0 );
		m_TestFile->ReadT( readRec2 );

		QCOMPARE( readRec->GetName(), readRec2.GetName() );
		QCOMPARE( readRec->GetAddress(), readRec2.GetAddress() );
		QCOMPARE( readRec->GetPhoneNumber(), readRec2.GetPhoneNumber() );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	try {
		TestRecord rec( 0 );
		rec.ReadT();
	}
	catch( FSResultException* ex )
	{
		COMPARE_RESULT( ex, FS_CODE(FILE_OBJECT_NOT_SET) );
	}
}


void FileStoreTest::RecordUpdate( )
{
	try {
		CreateAndOpenFile( );

			// insert new record
		TestRecord* newRecord = m_TestFile->NewRecord();
		newRecord->SetName( QString( "New Record" ) );
		newRecord->SetAddress( QString( "A new address" ) );
		newRecord->SetPhoneNumber( QString( "678-3434" ) );
		newRecord->InsertT();

		newRecord->SetName( "another name" );
		newRecord->UpdateT( );


		TestRecord* rec2 = m_TestFile->NewRecord(0);
		rec2->ReadT();

		QCOMPARE( rec2->GetName(), newRecord->GetName() );
	}
	catch( FSResultException* ex )
	{
		TEST_RESULT( ex );
	}

	try {
		TestRecord rec( 0 );
		rec.SetName( "new name" );
		rec.UpdateT();
	}
	catch( FSResultException* ex )
	{
		COMPARE_RESULT( ex, FS_CODE(FILE_OBJECT_NOT_SET) );
	}
}

