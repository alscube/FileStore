
// FSGlobalTypes.h

// Copyright (C) 2016 Al's Cube
// see www.alscube.com

// This software is released under the LGPLv3 license



#pragma once

#include <QtGlobal>

#include "stdint.h"

// you can mix these with qint's
typedef int32_t INT32;
typedef uint32_t UINT32;
typedef int64_t INT64;
typedef u_int64_t UINT64;


// If these are 'typedefs' it makes file IO a bit more annoying

// All Dates
// QDate::toJulianDay()
#define DATE qint64


// General ID
#define ID qint64


	// These IDs are more specific and can be
	// interchanged with the ID (for now)

// Unique ID used to identify a file
#define FILE_ID qint32
#define NO_FILE_ID -1

// Identifies the category of the file
#define FILE_TYPE qint32
#define NO_FILE_TYPE -1

// ID used to identify a record in file
#define REC_ID qint32
#define NO_REC_ID -1
